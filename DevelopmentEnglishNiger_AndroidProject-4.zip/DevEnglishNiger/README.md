# Development English — Niger

Professional English for Development Projects · Application Android d'apprentissage

## What this is

A complete, offline-first Android Studio project (Kotlin + Jetpack Compose, Material 3,
Room, DataStore, native Android TextToSpeech). No server, no account, no internet
required for lessons, vocabulary, exercises, TTS, or progress tracking.

## How to get an installable APK

You have **two options** — pick whichever is easier for you. Neither requires
technical Android experience beyond following the steps below.

### Option A — No installation needed (recommended if you don't have Android Studio)

This project includes a GitHub Actions workflow (`.github/workflows/build-apk.yml`)
that builds the APK automatically in the cloud — you never touch Gradle or the
Android SDK yourself.

1. Create a free account at https://github.com if you don't have one.
2. Create a new **private or public repository** (e.g. `development-english-niger`).
3. Upload the entire contents of this project folder to that repository
   (drag-and-drop works on github.com, or use `git push` if you're comfortable with Git).
4. Go to the repository's **Actions** tab. A workflow called "Build APK" will run
   automatically (or click "Run workflow" to trigger it manually).
5. Wait 3–5 minutes for the build to finish (green checkmark).
6. Click on the completed run → scroll to **Artifacts** → download
   `DevelopmentEnglishNiger-debug-apk`. Unzip it — inside is `app-debug.apk`.
7. Transfer that `.apk` file to an Android phone (email it to yourself, use a USB
   cable, or Google Drive) and tap it to install. You may need to allow
   "install from unknown sources" the first time — Android will prompt you.

This produces a **debug APK**, which is perfectly installable and functional,
but not signed for the Play Store. For a Play Store release, use Option B and
follow the signed-release steps below.

### Option B — Using Android Studio locally

1. Install **Android Studio** (Koala/2024.1 or newer): https://developer.android.com/studio
2. Open Android Studio → **Open** → select this project folder
   (`DevEnglishNiger/`, the one containing `settings.gradle.kts`).
3. Let Gradle sync (first sync needs internet to download dependencies — after that,
   the app itself runs fully offline on the phone).
4. Connect an Android phone (USB debugging enabled) or start an emulator.
5. To install and test directly: **Run ▶** (Shift+F10).
6. To produce a real installable APK file:
   **Build → Generate App Bundle / APK → Generate APK(s)**
   → APK appears in `app/build/outputs/apk/debug/app-debug.apk`.
7. For a signed release APK (needed to distribute outside your own devices):
   **Build → Generate Signed Bundle / APK** → follow the keystore wizard.

Minimum Android version supported: Android 7.0 (API 24).

## Project structure

```
app/src/main/java/com/nigerdev/englishtraining/
  data/model/        Content data classes (Module, VocabItem, Expression, ConceptCard,
                      DonorQuestion, Exercise) — the shared template for all 24 modules
  data/repository/   ModuleNContent.kt files (one per authored module) + ContentRepository
                      (aggregator, search) + ProgressRepository + SettingsRepository
  data/db/           Room entities/DAO/database — learner's saved progress
  tts/               TtsManager — wraps android.speech.tts.TextToSpeech
  ui/screens/        One package per screen (home, learningpath, module, vocabulary,
                      expressions, practice, donorsim, progress, settings, search)
  ui/components/     Reusable ListenButton / AudioSentence (the 🔊 button everywhere)
  ui/navgraph/       NavGraph wiring all screens together
  navigation/        Route definitions
```

## Adding Modules 4–24

Each module follows the exact same template. To add Module N:

1. Create `data/repository/ModuleNContent.kt` copying the shape of
   `Module3Content.kt` (vocabulary, collocations, concepts, donorQuestions, exercises).
2. Add `moduleN` to `ContentRepository.fullModules`.
3. Nothing else needs to change — Learning Path, Vocabulary, Expressions, Practice,
   Donor Simulation, Search and Progress all read from `ContentRepository` automatically.

Status: **25 modules fully authored** (Modules 1–24 per the original plan, plus Module 25
"Presenting Socio-Economic Data" added afterward), covering the complete arc from
foundational vocabulary through GIS/spatial evidence, project cycle, logical framework,
indicators, MEAL, safeguards, gender/inclusion, donor proposal writing, donor presentation
and defense, negotiation, professional correspondence, executive communication, and
socio-economic data presentation.
