package com.nigerdev.englishtraining.data.repository

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "settings")

enum class EnglishVoice { US, UK, DEVICE_DEFAULT }
enum class TextSize { SMALL, MEDIUM, LARGE }

data class AppSettings(
    val speechRate: Float = 1.0f,          // 0.70 / 1.00 / 1.20
    val englishVoice: EnglishVoice = EnglishVoice.US,
    val textSize: TextSize = TextSize.MEDIUM,
    val darkMode: Boolean = false,
    val interfaceFrenchPrimary: Boolean = true // whether French labels take priority in beginner modules
)

class SettingsRepository(private val context: Context) {

    private object Keys {
        val SPEECH_RATE = floatPreferencesKey("speech_rate")
        val VOICE = stringPreferencesKey("english_voice")
        val TEXT_SIZE = stringPreferencesKey("text_size")
        val DARK_MODE = booleanPreferencesKey("dark_mode")
        val FR_PRIMARY = booleanPreferencesKey("interface_french_primary")
    }

    val settingsFlow: Flow<AppSettings> = context.dataStore.data.map { prefs ->
        AppSettings(
            speechRate = prefs[Keys.SPEECH_RATE] ?: 1.0f,
            englishVoice = prefs[Keys.VOICE]?.let { runCatching { EnglishVoice.valueOf(it) }.getOrNull() } ?: EnglishVoice.US,
            textSize = prefs[Keys.TEXT_SIZE]?.let { runCatching { TextSize.valueOf(it) }.getOrNull() } ?: TextSize.MEDIUM,
            darkMode = prefs[Keys.DARK_MODE] ?: false,
            interfaceFrenchPrimary = prefs[Keys.FR_PRIMARY] ?: true
        )
    }

    suspend fun setSpeechRate(rate: Float) {
        context.dataStore.edit { it[Keys.SPEECH_RATE] = rate }
    }
    suspend fun setVoice(voice: EnglishVoice) {
        context.dataStore.edit { it[Keys.VOICE] = voice.name }
    }
    suspend fun setTextSize(size: TextSize) {
        context.dataStore.edit { it[Keys.TEXT_SIZE] = size.name }
    }
    suspend fun setDarkMode(enabled: Boolean) {
        context.dataStore.edit { it[Keys.DARK_MODE] = enabled }
    }
    suspend fun setFrenchPrimary(enabled: Boolean) {
        context.dataStore.edit { it[Keys.FR_PRIMARY] = enabled }
    }
}
