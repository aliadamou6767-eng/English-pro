package com.nigerdev.englishtraining.ui.screens.vocabulary

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nigerdev.englishtraining.AppContainer
import com.nigerdev.englishtraining.ui.components.AudioSentence

@Composable
fun MyVocabularyScreen(appContainer: AppContainer) {
    val savedVocab by appContainer.progressRepository.observeSavedVocabulary().collectAsState(initial = emptyList())

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("My Vocabulary", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Ma liste de vocabulaire personnelle", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(12.dp))

        if (savedVocab.isEmpty()) {
            Text("You haven't saved any words yet. Tap the ⭐ on a vocabulary card to add it here.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(savedVocab, key = { it.vocabId }) { item ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            AudioSentence(english = item.english, ttsManager = appContainer.ttsManager, style = MaterialTheme.typography.titleMedium)
                            Text(item.french, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(4.dp))
                            AudioSentence(english = item.exampleEn, ttsManager = appContainer.ttsManager, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }
    }
}
