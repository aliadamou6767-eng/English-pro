package com.nigerdev.englishtraining.data.repository

import com.nigerdev.englishtraining.data.model.*

/**
 * MODULE 7 — Territorial Analysis and Selection of an Intervention Area
 * Analyse territoriale et choix d'une zone d'intervention
 * English ratio: 55% (intermediate begins)
 */
val module7 = Module(
    id = 7,
    titleEn = "Territorial Analysis and Selection of an Intervention Area",
    titleFr = "Analyse territoriale et choix d'une zone d'intervention",
    englishRatio = 0.55f,
    objectiveEn = "By the end of this lesson, you will be able to explain, in English, the criteria and process used to select a project intervention area.",
    objectiveFr = "À la fin de cette leçon, vous serez capable d'expliquer en anglais les critères et le processus de choix d'une zone d'intervention.",
    vocabulary = listOf(
        VocabItem("m7_territorial_analysis", "territorial analysis", "analyse territoriale",
            "A structured study of a geographic area's characteristics, resources, and constraints to inform planning decisions.",
            "Étude structurée des caractéristiques, ressources et contraintes d'une zone géographique pour éclairer les décisions de planification.",
            "The territorial analysis combined satellite imagery, census data, and field visits.", 7),
        VocabItem("m7_selection_criteria", "selection criteria", "critères de sélection",
            "The agreed set of factors used to compare and choose between candidate intervention areas.",
            "Ensemble convenu de facteurs utilisés pour comparer et choisir entre zones d'intervention candidates.",
            "Poverty rate, accessibility and prior project presence were among the selection criteria.", 7),
        VocabItem("m7_administrative_boundary", "administrative boundary", "limite administrative",
            "The official border of a region, department, or commune.",
            "Frontière officielle d'une région, d'un département ou d'une commune.",
            "The intervention area follows the administrative boundary of the commune of Say.", 7),
        VocabItem("m7_commune", "commune", "commune",
            "The smallest decentralized administrative unit in Niger's territorial organization.",
            "La plus petite unité administrative décentralisée dans l'organisation territoriale du Niger.",
            "The project covers four rural communes in the Tillabéri region.", 7),
        VocabItem("m7_accessibility", "accessibility", "accessibilité",
            "The ease with which an area can be physically reached, affecting logistics and monitoring.",
            "Facilité avec laquelle une zone peut être physiquement atteinte, affectant la logistique et le suivi.",
            "Poor accessibility during the rainy season was factored into the site selection.", 7),
        VocabItem("m7_geographic_targeting", "geographic targeting", "ciblage géographique",
            "The process of selecting specific areas for intervention based on defined criteria, prior to household-level targeting.",
            "Processus de sélection de zones spécifiques d'intervention selon des critères définis, avant le ciblage au niveau des ménages.",
            "Geographic targeting narrowed forty candidate communes down to six.", 7),
        VocabItem("m7_convergence_zone", "convergence zone", "zone de convergence",
            "An area where multiple projects or sectors concentrate their interventions to maximize combined impact.",
            "Zone où plusieurs projets ou secteurs concentrent leurs interventions pour maximiser l'impact combiné.",
            "The commune was designated a convergence zone under the national resilience strategy.", 7)
    ),
    collocations = listOf(
        Expression("m7_e1", "to select an intervention area", "choisir une zone d'intervention",
            "The core phrase of this entire module — expect it constantly in proposals and interviews.",
            "The organization selected the intervention area based on vulnerability mapping.", 7),
        Expression("m7_e2", "to apply selection criteria", "appliquer des critères de sélection",
            "Describes the analytical step of comparing candidate areas.",
            "The team applied selection criteria to rank twelve candidate communes.", 7),
        Expression("m7_e3", "to overlay data layers", "superposer des couches de données",
            "Common in GIS-informed targeting discussions (see also Module 10).",
            "Analysts overlaid rainfall, poverty and population data layers to identify priority zones.", 7),
        Expression("m7_e4", "to avoid duplication with other actors", "éviter les doublons avec d'autres acteurs",
            "Frequently raised by donors as a justification requirement.",
            "The area was chosen partly to avoid duplication with other actors already present nearby.", 7),
        Expression("m7_e5", "to justify the choice of area", "justifier le choix de la zone",
            "Directly links to Donor Simulation practice — this is one of the most common donor questions.",
            "The proposal must clearly justify the choice of area using evidence, not assumption.", 7)
    ),
    concepts = listOf(
        ConceptCard("m7_c1", "Multi-criteria area selection", "Sélection de zone multicritère",
            "Rather than a single indicator, credible area selection combines several weighted criteria — vulnerability, accessibility, institutional presence, complementarity with other actors.",
            "Plutôt qu'un seul indicateur, une sélection de zone crédible combine plusieurs critères pondérés — vulnérabilité, accessibilité, présence institutionnelle, complémentarité avec d'autres acteurs.",
            "An illustrative scoring matrix for six Dosso-region communes weighted vulnerability at 40%, accessibility at 20%, and actor complementarity at 20%.", true, 7),
        ConceptCard("m7_c2", "Geographic vs. household targeting", "Ciblage géographique vs. ciblage des ménages",
            "Geographic targeting narrows the intervention area; household targeting (see Module 4) then identifies specific beneficiaries within that area. Confusing the two levels weakens a proposal's logic.",
            "Le ciblage géographique restreint la zone d'intervention ; le ciblage des ménages identifie ensuite les bénéficiaires précis au sein de cette zone. Confondre les deux niveaux affaiblit la logique d'une proposition.",
            "In an illustrative Tahoua project, geographic targeting selected two communes, after which household targeting selected the 30% most vulnerable households within them.", true, 7)
    ),
    donorQuestions = listOf(
        DonorQuestion("m7_dq1",
            "Why did you select this specific area rather than other equally poor areas nearby?",
            "We applied a multi-criteria selection process combining vulnerability data, accessibility, and the absence of other actors, and this commune scored highest while also avoiding duplication with an ongoing programme in the neighbouring commune.",
            "Bonne réponse : elle mentionne des critères précis et la non-duplication, deux éléments que les bailleurs valorisent fortement.",
            "area selection", 7),
        DonorQuestion("m7_dq2",
            "What data did you use to compare candidate intervention areas?",
            "We overlaid rainfall variability, poverty incidence, and population density data with field validation visits to confirm the results were accurate on the ground.",
            "Bonne réponse : elle combine données secondaires et vérification de terrain, ce qui renforce la fiabilité.",
            "evidence", 7)
    ),
    exercises = listOf(
        Exercise("m7_ex1", ExerciseType.MULTIPLE_CHOICE,
            "Which phrase best describes selecting areas before selecting individual beneficiaries?",
            "Quelle expression décrit le mieux la sélection de zones avant celle des bénéficiaires individuels ?",
            listOf("household targeting", "geographic targeting", "value chain", "convergence zone"),
            "geographic targeting", "Le ciblage géographique précède le ciblage des ménages.", 7),
        Exercise("m7_ex2", ExerciseType.TRANSLATION_FR_EN,
            "Translate: « La proposition doit clairement justifier le choix de la zone. »", null, emptyList(),
            "The proposal must clearly justify the choice of area.",
            "« Justify the choice of » est la collocation standard.", 7)
    )
)
