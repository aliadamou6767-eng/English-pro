package com.nigerdev.englishtraining.data.repository

import com.nigerdev.englishtraining.data.model.*

/**
 * MODULE 8 — Stakeholder Identification and Engagement
 * Identification et mobilisation des parties prenantes
 * English ratio: 55%
 */
val module8 = Module(
    id = 8,
    titleEn = "Stakeholder Identification and Engagement",
    titleFr = "Identification et mobilisation des parties prenantes",
    englishRatio = 0.55f,
    objectiveEn = "By the end of this lesson, you will be able to describe stakeholder mapping and engagement processes in English.",
    objectiveFr = "À la fin de cette leçon, vous serez capable de décrire les processus de cartographie et de mobilisation des parties prenantes en anglais.",
    vocabulary = listOf(
        VocabItem("m8_stakeholder_mapping", "stakeholder mapping", "cartographie des parties prenantes",
            "The process of identifying and categorizing all actors with an interest in or influence over a project.",
            "Processus d'identification et de catégorisation de tous les acteurs ayant un intérêt dans un projet ou une influence sur celui-ci.",
            "Stakeholder mapping identified fourteen key actors across three levels of governance.", 8),
        VocabItem("m8_traditional_authority", "traditional authority", "autorité coutumière",
            "A customary leader, such as a village chief, recognized within local governance structures.",
            "Chef coutumier, tel qu'un chef de village, reconnu au sein des structures de gouvernance locale.",
            "The traditional authority endorsed the land-use plan during the village assembly.", 8),
        VocabItem("m8_technical_service", "technical service", "service technique",
            "A decentralized government department, such as agriculture or livestock, providing specialized support.",
            "Service gouvernemental déconcentré, tel que l'agriculture ou l'élevage, apportant un appui spécialisé.",
            "The commune's agricultural technical service co-facilitated the training session.", 8),
        VocabItem("m8_consultation", "community consultation", "consultation communautaire",
            "A structured process of gathering input and feedback directly from community members.",
            "Processus structuré de recueil des avis et des retours directement auprès des membres de la communauté.",
            "Community consultations were held in all six target villages before the design phase.", 8),
        VocabItem("m8_buy_in", "buy-in", "adhésion",
            "The support and commitment of stakeholders toward a project's objectives and approach.",
            "Soutien et engagement des parties prenantes envers les objectifs et l'approche d'un projet.",
            "Early consultation secured strong buy-in from the mayor's office.", 8),
        VocabItem("m8_conflict_of_interest", "conflict of interest", "conflit d'intérêts",
            "A situation where a stakeholder's personal or institutional interest could compromise project objectivity.",
            "Situation où l'intérêt personnel ou institutionnel d'une partie prenante pourrait compromettre l'objectivité du projet.",
            "The team flagged a potential conflict of interest before finalizing the site selection committee.", 8),
        VocabItem("m8_grievance_mechanism", "grievance mechanism", "mécanisme de gestion des plaintes",
            "A formal channel that allows community members to raise concerns or complaints about a project.",
            "Canal formel permettant aux membres de la communauté de soulever des préoccupations ou des plaintes concernant un projet.",
            "A community-based grievance mechanism was established before construction began.", 8)
    ),
    collocations = listOf(
        Expression("m8_e1", "to engage stakeholders", "mobiliser les parties prenantes",
            "The core action verb of this module.",
            "The project engaged stakeholders at village, commune, and regional levels.", 8),
        Expression("m8_e2", "to secure the support of local authorities", "obtenir le soutien des autorités locales",
            "A frequent requirement in donor proposals.",
            "Early meetings helped secure the support of local authorities for the intervention.", 8),
        Expression("m8_e3", "to hold a consultation", "organiser une consultation",
            "Standard collocation for participatory processes.",
            "The team held a consultation with women's groups before finalizing activities.", 8),
        Expression("m8_e4", "to build trust with communities", "instaurer la confiance avec les communautés",
            "Used to describe relationship-building, especially in sensitive contexts.",
            "Transparent communication helped build trust with communities from the outset.", 8),
        Expression("m8_e5", "to establish a grievance mechanism", "mettre en place un mécanisme de gestion des plaintes",
            "Common in safeguards and accountability sections of proposals.",
            "The organization established a grievance mechanism accessible by phone and in person.", 8)
    ),
    concepts = listOf(
        ConceptCard("m8_c1", "Stakeholder categories", "Catégories de parties prenantes",
            "Stakeholders are typically grouped as primary (directly affected), secondary (institutions, service providers), and key influencers (decision-makers whose support is essential).",
            "Les parties prenantes sont généralement regroupées en primaires (directement affectées), secondaires (institutions, prestataires de services) et influenceurs clés (décideurs dont le soutien est essentiel).",
            "In an illustrative mapping for a Niamey-area project, the primary stakeholders were farming households, while the mayor's office was a key influencer.", true, 8),
        ConceptCard("m8_c2", "Free, prior and informed engagement", "Engagement libre, préalable et éclairé",
            "Meaningful stakeholder engagement happens before major decisions are made, gives communities accurate information, and does not pressure participation.",
            "Un engagement significatif des parties prenantes a lieu avant que les décisions majeures ne soient prises, fournit une information exacte aux communautés et n'exerce aucune pression sur leur participation.",
            "An illustrative example: village assemblies were held before, not after, the intervention area was finalized.", true, 8)
    ),
    donorQuestions = listOf(
        DonorQuestion("m8_dq1",
            "How will local authorities and communities participate in this project, beyond simply being informed?",
            "Local authorities co-chair the project steering committee, and communities are represented through elected village committees involved in planning, monitoring, and grievance resolution — not only in implementation.",
            "Bonne réponse : elle distingue une participation réelle (comités, suivi) d'une simple information, ce que les bailleurs cherchent à vérifier.",
            "participation", 8)
    ),
    exercises = listOf(
        Exercise("m8_ex1", ExerciseType.MULTIPLE_CHOICE,
            "Which term describes the support and commitment of stakeholders toward a project?",
            "Quel terme désigne le soutien et l'engagement des parties prenantes envers un projet ?",
            listOf("buy-in", "grievance mechanism", "conflict of interest", "consultation"),
            "buy-in", "« Buy-in » = adhésion / soutien actif des parties prenantes.", 8),
        Exercise("m8_ex2", ExerciseType.FILL_BLANK,
            "A community-based grievance mechanism was ______ before construction began.", null,
            listOf("established", "consulted", "engaged", "secured"),
            "established",
            "« Establish a mechanism » est la collocation correcte.", 8)
    )
)
