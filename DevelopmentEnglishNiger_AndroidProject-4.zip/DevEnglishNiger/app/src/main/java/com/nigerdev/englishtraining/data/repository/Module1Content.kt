package com.nigerdev.englishtraining.data.repository

import com.nigerdev.englishtraining.data.model.*

/**
 * MODULE 1 — Foundations of Development English
 * Les bases de l'anglais du développement
 * English ratio: 40% (beginner)
 */
val module1 = Module(
    id = 1,
    titleEn = "Foundations of Development English",
    titleFr = "Les bases de l'anglais du développement",
    englishRatio = 0.40f,
    objectiveEn = "By the end of this lesson, you will be able to name the main actors and basic concepts of a development project in English.",
    objectiveFr = "À la fin de cette leçon, vous serez capable de nommer les principaux acteurs et concepts de base d'un projet de développement en anglais.",
    vocabulary = listOf(
        VocabItem("m1_development", "development", "développement",
            "Positive economic, social or institutional change that improves people's living conditions.",
            "Changement positif économique, social ou institutionnel qui améliore les conditions de vie des populations.",
            "Rural development remains a priority for the Government of Niger.", 1),
        VocabItem("m1_project", "project", "projet",
            "A set of coordinated activities with a defined objective, timeframe and budget.",
            "Ensemble d'activités coordonnées avec un objectif, une durée et un budget définis.",
            "The project covers three rural municipalities in the Tillabéri region.", 1),
        VocabItem("m1_donor", "donor", "bailleur de fonds",
            "An organization or government that provides funding for a development project.",
            "Organisation ou gouvernement qui finance un projet de développement.",
            "The donor requested a detailed budget before approving the project.", 1),
        VocabItem("m1_beneficiary", "beneficiary", "bénéficiaire",
            "A person or group who receives direct benefit from a project's activities.",
            "Personne ou groupe qui bénéficie directement des activités d'un projet.",
            "Women-headed households are among the main beneficiaries of this programme.", 1),
        VocabItem("m1_stakeholder", "stakeholder", "partie prenante",
            "Any person, group or institution with an interest in, or affected by, a project.",
            "Toute personne, groupe ou institution ayant un intérêt dans un projet ou affecté par celui-ci.",
            "Local authorities and technical services are key stakeholders in this intervention.", 1),
        VocabItem("m1_implementing_partner", "implementing partner", "partenaire de mise en œuvre",
            "The organization responsible for carrying out project activities on the ground.",
            "Organisation chargée de mettre en œuvre les activités du projet sur le terrain.",
            "The NGO acts as the implementing partner for the water access project.", 1),
        VocabItem("m1_field_officer", "field officer", "agent de terrain",
            "A staff member who works directly with communities in the intervention area.",
            "Membre du personnel qui travaille directement avec les communautés dans la zone d'intervention.",
            "The field officer collected household data in three villages last week.", 1),
        VocabItem("m1_intervention_area", "intervention area", "zone d'intervention",
            "The specific geographic zone where a project's activities take place.",
            "Zone géographique précise où se déroulent les activités d'un projet.",
            "The intervention area was selected based on vulnerability criteria.", 1)
    ),
    collocations = listOf(
        Expression("m1_e1", "to implement a project", "mettre en œuvre un projet",
            "Used to describe the active phase of carrying out planned activities.",
            "The organization began to implement the project in January 2026.", 1),
        Expression("m1_e2", "to work in the field", "travailler sur le terrain",
            "Refers to hands-on presence in communities, as opposed to office-based work.",
            "Our team works in the field three days a week.", 1),
        Expression("m1_e3", "to report to a donor", "rendre compte à un bailleur",
            "The formal act of providing updates and accountability to a funding organization.",
            "The project manager reports to the donor on a quarterly basis.", 1),
        Expression("m1_e4", "to coordinate with local authorities", "se coordonner avec les autorités locales",
            "Working jointly and communicating with mayors, prefects, or traditional chiefs.",
            "The team coordinates with local authorities before every field mission.", 1),
        Expression("m1_e5", "to be based in", "être basé à",
            "Used to indicate a person's or an office's fixed working location.",
            "The regional coordinator is based in Tahoua.", 1),
        Expression("m1_e6", "to cover a region", "couvrir une région",
            "Describes the geographic scope of a project's activities.",
            "The programme covers the Maradi and Zinder regions.", 1)
    ),
    concepts = listOf(
        ConceptCard("m1_c1", "Development actor", "Acteur du développement",
            "A development actor is any organization involved in designing, funding or implementing development activities: governments, NGOs, UN agencies, and donors.",
            "Un acteur du développement est toute organisation impliquée dans la conception, le financement ou la mise en œuvre d'activités de développement : gouvernements, ONG, agences des Nations Unies et bailleurs.",
            "In Niger, actors such as the Ministry of Agriculture, GIZ, and FAO work together on food security programmes.", true, 1),
        ConceptCard("m1_c2", "Project cycle (overview)", "Cycle de projet (aperçu)",
            "The project cycle is the sequence a project follows: identification, design, approval, implementation, monitoring, and closure.",
            "Le cycle de projet est la séquence suivie par un projet : identification, conception, approbation, mise en œuvre, suivi et clôture.",
            "A water-access project in Dosso region moved from identification to implementation over eighteen months.", true, 1)
    ),
    exercises = listOf(
        Exercise("m1_ex1", ExerciseType.MULTIPLE_CHOICE,
            "Which word describes a person who receives direct benefit from a project?",
            "Quel mot désigne une personne qui bénéficie directement d'un projet ?",
            listOf("donor", "beneficiary", "stakeholder", "field officer"),
            "beneficiary", "« Beneficiary » désigne le bénéficiaire direct, à distinguer de « stakeholder » (partie prenante, plus large).", 1),
        Exercise("m1_ex2", ExerciseType.TRANSLATION_FR_EN,
            "Translate: « La zone d'intervention a été choisie selon des critères de vulnérabilité. »", null, emptyList(),
            "The intervention area was selected based on vulnerability criteria.",
            "Notez l'usage de « based on » pour exprimer « selon/sur la base de ».", 1)
    )
)
