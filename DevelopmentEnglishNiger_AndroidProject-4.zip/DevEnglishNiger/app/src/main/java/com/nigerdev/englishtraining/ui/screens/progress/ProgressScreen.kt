package com.nigerdev.englishtraining.ui.screens.progress

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nigerdev.englishtraining.AppContainer
import com.nigerdev.englishtraining.data.repository.ContentRepository

@Composable
fun ProgressScreen(appContainer: AppContainer) {
    val repo = appContainer.progressRepository
    val progressList by repo.observeModuleProgress().collectAsState(initial = emptyList())
    val savedVocab by repo.observeSavedVocabulary().collectAsState(initial = emptyList())
    val practiceCount by repo.observePracticeSessionCount().collectAsState(initial = 0)
    val donorCount by repo.observeDonorSimCompletedCount().collectAsState(initial = 0)

    val completed = progressList.count { it.isCompleted }
    val total = ContentRepository.allModuleTitles.size

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Progress", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Votre progression", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(12.dp))

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                StatRow("Modules completed", "$completed / $total")
                StatRow("Vocabulary saved", "${savedVocab.size} words")
                StatRow("Practice sessions", "$practiceCount")
                StatRow("Donor questions practiced", "$donorCount")
            }
        }

        Spacer(Modifier.height(16.dp))
        Text("Quiz scores by module", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(progressList.sortedBy { it.moduleId }) { p ->
                val stub = ContentRepository.allModuleTitles.find { it.id == p.moduleId }
                Card(Modifier.fillMaxWidth()) {
                    Row(
                        Modifier.padding(12.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Module ${p.moduleId} · ${stub?.titleEn ?: ""}")
                        Text(if (p.quizBestScorePercent > 0) "${p.quizBestScorePercent}%" else "—")
                    }
                }
            }
        }
    }
}

@Composable
private fun StatRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label)
        Text(value, fontWeight = FontWeight.Bold)
    }
}
