package com.nigerdev.englishtraining.data.repository

import com.nigerdev.englishtraining.data.model.*

/**
 * MODULE 12 — Project Cycle Management
 * Gestion du cycle de projet
 * English ratio: 60%
 */
val module12 = Module(
    id = 12,
    titleEn = "Project Cycle Management",
    titleFr = "Gestion du cycle de projet",
    englishRatio = 0.60f,
    objectiveEn = "By the end of this lesson, you will be able to describe the full project cycle and each phase's purpose in English.",
    objectiveFr = "À la fin de cette leçon, vous serez capable de décrire l'ensemble du cycle de projet et le but de chaque phase en anglais.",
    vocabulary = listOf(
        VocabItem("m12_project_cycle", "project cycle", "cycle de projet",
            "The sequence of phases a project moves through, from identification to closure.",
            "La séquence de phases qu'un projet traverse, de l'identification à la clôture.",
            "Understanding the project cycle helps new staff anticipate what comes next.", 12),
        VocabItem("m12_appraisal", "appraisal", "évaluation ex ante / instruction",
            "The phase in which a proposed project's feasibility, relevance and risks are formally assessed before approval.",
            "Phase durant laquelle la faisabilité, la pertinence et les risques d'un projet proposé sont formellement évalués avant approbation.",
            "The donor's appraisal process took six weeks before the grant was approved.", 12),
        VocabItem("m12_inception_phase", "inception phase", "phase de démarrage",
            "The early implementation period focused on setting up systems, staff and baseline data.",
            "Période initiale de mise en œuvre consacrée à la mise en place des systèmes, du personnel et des données de référence.",
            "The inception phase included recruiting field staff and finalizing the baseline survey.", 12),
        VocabItem("m12_closure", "project closure", "clôture du projet",
            "The final phase, including final reporting, asset handover, and evaluation.",
            "La phase finale, incluant le rapport final, le transfert des actifs et l'évaluation.",
            "Project closure included a handover ceremony with the commune authorities.", 12),
        VocabItem("m12_no_cost_extension", "no-cost extension", "prolongation sans coût",
            "An approved extension of a project's timeline without additional funding.",
            "Prolongation approuvée de la durée d'un projet sans financement supplémentaire.",
            "The donor granted a three-month no-cost extension due to flooding delays.", 12),
        VocabItem("m12_deliverable", "deliverable", "livrable",
            "A tangible output a project commits to producing within a given timeframe.",
            "Un résultat tangible qu'un projet s'engage à produire dans un délai donné.",
            "The mid-term report was the first major deliverable of the second year.", 12)
    ),
    collocations = listOf(
        Expression("m12_e1", "to move through the project cycle", "traverser le cycle de projet",
            "Used to describe progression across phases.",
            "The proposal moved through the project cycle from concept note to signed agreement.", 12),
        Expression("m12_e2", "to submit a project for appraisal", "soumettre un projet à évaluation",
            "Common phrase for the approval step.",
            "The proposal was submitted for appraisal in March and approved in May.", 12),
        Expression("m12_e3", "to close out a project", "clôturer un projet",
            "Describes the administrative and programmatic wrap-up of a project.",
            "The team closed out the project with a final report and asset inventory.", 12),
        Expression("m12_e4", "to request a no-cost extension", "demander une prolongation sans coût",
            "Frequently used phrase in donor correspondence (see also Module 23).",
            "We requested a no-cost extension to complete the remaining activities.", 12),
        Expression("m12_e5", "to meet project milestones", "atteindre les jalons du projet",
            "Common in progress reporting.",
            "The team met all project milestones scheduled for the first year.", 12)
    ),
    concepts = listOf(
        ConceptCard("m12_c1", "The six phases of the project cycle", "Les six phases du cycle de projet",
            "A typical project cycle includes: identification, design/formulation, appraisal, implementation, monitoring and evaluation, and closure — each with distinct outputs and decision points.",
            "Un cycle de projet type comprend : identification, conception/formulation, évaluation ex ante, mise en œuvre, suivi-évaluation et clôture — chacune avec des résultats et des points de décision distincts.",
            "In an illustrative donor-funded project in Zinder region, the appraisal phase alone took two months before the design was approved for funding.", true, 12),
        ConceptCard("m12_c2", "Why phase discipline matters", "Pourquoi la discipline des phases est importante",
            "Skipping or rushing a phase — such as moving to implementation without a completed needs assessment — is one of the most common causes of project design weaknesses raised by donors.",
            "Sauter ou précipiter une phase — comme passer à la mise en œuvre sans évaluation des besoins complète — est l'une des causes les plus fréquentes de faiblesses de conception relevées par les bailleurs.",
            "An illustrative example: a project that skipped stakeholder consultation faced community resistance during implementation that could have been anticipated.", true, 12)
    ),
    donorQuestions = listOf(
        DonorQuestion("m12_dq1",
            "Where is this project in the project cycle, and what is the next milestone?",
            "The project has completed appraisal and is in its inception phase; the next milestone is completion of the baseline survey, expected within six weeks.",
            "Bonne réponse : elle situe précisément le projet dans le cycle et donne une échéance claire.",
            "project cycle", 12)
    ),
    exercises = listOf(
        Exercise("m12_ex1", ExerciseType.MULTIPLE_CHOICE,
            "Which phase involves formally assessing a project's feasibility before approval?",
            "Quelle phase consiste à évaluer formellement la faisabilité d'un projet avant approbation ?",
            listOf("closure", "appraisal", "inception phase", "deliverable"),
            "appraisal", "« Appraisal » est la phase d'évaluation avant approbation.", 12),
        Exercise("m12_ex2", ExerciseType.FILL_BLANK,
            "The donor granted a three-month no-cost ______ due to flooding delays.", null,
            listOf("extension", "closure", "deliverable", "appraisal"),
            "extension",
            "« No-cost extension » est l'expression consacrée.", 12)
    )
)
