package com.nigerdev.englishtraining.ui.screens.learningpath

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nigerdev.englishtraining.AppContainer
import com.nigerdev.englishtraining.data.repository.ContentRepository

@Composable
fun LearningPathScreen(appContainer: AppContainer, onOpenModule: (Int) -> Unit) {
    val progressList by appContainer.progressRepository.observeModuleProgress().collectAsState(initial = emptyList())
    val completedIds = remember(progressList) { progressList.filter { it.isCompleted }.map { it.moduleId }.toSet() }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Learning Path", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("Parcours d'apprentissage · 24 modules", style = MaterialTheme.typography.bodyMedium)
        }

        items(ContentRepository.allModuleTitles) { stub ->
            val isCompleted = stub.id in completedIds
            val isUnlocked = stub.id == 1 || (stub.id - 1) in completedIds
            val authored = ContentRepository.isModuleAuthored(stub.id)

            Card(
                modifier = Modifier.fillMaxWidth(),
                onClick = { if (isUnlocked) onOpenModule(stub.id) }
            ) {
                Row(
                    modifier = Modifier.padding(16.dp).fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = when {
                            isCompleted -> Icons.Filled.CheckCircle
                            isUnlocked -> Icons.Filled.PlayCircle
                            else -> Icons.Filled.Lock
                        },
                        contentDescription = null
                    )
                    Column(Modifier.weight(1f)) {
                        Text("Module ${stub.id}", style = MaterialTheme.typography.labelLarge)
                        Text(stub.titleEn, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text(stub.titleFr, style = MaterialTheme.typography.bodyMedium)
                        if (!authored) {
                            Text("Content in production", style = MaterialTheme.typography.labelLarge)
                        }
                    }
                }
            }
        }
    }
}
