package com.nigerdev.englishtraining.data.repository

import com.nigerdev.englishtraining.data.model.*

/**
 * MODULE 14 — Indicators, Baseline, Targets and Means of Verification
 * Indicateurs, situation de référence, cibles et moyens de vérification
 * English ratio: 60%
 */
val module14 = Module(
    id = 14,
    titleEn = "Indicators, Baseline, Targets and Means of Verification",
    titleFr = "Indicateurs, situation de référence, cibles et moyens de vérification",
    englishRatio = 0.60f,
    objectiveEn = "By the end of this lesson, you will be able to formulate SMART indicators and explain baseline, target and means of verification in English.",
    objectiveFr = "À la fin de cette leçon, vous serez capable de formuler des indicateurs SMART et d'expliquer la situation de référence, la cible et les moyens de vérification en anglais.",
    vocabulary = listOf(
        VocabItem("m14_indicator", "indicator", "indicateur",
            "A measurable variable used to track progress toward an objective.",
            "Variable mesurable utilisée pour suivre les progrès vers un objectif.",
            "The indicator tracks the percentage of households with access to safe drinking water.", 14),
        VocabItem("m14_baseline", "baseline", "situation de référence",
            "The value of an indicator before project implementation begins, used as a reference point.",
            "La valeur d'un indicateur avant le début de la mise en œuvre du projet, utilisée comme point de référence.",
            "Illustrative example: baseline — 35% of households have access to safe drinking water.", 14),
        VocabItem("m14_target", "target", "cible",
            "The value an indicator is expected to reach by a specified point in the project.",
            "La valeur qu'un indicateur est censé atteindre à un moment donné du projet.",
            "Illustrative example: target — 70% of households will have access to safe drinking water by project end.", 14),
        VocabItem("m14_means_of_verification", "means of verification", "moyens de vérification",
            "The specific source or method used to obtain data for an indicator.",
            "La source ou méthode spécifique utilisée pour obtenir les données d'un indicateur.",
            "Means of verification: household survey and project monitoring records.", 14),
        VocabItem("m14_ovi", "objectively verifiable indicator (OVI)", "indicateur objectivement vérifiable (IOV)",
            "An indicator specified with enough precision that different observers would measure it the same way.",
            "Indicateur précisé avec suffisamment de rigueur pour que différents observateurs le mesurent de la même façon.",
            "The OVI specified exact units, timeframe and population to avoid ambiguity.", 14),
        VocabItem("m14_smart_indicator", "SMART indicator", "indicateur SMART",
            "An indicator that is Specific, Measurable, Achievable, Relevant, and Time-bound.",
            "Indicateur qui est Spécifique, Mesurable, Atteignable, Pertinent et Limité dans le temps.",
            "The team revised the indicator to make it SMART by adding a clear timeframe.", 14),
        VocabItem("m14_quantitative_indicator", "quantitative indicator", "indicateur quantitatif",
            "An indicator expressed in numbers, percentages or ratios.",
            "Indicateur exprimé en chiffres, pourcentages ou ratios.",
            "Number of boreholes rehabilitated is a quantitative indicator.", 14),
        VocabItem("m14_qualitative_indicator", "qualitative indicator", "indicateur qualitatif",
            "An indicator capturing perceptions, quality or experience, often through descriptive categories.",
            "Indicateur saisissant des perceptions, la qualité ou une expérience, souvent via des catégories descriptives.",
            "Perceived improvement in water quality is a qualitative indicator collected through interviews.", 14)
    ),
    collocations = listOf(
        Expression("m14_e1", "to formulate an indicator", "formuler un indicateur",
            "Standard verb-noun collocation for this skill.",
            "The team formulated an indicator specific enough to be measured consistently.", 14),
        Expression("m14_e2", "to establish a baseline", "établir une situation de référence",
            "Common phrase describing the first monitoring step.",
            "The project established a baseline during the first month of implementation.", 14),
        Expression("m14_e3", "to set a realistic target", "fixer une cible réaliste",
            "Frequently discussed in appraisal and donor negotiation.",
            "The team set a realistic target based on similar projects' past performance.", 14),
        Expression("m14_e4", "to track progress against indicators", "suivre les progrès par rapport aux indicateurs",
            "Common phrase for monitoring narrative.",
            "The monitoring system tracks progress against indicators on a quarterly basis.", 14),
        Expression("m14_e5", "to specify the means of verification", "préciser les moyens de vérification",
            "Directly ties to logframe completion.",
            "For each indicator, the logframe specifies the means of verification.", 14)
    ),
    concepts = listOf(
        ConceptCard("m14_c1", "Baseline, target, indicator, means of verification — worked example", "Exemple travaillé : situation de référence, cible, indicateur, moyens de vérification",
            "These four elements must align: the indicator defines what is measured, the baseline is its starting value, the target is its expected end value, and the means of verification is how it will be checked.",
            "Ces quatre éléments doivent être cohérents : l'indicateur définit ce qui est mesuré, la situation de référence est sa valeur de départ, la cible sa valeur attendue en fin de projet, et les moyens de vérification la façon de la contrôler.",
            "Illustrative example: Indicator — % of households with safe drinking water access. Baseline — 35%. Target — 70% by project end. Means of verification — household survey and monitoring records.", true, 14),
        ConceptCard("m14_c2", "SMART criteria", "Critères SMART",
            "SMART indicators avoid vague formulations like 'improve water access' in favor of precise, checkable statements with numbers and timeframes.",
            "Les indicateurs SMART évitent les formulations vagues comme « améliorer l'accès à l'eau » au profit d'énoncés précis et vérifiables, avec chiffres et délais.",
            "A weak indicator — 'water access improves.' A SMART indicator — '% of targeted households with access to safe drinking water within 500m, measured by household survey at midline and endline.'", true, 14)
    ),
    donorQuestions = listOf(
        DonorQuestion("m14_dq1",
            "What is your baseline, and how confident are you in that figure?",
            "Our baseline of 35% water access comes from a household survey conducted before implementation, using the same methodology we will use for the endline, so the two figures will be directly comparable.",
            "Bonne réponse : elle précise la source ET la cohérence méthodologique entre référence et évaluation finale.",
            "baseline", 14),
        DonorQuestion("m14_dq2",
            "How will you verify that you have actually reached your targets?",
            "Each indicator has a specified means of verification — for water access, that is a household survey at midline and endline, cross-checked against our monitoring records of functional water points.",
            "Bonne réponse : elle relie directement l'indicateur à sa méthode de vérification précise.",
            "verification", 14)
    ),
    exercises = listOf(
        Exercise("m14_ex1", ExerciseType.IDENTIFY_INDICATOR,
            "In the sentence 'Percentage of targeted households with access to safe drinking water,' what role does this text play?",
            "Dans la phrase « Pourcentage des ménages ciblés ayant accès à l'eau potable », quel rôle joue ce texte ?",
            listOf("indicator", "baseline", "target", "means of verification"),
            "indicator", "Cette formulation décrit ce qui est mesuré : c'est l'indicateur, pas encore une valeur chiffrée.", 14),
        Exercise("m14_ex2", ExerciseType.MULTIPLE_CHOICE,
            "Which acronym describes an indicator that is Specific, Measurable, Achievable, Relevant, Time-bound?",
            "Quel acronyme désigne un indicateur Spécifique, Mesurable, Atteignable, Pertinent, Limité dans le temps ?",
            listOf("OVI", "SMART", "MARP", "GIS"),
            "SMART", "SMART est l'acronyme standard pour les indicateurs bien formulés.", 14)
    )
)
