package com.nigerdev.englishtraining.data.repository

import com.nigerdev.englishtraining.data.model.*

/**
 * ModuleStub is used for modules whose full content (vocab/expressions/exercises)
 * has not yet been authored. The Learning Path screen shows these as
 * "coming soon" / locked-with-preview cards using just the title pair.
 *
 * TO ADD A NEW MODULE:
 *  1. Create ModuleN Content.kt following Module1Content.kt / Module2Content.kt / Module3Content.kt exactly.
 *  2. Add the resulting `moduleN` object to ContentRepository.fullModules below.
 *  3. Remove its entry from `stubTitles` (or leave it, fullModules takes priority).
 */
data class ModuleStub(val id: Int, val titleEn: String, val titleFr: String)

object ContentRepository {

    // Modules with complete authored content
    val fullModules: List<Module> = listOf(module1, module2, module3, module4, module5, module6, module7, module8, module9, module10, module11, module12, module13, module14, module15, module16, module17, module18, module19, module20, module21, module22, module23, module24, module25)

    // The full 24-module sequence (titles only), per the validated series plan.
    // Entries 1-3 are superseded by fullModules above.
    val allModuleTitles: List<ModuleStub> = listOf(
        ModuleStub(1, "Foundations of Development English", "Les bases de l'anglais du développement"),
        ModuleStub(2, "Understanding Development Problems", "Comprendre les problèmes de développement"),
        ModuleStub(3, "Climate Change, Vulnerability and Resilience", "Changement climatique, vulnérabilité et résilience"),
        ModuleStub(4, "Poverty, Livelihoods and Vulnerable Groups", "Pauvreté, moyens d'existence et groupes vulnérables"),
        ModuleStub(5, "Agriculture, Livestock, Fisheries and Rural Development", "Agriculture, élevage, pêche et développement rural"),
        ModuleStub(6, "Infrastructure, Equipment and Basic Services", "Infrastructures, équipements et services sociaux de base"),
        ModuleStub(7, "Territorial Analysis and Selection of an Intervention Area", "Analyse territoriale et choix d'une zone d'intervention"),
        ModuleStub(8, "Stakeholder Identification and Engagement", "Identification et mobilisation des parties prenantes"),
        ModuleStub(9, "Field Research and Needs Assessment", "Recherche de terrain et évaluation des besoins"),
        ModuleStub(10, "GIS, Remote Sensing and Spatial Evidence", "SIG, télédétection et données spatiales"),
        ModuleStub(11, "From Needs Assessment to Project Identification", "De l'évaluation des besoins à l'identification du projet"),
        ModuleStub(12, "Project Cycle Management", "Gestion du cycle de projet"),
        ModuleStub(13, "Project Design and Logical Framework", "Conception du projet et cadre logique"),
        ModuleStub(14, "Indicators, Baseline, Targets and Means of Verification", "Indicateurs, situation de référence, cibles et moyens de vérification"),
        ModuleStub(15, "Monitoring, Evaluation, Accountability and Learning", "Suivi, évaluation, redevabilité et apprentissage"),
        ModuleStub(16, "Risk Management, Safeguards and Sustainability", "Gestion des risques, sauvegardes et durabilité"),
        ModuleStub(17, "Gender, Inclusion, Human Rights and Do-No-Harm", "Genre, inclusion, droits humains et principe de ne pas nuire"),
        ModuleStub(18, "Project Implementation and Coordination", "Mise en œuvre et coordination du projet"),
        ModuleStub(19, "Project Proposal Writing for Donors", "Rédaction de propositions de projets pour les bailleurs"),
        ModuleStub(20, "Presenting a Development Project to Donors", "Présentation d'un projet de développement aux bailleurs"),
        ModuleStub(21, "Donor Questions, Defense and Professional Discussion", "Questions des bailleurs, défense du projet et discussion professionnelle"),
        ModuleStub(22, "Negotiation with Donors and Professional Diplomacy", "Négociation avec les bailleurs et diplomatie professionnelle"),
        ModuleStub(23, "Reporting, Emails and Professional Correspondence", "Rapports, courriels et correspondance professionnelle"),
        ModuleStub(24, "Advanced Professional Communication and Executive English", "Communication professionnelle avancée et anglais exécutif"),
        ModuleStub(25, "Presenting Socio-Economic Data", "Présentation des données socio-économiques")
    )

    fun moduleById(id: Int): Module? = fullModules.find { it.id == id }

    fun isModuleAuthored(id: Int): Boolean = fullModules.any { it.id == id }

    fun allVocabulary(): List<VocabItem> = fullModules.flatMap { it.vocabulary }
    fun allExpressions(): List<Expression> = fullModules.flatMap { it.collocations }
    fun allConcepts(): List<ConceptCard> = fullModules.flatMap { it.concepts }
    fun allDonorQuestions(): List<DonorQuestion> = fullModules.flatMap { it.donorQuestions }
    fun allExercises(): List<Exercise> = fullModules.flatMap { it.exercises }

    fun search(query: String): SearchResults {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return SearchResults()
        return SearchResults(
            vocabulary = allVocabulary().filter {
                it.english.lowercase().contains(q) || it.french.lowercase().contains(q)
            },
            expressions = allExpressions().filter {
                it.english.lowercase().contains(q) || it.french.lowercase().contains(q)
            },
            concepts = allConcepts().filter {
                it.titleEn.lowercase().contains(q) || it.titleFr.lowercase().contains(q)
            },
            donorQuestions = allDonorQuestions().filter {
                it.questionEn.lowercase().contains(q)
            }
        )
    }
}

data class SearchResults(
    val vocabulary: List<VocabItem> = emptyList(),
    val expressions: List<Expression> = emptyList(),
    val concepts: List<ConceptCard> = emptyList(),
    val donorQuestions: List<DonorQuestion> = emptyList()
) {
    val isEmpty: Boolean
        get() = vocabulary.isEmpty() && expressions.isEmpty() && concepts.isEmpty() && donorQuestions.isEmpty()
}
