package com.nigerdev.englishtraining.data.model

/**
 * These are static content models (bundled with the app, not persisted in Room).
 * Room is used only for the learner's dynamic state: progress, quiz scores,
 * saved vocabulary, review intervals. See data/db for that layer.
 *
 * IMPORTANT for future module authors: every module 4-24 must populate a
 * `Module` object following exactly this shape. This is the single template
 * for the whole 24-module series.
 */

data class Module(
    val id: Int,                       // 1..24
    val titleEn: String,
    val titleFr: String,
    val englishRatio: Float,           // 0.40 / 0.60 / 0.80 per the beginner/intermediate/advanced progression
    val objectiveEn: String,
    val objectiveFr: String,
    val vocabulary: List<VocabItem>,
    val collocations: List<Expression>,
    val concepts: List<ConceptCard>,
    val methodologySteps: List<MethodologyItem> = emptyList(),
    val donorQuestions: List<DonorQuestion> = emptyList(),
    val exercises: List<Exercise> = emptyList()
)

data class VocabItem(
    val id: String,                    // stable id, e.g. "m1_vulnerability"
    val english: String,
    val french: String,
    val definitionEn: String,
    val explanationFr: String,
    val exampleEn: String,
    val moduleId: Int
)

data class Expression(
    val id: String,
    val english: String,               // e.g. "conduct a needs assessment"
    val french: String,
    val explanationFr: String,
    val exampleEn: String,
    val moduleId: Int
)

data class ConceptCard(
    val id: String,
    val titleEn: String,
    val titleFr: String,
    val explanationEn: String,
    val explanationFr: String,
    val nigerExampleEn: String,
    val isIllustrativeExample: Boolean = true,
    val moduleId: Int
)

data class MethodologyItem(
    val id: String,
    val nameEn: String,                // e.g. "Key informant interview"
    val nameFr: String,
    val whatEn: String,
    val whyEn: String,
    val howEn: String,
    val whoEn: String,
    val dataCollectedEn: String,
    val useOfInformationEn: String,
    val moduleId: Int
)

data class DonorQuestion(
    val id: String,
    val questionEn: String,
    val modelAnswerEn: String,
    val explanationFr: String,         // why this answer works, in French
    val category: String,              // "area selection", "indicators", "sustainability" ...
    val moduleId: Int
)

enum class ExerciseType {
    MULTIPLE_CHOICE, TRANSLATION_EN_FR, TRANSLATION_FR_EN, FILL_BLANK,
    MATCH_PAIRS, SENTENCE_CORRECTION, CHOOSE_EXPRESSION, IDENTIFY_INDICATOR
}

data class Exercise(
    val id: String,
    val type: ExerciseType,
    val promptEn: String,
    val promptFr: String? = null,
    val options: List<String> = emptyList(),
    val correctAnswer: String,
    val explanationFr: String,
    val moduleId: Int
)
