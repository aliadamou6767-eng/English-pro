package com.nigerdev.englishtraining.ui.screens.settings

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nigerdev.englishtraining.AppContainer
import com.nigerdev.englishtraining.data.repository.AppSettings
import com.nigerdev.englishtraining.data.repository.EnglishVoice
import com.nigerdev.englishtraining.data.repository.TextSize
import kotlinx.coroutines.launch
import java.util.Locale

@Composable
fun SettingsScreen(appContainer: AppContainer) {
    val settings by appContainer.settingsRepository.settingsFlow.collectAsState(initial = AppSettings())
    val scope = rememberCoroutineScope()
    var showResetConfirm by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Paramètres", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(16.dp))

        Text("Speech rate · Vitesse de lecture", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Row {
            listOf(0.70f to "0.70x Slow", 1.00f to "1.00x Normal", 1.20f to "1.20x Fast").forEach { (rate, label) ->
                FilterChip(
                    selected = settings.speechRate == rate,
                    onClick = {
                        scope.launch { appContainer.settingsRepository.setSpeechRate(rate) }
                        appContainer.ttsManager.setSpeechRate(rate)
                    },
                    label = { Text(label) },
                    modifier = Modifier.padding(end = 6.dp)
                )
            }
        }

        Spacer(Modifier.height(20.dp))
        Text("English pronunciation · Prononciation", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Row {
            listOf(EnglishVoice.US to "English (US)", EnglishVoice.UK to "English (UK)", EnglishVoice.DEVICE_DEFAULT to "Device voice").forEach { (voice, label) ->
                FilterChip(
                    selected = settings.englishVoice == voice,
                    onClick = {
                        scope.launch { appContainer.settingsRepository.setVoice(voice) }
                        val locale = when (voice) {
                            EnglishVoice.US -> Locale.US
                            EnglishVoice.UK -> Locale.UK
                            EnglishVoice.DEVICE_DEFAULT -> Locale.getDefault()
                        }
                        appContainer.ttsManager.setVoiceLocale(locale)
                    },
                    label = { Text(label) },
                    modifier = Modifier.padding(end = 6.dp)
                )
            }
        }

        Spacer(Modifier.height(20.dp))
        Text("Text size · Taille du texte", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Row {
            listOf(TextSize.SMALL to "Small", TextSize.MEDIUM to "Medium", TextSize.LARGE to "Large").forEach { (size, label) ->
                FilterChip(
                    selected = settings.textSize == size,
                    onClick = { scope.launch { appContainer.settingsRepository.setTextSize(size) } },
                    label = { Text(label) },
                    modifier = Modifier.padding(end = 6.dp)
                )
            }
        }

        Spacer(Modifier.height(20.dp))
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Dark mode · Mode sombre", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Switch(
                checked = settings.darkMode,
                onCheckedChange = { scope.launch { appContainer.settingsRepository.setDarkMode(it) } }
            )
        }

        Spacer(Modifier.height(32.dp))
        OutlinedButton(
            onClick = { showResetConfirm = true },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
        ) { Text("Reset progress · Réinitialiser la progression") }

        if (showResetConfirm) {
            AlertDialog(
                onDismissRequest = { showResetConfirm = false },
                title = { Text("Reset all progress?") },
                text = { Text("This will erase completed modules, saved vocabulary, quiz scores, and donor simulation history. This cannot be undone.\n\nCeci effacera votre progression, votre vocabulaire enregistré et vos scores. Cette action est irréversible.") },
                confirmButton = {
                    TextButton(onClick = {
                        scope.launch { appContainer.progressRepository.resetAllProgress() }
                        showResetConfirm = false
                    }) { Text("Reset") }
                },
                dismissButton = {
                    TextButton(onClick = { showResetConfirm = false }) { Text("Cancel") }
                }
            )
        }
    }
}
