package com.nigerdev.englishtraining.data.repository

import com.nigerdev.englishtraining.data.model.*

/**
 * MODULE 15 — Monitoring, Evaluation, Accountability and Learning
 * Suivi, évaluation, redevabilité et apprentissage
 * English ratio: 60%
 */
val module15 = Module(
    id = 15,
    titleEn = "Monitoring, Evaluation, Accountability and Learning",
    titleFr = "Suivi, évaluation, redevabilité et apprentissage",
    englishRatio = 0.60f,
    objectiveEn = "By the end of this lesson, you will be able to explain MEAL systems and distinguish monitoring from evaluation in English.",
    objectiveFr = "À la fin de cette leçon, vous serez capable d'expliquer les systèmes MEAL et de distinguer le suivi de l'évaluation en anglais.",
    vocabulary = listOf(
        VocabItem("m15_monitoring", "monitoring", "suivi",
            "The continuous, routine tracking of project activities and indicators during implementation.",
            "Le suivi continu et routinier des activités et indicateurs du projet pendant la mise en œuvre.",
            "Monthly monitoring visits verified that boreholes remained functional.", 15),
        VocabItem("m15_evaluation", "evaluation", "évaluation",
            "A periodic, more in-depth assessment of a project's relevance, effectiveness, and results.",
            "Une évaluation périodique et plus approfondie de la pertinence, de l'efficacité et des résultats d'un projet.",
            "The mid-term evaluation assessed whether the project remained on track to meet its targets.", 15),
        VocabItem("m15_accountability", "accountability", "redevabilité",
            "The obligation to report on and take responsibility for a project's use of resources and results, including to affected communities.",
            "L'obligation de rendre compte et d'assumer la responsabilité de l'utilisation des ressources et des résultats d'un projet, y compris envers les communautés affectées.",
            "Accountability to affected populations includes sharing results in accessible, local-language formats.", 15),
        VocabItem("m15_lessons_learned", "lessons learned", "leçons apprises",
            "Insights drawn from project experience, intended to inform future design and decision-making.",
            "Enseignements tirés de l'expérience d'un projet, destinés à éclairer la conception et les décisions futures.",
            "Lessons learned from the pilot phase informed the scale-up strategy.", 15),
        VocabItem("m15_data_quality", "data quality", "qualité des données",
            "The accuracy, completeness, and reliability of data collected for monitoring and evaluation.",
            "L'exactitude, l'exhaustivité et la fiabilité des données collectées pour le suivi-évaluation.",
            "A data quality audit found minor inconsistencies in the field-collected survey data.", 15),
        VocabItem("m15_mid_term_review", "mid-term review", "revue à mi-parcours",
            "An assessment conducted partway through a project to check progress and adjust course if needed.",
            "Une évaluation menée à mi-chemin d'un projet pour vérifier les progrès et ajuster si nécessaire.",
            "The mid-term review recommended revising the targeting criteria.", 15),
        VocabItem("m15_feedback_loop", "feedback loop", "boucle de rétroaction",
            "A mechanism ensuring that monitoring findings are used to adjust project implementation.",
            "Un mécanisme garantissant que les résultats du suivi soient utilisés pour ajuster la mise en œuvre du projet.",
            "A functioning feedback loop allowed field data to influence programming decisions within weeks.", 15)
    ),
    collocations = listOf(
        Expression("m15_e1", "to monitor project performance", "suivre la performance du projet",
            "Very common phrase for describing routine tracking.",
            "The team monitors project performance against indicators on a monthly basis.", 15),
        Expression("m15_e2", "to conduct a mid-term evaluation", "réaliser une évaluation à mi-parcours",
            "Standard phrase for a scheduled evaluation milestone.",
            "An independent consultant will conduct the mid-term evaluation in month eighteen.", 15),
        Expression("m15_e3", "to be accountable to communities", "être redevable envers les communautés",
            "Reflects the accountability dimension of MEAL, beyond donor reporting.",
            "The project is accountable to communities through regular feedback sessions.", 15),
        Expression("m15_e4", "to feed lessons learned into design", "intégrer les leçons apprises dans la conception",
            "Links monitoring findings back to programming — a valued practice by donors.",
            "The team fed lessons learned from year one into the year-two workplan.", 15),
        Expression("m15_e5", "to ensure data quality", "garantir la qualité des données",
            "Frequently expected in MEAL sections of proposals.",
            "Spot-checks and back-checks help ensure data quality throughout the survey.", 15)
    ),
    concepts = listOf(
        ConceptCard("m15_c1", "Monitoring vs. evaluation", "Suivi vs. évaluation",
            "Monitoring is continuous and operational — tracking whether activities happen as planned. Evaluation is periodic and analytical — asking whether the project is achieving, and will achieve, its intended results.",
            "Le suivi est continu et opérationnel — il vérifie si les activités se déroulent comme prévu. L'évaluation est périodique et analytique — elle interroge si le projet atteint, et atteindra, ses résultats visés.",
            "In an illustrative example, monthly monitoring confirmed boreholes were being drilled on schedule, while the mid-term evaluation asked whether access to water was actually changing household behavior.", true, 15),
        ConceptCard("m15_c2", "Accountability to affected populations (AAP)", "Redevabilité envers les populations affectées",
            "AAP means communities have a genuine voice in how a project is run, including complaint mechanisms and transparent sharing of results — not only being a source of data for the project.",
            "La redevabilité envers les populations affectées signifie que les communautés ont une réelle voix dans la conduite d'un projet, y compris des mécanismes de plainte et un partage transparent des résultats — pas seulement une source de données pour le projet.",
            "An illustrative AAP practice: results of the household survey were shared back with communities in a village meeting before the final donor report was submitted.", true, 15)
    ),
    donorQuestions = listOf(
        DonorQuestion("m15_dq1",
            "How is your monitoring system different from your evaluation plan?",
            "Monitoring is continuous — our field teams track indicators monthly and report on activity implementation — while evaluation is periodic, with an independent mid-term and final evaluation assessing whether the project logic is holding and results are being achieved.",
            "Bonne réponse : elle distingue clairement fréquence et objectif du suivi vs. de l'évaluation.",
            "MEAL system", 15),
        DonorQuestion("m15_dq2",
            "How do communities have a voice in how this project is monitored and adjusted?",
            "Communities participate through quarterly feedback sessions and a complaints mechanism, and their input has already led to one adjustment in our activity schedule during the pilot phase.",
            "Bonne réponse : elle donne un exemple concret d'ajustement réel, pas seulement une déclaration d'intention.",
            "accountability", 15)
    ),
    exercises = listOf(
        Exercise("m15_ex1", ExerciseType.MULTIPLE_CHOICE,
            "Which term describes the continuous, routine tracking of project activities?",
            "Quel terme désigne le suivi continu et routinier des activités d'un projet ?",
            listOf("evaluation", "monitoring", "lessons learned", "accountability"),
            "monitoring", "« Monitoring » = suivi continu, distinct de l'évaluation périodique.", 15),
        Exercise("m15_ex2", ExerciseType.FILL_BLANK,
            "The team fed ______ from year one into the year-two workplan.", null,
            listOf("lessons learned", "data quality", "accountability", "feedback loop"),
            "lessons learned",
            "« Feed lessons learned into » est la collocation correcte.", 15)
    )
)
