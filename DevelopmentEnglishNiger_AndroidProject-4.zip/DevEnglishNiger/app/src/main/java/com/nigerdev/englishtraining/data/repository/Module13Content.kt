package com.nigerdev.englishtraining.data.repository

import com.nigerdev.englishtraining.data.model.*

/**
 * MODULE 13 — Project Design and Logical Framework
 * Conception du projet et cadre logique
 * English ratio: 60%
 */
val module13 = Module(
    id = 13,
    titleEn = "Project Design and Logical Framework",
    titleFr = "Conception du projet et cadre logique",
    englishRatio = 0.60f,
    objectiveEn = "By the end of this lesson, you will be able to explain the logical framework and the results chain in English.",
    objectiveFr = "À la fin de cette leçon, vous serez capable d'expliquer le cadre logique et la chaîne de résultats en anglais.",
    vocabulary = listOf(
        VocabItem("m13_logical_framework", "logical framework (logframe)", "cadre logique",
            "A matrix summarizing a project's objectives, results, indicators, means of verification and assumptions.",
            "Matrice résumant les objectifs, résultats, indicateurs, moyens de vérification et hypothèses d'un projet.",
            "The logical framework clearly linked activities to expected outcomes.", 13),
        VocabItem("m13_activity", "activity", "activité",
            "A specific action undertaken using project resources to produce outputs.",
            "Action spécifique entreprise avec les ressources du projet pour produire des extrants.",
            "Training community animators was one of the project's key activities.", 13),
        VocabItem("m13_output", "output", "extrant / produit",
            "The immediate, direct result of project activities, within the project's control.",
            "Le résultat immédiat et direct des activités du projet, sous le contrôle du projet.",
            "200 farmers trained in climate-smart techniques was a project output.", 13),
        VocabItem("m13_outcome", "outcome", "effet / résultat intermédiaire",
            "The medium-term change resulting from outputs, often influenced by factors beyond the project's full control.",
            "Le changement à moyen terme résultant des extrants, souvent influencé par des facteurs hors du contrôle total du projet.",
            "Increased adoption of climate-smart practices was the expected outcome.", 13),
        VocabItem("m13_impact", "impact", "impact",
            "The long-term, broader change to which the project contributes, alongside other factors.",
            "Le changement à long terme et plus large auquel le projet contribue, aux côtés d'autres facteurs.",
            "Improved household food security was the project's intended long-term impact.", 13),
        VocabItem("m13_assumption", "assumption", "hypothèse",
            "An external condition that must hold true for the project's logic to work, but which the project does not control.",
            "Condition externe qui doit se vérifier pour que la logique du projet fonctionne, mais que le projet ne contrôle pas.",
            "A key assumption was that rainfall would not fall below the ten-year average.", 13),
        VocabItem("m13_results_chain", "results chain", "chaîne de résultats",
            "The logical sequence from activities through outputs and outcomes to impact.",
            "La séquence logique des activités aux extrants, aux effets, jusqu'à l'impact.",
            "The results chain showed how training activities were expected to lead to improved yields.", 13)
    ),
    collocations = listOf(
        Expression("m13_e1", "to build a logical framework", "élaborer un cadre logique",
            "The core design activity of this module.",
            "The design team built a logical framework during a two-day workshop.", 13),
        Expression("m13_e2", "to link activities to outcomes", "relier les activités aux effets",
            "Describes the essential coherence check in project design.",
            "Each activity must clearly link to outcomes in the results chain.", 13),
        Expression("m13_e3", "to state underlying assumptions", "énoncer les hypothèses sous-jacentes",
            "Frequently required in logframe columns and donor templates.",
            "The proposal states underlying assumptions about market access and rainfall.", 13),
        Expression("m13_e4", "to distinguish outputs from outcomes", "distinguer les extrants des effets",
            "A common point of confusion the module directly addresses.",
            "It is important to distinguish outputs, which the project controls, from outcomes, which it influences.", 13),
        Expression("m13_e5", "to contribute to impact", "contribuer à l'impact",
            "Careful phrasing avoiding overclaiming attribution for long-term impact.",
            "The project contributes to impact alongside government and other partners' efforts.", 13)
    ),
    concepts = listOf(
        ConceptCard("m13_c1", "The results chain", "La chaîne de résultats",
            "The results chain moves from Activities → Outputs → Outcomes → Impact, with control decreasing and time horizon lengthening at each step.",
            "La chaîne de résultats va des Activités → Extrants → Effets → Impact, avec un contrôle décroissant et un horizon temporel croissant à chaque étape.",
            "In an illustrative Tillabéri water project: activity = drilling boreholes; output = functional water points; outcome = reduced water collection time; impact = improved household wellbeing.", true, 13),
        ConceptCard("m13_c2", "Outputs vs. outcomes — a frequent confusion", "Extrants vs. effets — une confusion fréquente",
            "An output is something a project directly produces and controls; an outcome is a behavioral or condition change that the output makes possible but does not guarantee.",
            "Un extrant est quelque chose que le projet produit et contrôle directement ; un effet est un changement de comportement ou de condition que l'extrant rend possible sans le garantir.",
            "Training 200 farmers is an output; those farmers actually adopting new techniques is the outcome — the project cannot fully control the second.", true, 13)
    ),
    donorQuestions = listOf(
        DonorQuestion("m13_dq1",
            "Can you walk us through your results chain, from activities to impact?",
            "Certainly: our main activity is training and input distribution, which produces the output of farmers equipped with drought-tolerant seed, leading to the outcome of improved yields, contributing to the impact of improved household food security.",
            "Bonne réponse : elle suit la chaîne dans l'ordre, sans sauter d'étape, ce qui montre une logique de projet solide.",
            "results chain", 13),
        DonorQuestion("m13_dq2",
            "What assumptions does your project logic depend on?",
            "The main assumption is that rainfall will not fall significantly below the ten-year average; if it does, we have a contingency plan involving supplementary irrigation support.",
            "Bonne réponse : elle nomme une hypothèse claire ET une réponse au risque, ce qui rassure les bailleurs sur l'anticipation des risques.",
            "assumptions", 13)
    ),
    exercises = listOf(
        Exercise("m13_ex1", ExerciseType.MULTIPLE_CHOICE,
            "Which term describes the immediate, direct result of project activities?",
            "Quel terme désigne le résultat immédiat et direct des activités d'un projet ?",
            listOf("outcome", "output", "impact", "assumption"),
            "output", "« Output » = extrant direct, sous contrôle du projet.", 13),
        Exercise("m13_ex2", ExerciseType.MATCH_PAIRS,
            "Match each stage of the results chain with its French translation.", null,
            listOf("activity=activité", "output=extrant", "outcome=effet", "impact=impact"),
            "activity=activité;output=extrant;outcome=effet;impact=impact",
            "Ces quatre termes forment la chaîne de résultats complète.", 13)
    )
)
