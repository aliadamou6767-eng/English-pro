package com.nigerdev.englishtraining.data.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {

    // --- Module progress ---
    @Query("SELECT * FROM module_progress")
    fun observeModuleProgress(): Flow<List<ModuleProgressEntity>>

    @Query("SELECT * FROM module_progress WHERE moduleId = :moduleId")
    suspend fun getModuleProgress(moduleId: Int): ModuleProgressEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertModuleProgress(progress: ModuleProgressEntity)

    // --- Saved vocabulary ("My Vocabulary") ---
    @Query("SELECT * FROM saved_vocabulary ORDER BY savedTimestamp DESC")
    fun observeSavedVocabulary(): Flow<List<SavedVocabularyEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveVocabulary(item: SavedVocabularyEntity)

    @Query("DELETE FROM saved_vocabulary WHERE vocabId = :vocabId")
    suspend fun removeSavedVocabulary(vocabId: String)

    @Query("SELECT EXISTS(SELECT 1 FROM saved_vocabulary WHERE vocabId = :vocabId)")
    fun isVocabularySaved(vocabId: String): Flow<Boolean>

    // --- Spaced review ---
    @Query("SELECT * FROM review_state WHERE vocabId = :vocabId")
    suspend fun getReviewState(vocabId: String): ReviewStateEntity?

    @Query("SELECT * FROM review_state WHERE nextDueTimestamp <= :now ORDER BY nextDueTimestamp ASC")
    suspend fun getDueReviews(now: Long): List<ReviewStateEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertReviewState(state: ReviewStateEntity)

    // --- Donor simulation ---
    @Insert
    suspend fun logDonorSimulation(entry: DonorSimulationLogEntity)

    @Query("SELECT COUNT(DISTINCT donorQuestionId) FROM donor_simulation_log")
    fun observeDonorSimCompletedCount(): Flow<Int>

    // --- Practice sessions ---
    @Insert
    suspend fun logPracticeSession(entry: PracticeSessionEntity)

    @Query("SELECT COUNT(*) FROM practice_session_log")
    fun observePracticeSessionCount(): Flow<Int>

    // --- Aggregate helpers for Home / Progress screens ---
    @Query("SELECT COUNT(*) FROM module_progress WHERE isCompleted = 1")
    fun observeCompletedModuleCount(): Flow<Int>

    @Query("DELETE FROM module_progress")
    suspend fun clearModuleProgress()

    @Query("DELETE FROM saved_vocabulary")
    suspend fun clearSavedVocabulary()

    @Query("DELETE FROM review_state")
    suspend fun clearReviewState()

    @Query("DELETE FROM donor_simulation_log")
    suspend fun clearDonorLog()

    @Query("DELETE FROM practice_session_log")
    suspend fun clearPracticeLog()
}
