package com.nigerdev.englishtraining.data.repository

import com.nigerdev.englishtraining.data.model.*

/**
 * MODULE 19 — Project Proposal Writing for Donors
 * Rédaction de propositions de projets pour les bailleurs
 * English ratio: 70% (advanced begins)
 */
val module19 = Module(
    id = 19,
    titleEn = "Project Proposal Writing for Donors",
    titleFr = "Rédaction de propositions de projets pour les bailleurs",
    englishRatio = 0.70f,
    objectiveEn = "By the end of this lesson, you will be able to write clear, professional sections of a donor proposal in English.",
    objectiveFr = "À la fin de cette leçon, vous serez capable de rédiger des sections claires et professionnelles d'une proposition de projet destinée à un bailleur, en anglais.",
    vocabulary = listOf(
        VocabItem("m19_executive_summary", "executive summary", "résumé exécutif",
            "A concise overview of a proposal's key points, written to be understood without reading the full document.",
            "Aperçu concis des points clés d'une proposition, rédigé pour être compris sans lire le document complet.",
            "The executive summary highlighted the project's objective, target group and requested budget.", 19),
        VocabItem("m19_call_for_proposals", "call for proposals", "appel à propositions",
            "A donor's public invitation for organizations to submit project proposals for funding.",
            "Invitation publique d'un bailleur aux organisations à soumettre des propositions de projet pour financement.",
            "The organization responded to a call for proposals focused on climate resilience.", 19),
        VocabItem("m19_eligibility_criteria", "eligibility criteria", "critères d'éligibilité",
            "The conditions an organization or project must meet to qualify for funding.",
            "Conditions qu'une organisation ou un projet doit remplir pour être éligible à un financement.",
            "The proposal confirmed the organization met all eligibility criteria before submission.", 19),
        VocabItem("m19_budget_narrative", "budget narrative", "note budgétaire",
            "A written explanation justifying each budget line in a proposal.",
            "Explication écrite justifiant chaque ligne budgétaire d'une proposition.",
            "The budget narrative explained why vehicle costs were shared across two project components.", 19),
        VocabItem("m19_compliance", "compliance", "conformité",
            "Adherence to a donor's specific formatting, content and procedural requirements.",
            "Respect des exigences spécifiques de format, de contenu et de procédure d'un bailleur.",
            "A compliance check confirmed the proposal met the donor's page limit and annex requirements.", 19),
        VocabItem("m19_added_value", "added value", "valeur ajoutée",
            "The distinct benefit or advantage an organization or approach brings compared to alternatives.",
            "L'avantage ou le bénéfice distinct qu'apporte une organisation ou une approche par rapport aux alternatives.",
            "The proposal emphasized the organization's added value through its established community relationships.", 19)
    ),
    collocations = listOf(
        Expression("m19_e1", "to respond to a call for proposals", "répondre à un appel à propositions",
            "The starting action of proposal development.",
            "The team responded to a call for proposals within the six-week deadline.", 19),
        Expression("m19_e2", "to meet eligibility criteria", "remplir les critères d'éligibilité",
            "Common early-stage compliance phrase.",
            "The organization confirmed it met eligibility criteria before drafting the proposal.", 19),
        Expression("m19_e3", "to draft a compelling narrative", "rédiger un récit convaincant",
            "Refers to the persuasive writing quality expected in proposals.",
            "The team drafted a compelling narrative supported by assessment evidence.", 19),
        Expression("m19_e4", "to justify budget lines", "justifier les lignes budgétaires",
            "Standard phrase for the financial section.",
            "The budget narrative justified each budget line with a clear rationale.", 19),
        Expression("m19_e5", "to submit a proposal for review", "soumettre une proposition pour examen",
            "Common in the final stage of proposal preparation.",
            "The finance and programme teams submitted the proposal for review before the deadline.", 19)
    ),
    concepts = listOf(
        ConceptCard("m19_c1", "Anatomy of a donor proposal", "Anatomie d'une proposition destinée à un bailleur",
            "A typical proposal includes: executive summary, problem statement, target population, methodology, logical framework, risk matrix, budget and budget narrative, and organizational capacity — each donor's template varies but this core structure recurs.",
            "Une proposition type comprend : résumé exécutif, énoncé du problème, population cible, méthodologie, cadre logique, matrice des risques, budget et note budgétaire, et capacité organisationnelle — le gabarit varie selon le bailleur mais cette structure de base revient souvent.",
            "An illustrative AFD-funded proposal in Niger followed this structure with an added section on alignment with national strategy (Initiative 3N, PDC).", true, 19),
        ConceptCard("m19_c2", "Writing for a donor reader", "Écrire pour un lecteur bailleur",
            "Donor readers often review many proposals quickly: lead with the strongest evidence and clearest logic first, avoid unexplained acronyms, and make every claim traceable to a source.",
            "Les lecteurs bailleurs examinent souvent de nombreuses propositions rapidement : commencez par la preuve la plus solide et la logique la plus claire, évitez les acronymes non expliqués, et rendez chaque affirmation traçable à une source.",
            "An illustrative revision replaced 'the situation is very difficult' with 'a household survey found that 42% of households face food insecurity during the lean season.'", true, 19)
    ),
    donorQuestions = listOf(
        DonorQuestion("m19_dq1",
            "What makes your organization particularly well-placed to implement this project?",
            "Our organization has worked in this commune for six years, has established relationships with local authorities and communities, and our field team already has the language and cultural knowledge needed for effective implementation.",
            "Bonne réponse : elle donne des éléments concrets de valeur ajoutée plutôt qu'une affirmation générale de compétence.",
            "added value", 19)
    ),
    exercises = listOf(
        Exercise("m19_ex1", ExerciseType.MULTIPLE_CHOICE,
            "Which section gives a concise overview of a proposal's key points?",
            "Quelle section donne un aperçu concis des points clés d'une proposition ?",
            listOf("budget narrative", "executive summary", "eligibility criteria", "compliance"),
            "executive summary", "Le résumé exécutif synthétise les points clés en tête de proposition.", 19),
        Exercise("m19_ex2", ExerciseType.SENTENCE_CORRECTION,
            "Correct this sentence for a proposal: 'The situation is very difficult for the people there.'",
            "Corrigez cette phrase pour une proposition : « La situation est très difficile pour les gens là-bas. »",
            emptyList(),
            "A household survey found that 42% of households face food insecurity during the lean season.",
            "Remplacez les affirmations vagues par des données précises et sourcées — c'est un principe central de la rédaction pour bailleurs.", 19)
    )
)
