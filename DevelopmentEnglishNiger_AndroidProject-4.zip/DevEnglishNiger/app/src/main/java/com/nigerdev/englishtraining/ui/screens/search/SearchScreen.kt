package com.nigerdev.englishtraining.ui.screens.search

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nigerdev.englishtraining.AppContainer
import com.nigerdev.englishtraining.data.repository.ContentRepository
import com.nigerdev.englishtraining.ui.components.AudioSentence

@Composable
fun SearchScreen(appContainer: AppContainer) {
    var query by remember { mutableStateOf("") }
    val results = remember(query) { ContentRepository.search(query) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Search", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            placeholder = { Text("Search words, expressions, concepts, donor questions…") },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            singleLine = true
        )

        if (query.isBlank()) return@Column

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (results.vocabulary.isNotEmpty()) {
                item { SectionLabel("Vocabulary") }
                items(results.vocabulary) { v ->
                    ResultCard { AudioSentence(v.english, appContainer.ttsManager); Text(v.french) }
                }
            }
            if (results.expressions.isNotEmpty()) {
                item { SectionLabel("Expressions") }
                items(results.expressions) { e ->
                    ResultCard { AudioSentence(e.english, appContainer.ttsManager); Text(e.french) }
                }
            }
            if (results.concepts.isNotEmpty()) {
                item { SectionLabel("Concepts") }
                items(results.concepts) { c ->
                    ResultCard { Text("${c.titleEn} / ${c.titleFr}", fontWeight = FontWeight.SemiBold) }
                }
            }
            if (results.donorQuestions.isNotEmpty()) {
                item { SectionLabel("Donor questions") }
                items(results.donorQuestions) { d ->
                    ResultCard { AudioSentence(d.questionEn, appContainer.ttsManager) }
                }
            }
            if (results.isEmpty) {
                item { Text("No results yet for “$query”.") }
            }
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
}

@Composable
private fun ResultCard(content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), content = content)
    }
}
