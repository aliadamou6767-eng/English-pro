package com.nigerdev.englishtraining.data.repository

import com.nigerdev.englishtraining.data.model.*

/**
 * MODULE 5 — Agriculture, Livestock, Fisheries and Rural Development
 * Agriculture, élevage, pêche et développement rural
 * English ratio: 50% (beginner/intermediate transition)
 */
val module5 = Module(
    id = 5,
    titleEn = "Agriculture, Livestock, Fisheries and Rural Development",
    titleFr = "Agriculture, élevage, pêche et développement rural",
    englishRatio = 0.50f,
    objectiveEn = "By the end of this lesson, you will be able to discuss agricultural, pastoral and rural development issues in professional English.",
    objectiveFr = "À la fin de cette leçon, vous serez capable de discuter des enjeux agricoles, pastoraux et de développement rural en anglais professionnel.",
    vocabulary = listOf(
        VocabItem("m5_rain_fed_agriculture", "rain-fed agriculture", "agriculture pluviale",
            "Farming that depends entirely on rainfall rather than irrigation.",
            "Agriculture qui dépend entièrement des précipitations plutôt que de l'irrigation.",
            "Rain-fed agriculture remains dominant in the Maradi and Zinder regions.", 5),
        VocabItem("m5_irrigated_perimeter", "irrigated perimeter", "périmètre irrigué",
            "A defined area equipped with infrastructure to deliver water for crop production.",
            "Zone délimitée équipée d'infrastructures permettant d'irriguer les cultures.",
            "The irrigated perimeter along the Niger River supports off-season vegetable production.", 5),
        VocabItem("m5_transhumance", "transhumance", "transhumance",
            "The seasonal movement of livestock and herders between pasture areas.",
            "Déplacement saisonnier du bétail et des éleveurs entre zones de pâturage.",
            "Transhumance corridors must remain open for herders moving south during the dry season.", 5),
        VocabItem("m5_pastoralist", "pastoralist", "pasteur / éleveur pastoral",
            "A person whose livelihood is based primarily on raising livestock, often with mobility.",
            "Personne dont les moyens d'existence reposent principalement sur l'élevage, souvent avec mobilité.",
            "Pastoralists in the region rely on customary grazing rights along migration routes.", 5),
        VocabItem("m5_agropastoral", "agropastoral", "agropastoral",
            "Combining crop farming and livestock rearing within the same livelihood system.",
            "Combinant agriculture et élevage au sein d'un même système de subsistance.",
            "Most households in the intervention zone follow an agropastoral livelihood system.", 5),
        VocabItem("m5_yield", "crop yield", "rendement agricole",
            "The quantity of a crop produced per unit of cultivated area.",
            "Quantité d'une culture produite par unité de surface cultivée.",
            "Millet yields declined by an estimated 20% following the erratic rainy season.", 5),
        VocabItem("m5_fodder", "fodder", "fourrage",
            "Plant material, especially grass or hay, fed to livestock.",
            "Matière végétale, notamment herbe ou foin, donnée au bétail.",
            "Fodder shortages during the dry season weaken livestock body condition.", 5),
        VocabItem("m5_value_chain", "value chain", "chaîne de valeur",
            "The full sequence of activities, from production to consumer, that adds value to a product.",
            "L'ensemble des activités, de la production au consommateur, qui ajoutent de la valeur à un produit.",
            "The project strengthens the cowpea value chain from production to local markets.", 5)
    ),
    collocations = listOf(
        Expression("m5_e1", "to improve agricultural productivity", "améliorer la productivité agricole",
            "Standard phrase for agricultural project objectives.",
            "The programme aims to improve agricultural productivity through improved seed varieties.", 5),
        Expression("m5_e2", "to support pastoral livelihoods", "soutenir les moyens d'existence pastoraux",
            "Used when describing interventions benefiting herding communities.",
            "The project supports pastoral livelihoods through animal health services.", 5),
        Expression("m5_e3", "to secure transhumance corridors", "sécuriser les couloirs de transhumance",
            "A frequent phrase in land-use and conflict-prevention contexts.",
            "Local authorities worked to secure transhumance corridors ahead of the dry season.", 5),
        Expression("m5_e4", "to diversify agricultural production", "diversifier la production agricole",
            "Refers to reducing reliance on a single crop.",
            "Farmers are encouraged to diversify agricultural production to manage climate risk.", 5),
        Expression("m5_e5", "to strengthen the value chain", "renforcer la chaîne de valeur",
            "Common in market-linkage and economic-development components.",
            "The intervention strengthens the value chain from farm gate to regional markets.", 5),
        Expression("m5_e6", "to restore degraded land", "restaurer les terres dégradées",
            "Used in natural resource management and CES/DRS-related activities.",
            "Half-moon techniques were used to restore degraded land in the project area.", 5)
    ),
    concepts = listOf(
        ConceptCard("m5_c1", "Agropastoral system", "Système agropastoral",
            "An agropastoral system integrates crop and livestock production, allowing households to spread risk across two complementary activities.",
            "Un système agropastoral intègre production agricole et élevage, permettant aux ménages de répartir les risques entre deux activités complémentaires.",
            "In an illustrative Tahoua-region household, millet farming was combined with small ruminant rearing to manage rainfall risk.", true, 5),
        ConceptCard("m5_c2", "Transhumance corridors", "Couloirs de transhumance",
            "Transhumance corridors are recognized routes that allow herders' seasonal movement while reducing conflict with farming communities over land use.",
            "Les couloirs de transhumance sont des itinéraires reconnus qui permettent le déplacement saisonnier des éleveurs tout en réduisant les conflits avec les communautés agricoles.",
            "An illustrative corridor mapping exercise in Dosso region identified three points of recurring farmer-herder tension.", true, 5)
    ),
    donorQuestions = listOf(
        DonorQuestion("m5_dq1",
            "Why does the project combine agricultural and pastoral support instead of focusing on one sector?",
            "Because most households in this zone follow an agropastoral livelihood system, so supporting only one sector would leave a significant share of the risk unaddressed.",
            "Bonne réponse : elle relie directement le choix de conception à la réalité des moyens d'existence locaux.",
            "sector choice", 5)
    ),
    exercises = listOf(
        Exercise("m5_ex1", ExerciseType.MULTIPLE_CHOICE,
            "Which term describes farming that depends entirely on rainfall?",
            "Quel terme désigne l'agriculture qui dépend entièrement des précipitations ?",
            listOf("irrigated perimeter", "rain-fed agriculture", "value chain", "fodder"),
            "rain-fed agriculture", "« Rain-fed » = pluvial, sans irrigation.", 5),
        Exercise("m5_ex2", ExerciseType.CHOOSE_EXPRESSION,
            "Choose the correct expression: Local authorities worked to ______ ahead of the dry season.",
            null,
            listOf("secure transhumance corridors", "restore transhumance corridors", "diversify transhumance corridors", "strengthen transhumance corridors"),
            "secure transhumance corridors",
            "« Secure a corridor » est la collocation standard pour protéger un couloir de transhumance.", 5)
    )
)
