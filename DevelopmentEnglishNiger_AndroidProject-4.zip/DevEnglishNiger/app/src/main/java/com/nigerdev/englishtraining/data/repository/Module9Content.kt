package com.nigerdev.englishtraining.data.repository

import com.nigerdev.englishtraining.data.model.*

/**
 * MODULE 9 — Field Research and Needs Assessment
 * Recherche de terrain et évaluation des besoins
 * English ratio: 55%
 */
val module9 = Module(
    id = 9,
    titleEn = "Field Research and Needs Assessment",
    titleFr = "Recherche de terrain et évaluation des besoins",
    englishRatio = 0.55f,
    objectiveEn = "By the end of this lesson, you will be able to explain field research methodologies and needs assessment processes in English.",
    objectiveFr = "À la fin de cette leçon, vous serez capable d'expliquer les méthodologies de recherche de terrain et les processus d'évaluation des besoins en anglais.",
    vocabulary = listOf(
        VocabItem("m9_needs_assessment", "needs assessment", "évaluation des besoins",
            "A systematic process of identifying gaps between current conditions and desired outcomes for a target population.",
            "Processus systématique d'identification des écarts entre la situation actuelle et les résultats souhaités pour une population cible.",
            "The needs assessment revealed that water access was the top priority for surveyed households.", 9),
        VocabItem("m9_household_survey", "household survey", "enquête auprès des ménages",
            "A structured questionnaire administered to a sample of households to collect quantitative data.",
            "Questionnaire structuré administré à un échantillon de ménages pour recueillir des données quantitatives.",
            "The household survey covered 400 households across eight villages.", 9),
        VocabItem("m9_key_informant_interview", "key informant interview", "entretien avec informateur clé",
            "An in-depth interview with an individual who has specialized knowledge about the community or topic.",
            "Entretien approfondi avec une personne possédant une connaissance spécialisée de la communauté ou du sujet.",
            "Key informant interviews with health workers highlighted seasonal spikes in malnutrition.", 9),
        VocabItem("m9_focus_group", "focus group discussion", "discussion de groupe",
            "A guided group discussion used to explore perceptions, attitudes, and shared experiences.",
            "Discussion de groupe guidée utilisée pour explorer perceptions, attitudes et expériences partagées.",
            "A focus group discussion with women revealed time constraints linked to water collection.", 9),
        VocabItem("m9_sampling", "sampling", "échantillonnage",
            "The process of selecting a representative subset of a population for data collection.",
            "Processus de sélection d'un sous-ensemble représentatif d'une population pour la collecte de données.",
            "Random sampling was used to ensure the survey results were representative.", 9),
        VocabItem("m9_secondary_data", "secondary data", "données secondaires",
            "Existing data collected by others, such as census records or previous studies.",
            "Données existantes collectées par d'autres, telles que les recensements ou études antérieures.",
            "Secondary data from the national statistics institute informed the assessment's sampling frame.", 9),
        VocabItem("m9_data_triangulation", "data triangulation", "triangulation des données",
            "Cross-checking findings using multiple data sources or methods to strengthen validity.",
            "Vérification croisée des résultats à partir de plusieurs sources ou méthodes pour renforcer la validité.",
            "Data triangulation confirmed that survey findings matched key informant accounts.", 9)
    ),
    collocations = listOf(
        Expression("m9_e1", "to conduct a needs assessment", "réaliser une évaluation des besoins",
            "The essential collocation for this entire module.",
            "The team conducted a needs assessment before finalizing the project design.", 9),
        Expression("m9_e2", "to collect primary data", "collecter des données primaires",
            "Refers to data gathered directly by the project team.",
            "Enumerators collected primary data using tablet-based questionnaires.", 9),
        Expression("m9_e3", "to triangulate findings", "trianguler les résultats",
            "Used when describing methodological rigor.",
            "The team triangulated findings from surveys, interviews and secondary data.", 9),
        Expression("m9_e4", "to ensure a representative sample", "garantir un échantillon représentatif",
            "Common phrase justifying sampling methodology to donors.",
            "Stratified sampling helped ensure a representative sample across livelihood groups.", 9),
        Expression("m9_e5", "to validate findings with communities", "valider les résultats avec les communautés",
            "Describes the feedback loop that strengthens assessment credibility.",
            "Preliminary findings were validated with communities during a restitution meeting.", 9)
    ),
    concepts = listOf(
        ConceptCard("m9_c1", "Mixed-methods assessment", "Évaluation à méthodes mixtes",
            "A mixed-methods needs assessment combines quantitative data (surveys) with qualitative data (interviews, focus groups) to capture both scale and depth of a problem.",
            "Une évaluation à méthodes mixtes combine données quantitatives (enquêtes) et données qualitatives (entretiens, groupes de discussion) pour saisir à la fois l'ampleur et la profondeur d'un problème.",
            "An illustrative Maradi-region assessment paired a 350-household survey with twelve focus group discussions.", true, 9),
        ConceptCard("m9_c2", "MARP / participatory rapid appraisal", "MARP / méthode accélérée de recherche participative",
            "A rapid, participatory approach that engages community members directly in mapping problems and resources, often used alongside formal surveys.",
            "Une approche rapide et participative qui implique directement les membres de la communauté dans la cartographie des problèmes et des ressources, souvent utilisée en complément des enquêtes formelles.",
            "A MARP exercise in an illustrative Tillabéri village produced a community resource map used to validate survey findings.", true, 9)
    ),
    donorQuestions = listOf(
        DonorQuestion("m9_dq1",
            "What methodology did you use to collect data for this assessment?",
            "We used a mixed-methods approach: a household survey with a statistically representative sample, complemented by key informant interviews and focus group discussions, and we triangulated the findings against secondary data.",
            "Bonne réponse : elle nomme précisément les méthodes et mentionne la triangulation, ce qui rassure sur la rigueur méthodologique.",
            "methodology", 9),
        DonorQuestion("m9_dq2",
            "How did you ensure your sample was representative of the target population?",
            "We used stratified random sampling across livelihood groups and villages, based on population data from the national statistics institute, to avoid over-representing any single group.",
            "Bonne réponse : elle précise la méthode d'échantillonnage et sa justification.",
            "sampling", 9)
    ),
    exercises = listOf(
        Exercise("m9_ex1", ExerciseType.MULTIPLE_CHOICE,
            "Which method involves a guided group discussion to explore shared perceptions?",
            "Quelle méthode consiste en une discussion de groupe guidée pour explorer des perceptions partagées ?",
            listOf("household survey", "focus group discussion", "secondary data", "sampling"),
            "focus group discussion", "« Focus group discussion » = discussion de groupe.", 9),
        Exercise("m9_ex2", ExerciseType.TRANSLATION_FR_EN,
            "Translate: « L'équipe a trianguler les résultats des enquêtes et des entretiens. »", null, emptyList(),
            "The team triangulated findings from surveys and interviews.",
            "« Triangulate findings » est la formulation professionnelle standard.", 9)
    )
)
