package com.nigerdev.englishtraining

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.nigerdev.englishtraining.data.repository.AppSettings
import com.nigerdev.englishtraining.navigation.Dest
import com.nigerdev.englishtraining.ui.navgraph.appNavGraph
import com.nigerdev.englishtraining.ui.theme.DevEnglishNigerTheme

class MainActivity : ComponentActivity() {

    private lateinit var appContainer: AppContainer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        appContainer = AppContainer(applicationContext)

        setContent {
            val settings by appContainer.settingsRepository.settingsFlow.collectAsState(initial = AppSettings())

            DevEnglishNigerTheme(darkTheme = settings.darkMode) {
                Surface {
                    AppScaffold(appContainer = appContainer)
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isFinishing) appContainer.ttsManager.shutdown()
    }
}

private data class BottomItem(val dest: Dest, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

@Composable
fun AppScaffold(appContainer: AppContainer) {
    val navController = rememberNavController()

    val bottomItems = listOf(
        BottomItem(Dest.Home, "Home", Icons.Filled.Home),
        BottomItem(Dest.LearningPath, "Path", Icons.Filled.School),
        BottomItem(Dest.Vocabulary, "Vocabulary", Icons.Filled.MenuBook),
        BottomItem(Dest.DonorSimulation, "Donor", Icons.Filled.RecordVoiceOver),
        BottomItem(Dest.Progress, "Progress", Icons.Filled.BarChart)
    )

    Scaffold(
        bottomBar = {
            val backStackEntry by navController.currentBackStackEntryAsState()
            val currentRoute = backStackEntry?.destination?.route
            NavigationBar {
                bottomItems.forEach { item ->
                    NavigationBarItem(
                        selected = currentRoute == item.dest.route,
                        onClick = {
                            navController.navigate(item.dest.route) {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(item.icon, contentDescription = item.label) },
                        label = { Text(item.label) }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Dest.Home.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            appNavGraph(navController = navController, appContainer = appContainer)
        }
    }
}
