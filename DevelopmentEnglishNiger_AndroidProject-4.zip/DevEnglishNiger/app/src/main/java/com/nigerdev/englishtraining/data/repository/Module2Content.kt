package com.nigerdev.englishtraining.data.repository

import com.nigerdev.englishtraining.data.model.*

/**
 * MODULE 2 — Understanding Development Problems
 * Comprendre les problèmes de développement
 * English ratio: 40% (beginner)
 */
val module2 = Module(
    id = 2,
    titleEn = "Understanding Development Problems",
    titleFr = "Comprendre les problèmes de développement",
    englishRatio = 0.40f,
    objectiveEn = "By the end of this lesson, you will be able to describe a development problem in English using causes and consequences.",
    objectiveFr = "À la fin de cette leçon, vous serez capable de décrire un problème de développement en anglais en utilisant causes et conséquences.",
    vocabulary = listOf(
        VocabItem("m2_root_cause", "root cause", "cause profonde",
            "The fundamental, underlying reason a problem exists, as opposed to its visible symptoms.",
            "La raison fondamentale et sous-jacente de l'existence d'un problème, par opposition à ses symptômes visibles.",
            "Land degradation is a root cause of declining agricultural yields.", 2),
        VocabItem("m2_consequence", "consequence", "conséquence",
            "A direct effect or result that follows from a problem.",
            "Effet direct ou résultat qui découle d'un problème.",
            "Food insecurity is a direct consequence of two consecutive years of poor rainfall.", 2),
        VocabItem("m2_constraint", "constraint", "contrainte",
            "A factor that limits what a project or a population can do.",
            "Facteur qui limite ce qu'un projet ou une population peut faire.",
            "Limited access to credit is a major constraint for smallholder farmers.", 2),
        VocabItem("m2_food_insecurity", "food insecurity", "insécurité alimentaire",
            "A situation in which people lack reliable access to sufficient, safe and nutritious food.",
            "Situation dans laquelle les populations n'ont pas un accès fiable à une alimentation suffisante, sûre et nutritive.",
            "Food insecurity affects several communes in the Diffa region during the lean season.", 2),
        VocabItem("m2_land_degradation", "land degradation", "dégradation des terres",
            "The decline in the quality and productivity of land due to erosion, overuse, or climate factors.",
            "Déclin de la qualité et de la productivité des terres dû à l'érosion, à la surexploitation ou aux facteurs climatiques.",
            "Land degradation has reduced cultivable surfaces in parts of Zinder region.", 2),
        VocabItem("m2_underlying_factor", "underlying factor", "facteur sous-jacent",
            "A less visible factor that contributes to a problem alongside its root causes.",
            "Facteur moins visible qui contribue à un problème aux côtés de ses causes profondes.",
            "Weak market access is an underlying factor in low household income.", 2),
        VocabItem("m2_problem_statement", "problem statement", "énoncé du problème",
            "A concise, evidence-based description of the core problem a project intends to address.",
            "Description concise et fondée sur des preuves du problème central qu'un projet entend traiter.",
            "The problem statement identifies declining pasture availability as the central issue.", 2)
    ),
    collocations = listOf(
        Expression("m2_e1", "to identify the causes of", "identifier les causes de",
            "Used when analytically tracing why a problem occurs.",
            "The team worked to identify the causes of declining well water levels.", 2),
        Expression("m2_e2", "to be affected by", "être affecté par",
            "Standard construction for describing populations impacted by a phenomenon.",
            "Pastoralist households are particularly affected by reduced grazing land.", 2),
        Expression("m2_e3", "to result in", "aboutir à / entraîner",
            "Used to link a cause to its outcome.",
            "Poor rainfall distribution results in lower cereal production.", 2),
        Expression("m2_e4", "to exacerbate a problem", "aggraver un problème",
            "To make an existing problem worse.",
            "Rapid population growth exacerbates pressure on natural resources.", 2),
        Expression("m2_e5", "to stem from", "découler de / provenir de",
            "A more formal way of expressing that something originates from a cause.",
            "Much of the water shortage stems from the degradation of traditional ponds.", 2),
        Expression("m2_e6", "to have a direct impact on", "avoir un impact direct sur",
            "Used to connect a factor to a clearly observable effect.",
            "Reduced rainfall has a direct impact on livestock body condition.", 2)
    ),
    concepts = listOf(
        ConceptCard("m2_c1", "Problem tree (introduction)", "Arbre à problèmes (introduction)",
            "A problem tree is a visual tool that organizes a central problem, its root causes (roots) and its consequences (branches).",
            "L'arbre à problèmes est un outil visuel qui organise un problème central, ses causes profondes (racines) et ses conséquences (branches).",
            "A problem tree built for a Tahoua-region project placed 'low agricultural productivity' as the central problem.", true, 2),
        ConceptCard("m2_c2", "Causes vs. consequences", "Causes vs. conséquences",
            "Causes explain why a problem exists; consequences describe what happens as a result. Confusing the two weakens a project's logic.",
            "Les causes expliquent pourquoi un problème existe ; les conséquences décrivent ce qui en résulte. Confondre les deux affaiblit la logique du projet.",
            "In a Maradi food-security analysis, 'poor soil fertility' was a cause, while 'reduced household income' was a consequence.", true, 2)
    ),
    exercises = listOf(
        Exercise("m2_ex1", ExerciseType.FILL_BLANK,
            "Reduced rainfall ______ in lower cereal yields across the region.", null,
            listOf("results", "identifies", "exacerbates", "stems"),
            "results",
            "« Result in » est l'expression correcte pour relier une cause à sa conséquence.", 2),
        Exercise("m2_ex2", ExerciseType.MULTIPLE_CHOICE,
            "Which term best describes a fundamental, underlying reason for a problem?",
            "Quel terme désigne le mieux une raison fondamentale et sous-jacente d'un problème ?",
            listOf("consequence", "root cause", "constraint", "problem statement"),
            "root cause", "« Root cause » = cause profonde, à la racine du problème.", 2)
    )
)
