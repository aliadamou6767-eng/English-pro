package com.nigerdev.englishtraining.ui.screens.practice

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nigerdev.englishtraining.data.repository.ContentRepository

@Composable
fun PracticeHubScreen(onOpenPractice: (Int) -> Unit) {
    val modulesWithExercises = remember { ContentRepository.fullModules.filter { it.exercises.isNotEmpty() } }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Practice", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Exercices interactifs par module", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(12.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(modulesWithExercises, key = { it.id }) { m ->
                Card(Modifier.fillMaxWidth(), onClick = { onOpenPractice(m.id) }) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Module ${m.id} · ${m.titleEn}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text("${m.exercises.size} exercises", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}
