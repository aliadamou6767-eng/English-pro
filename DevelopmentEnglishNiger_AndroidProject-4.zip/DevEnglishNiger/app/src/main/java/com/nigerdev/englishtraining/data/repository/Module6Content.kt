package com.nigerdev.englishtraining.data.repository

import com.nigerdev.englishtraining.data.model.*

/**
 * MODULE 6 — Infrastructure, Equipment and Basic Services
 * Infrastructures, équipements et services sociaux de base
 * English ratio: 50%
 */
val module6 = Module(
    id = 6,
    titleEn = "Infrastructure, Equipment and Basic Services",
    titleFr = "Infrastructures, équipements et services sociaux de base",
    englishRatio = 0.50f,
    objectiveEn = "By the end of this lesson, you will be able to describe infrastructure gaps and basic services in professional English.",
    objectiveFr = "À la fin de cette leçon, vous serez capable de décrire les déficits d'infrastructures et les services sociaux de base en anglais professionnel.",
    vocabulary = listOf(
        VocabItem("m6_basic_services", "basic services", "services sociaux de base",
            "Essential public services such as health, education, water and sanitation.",
            "Services publics essentiels tels que la santé, l'éducation, l'eau et l'assainissement.",
            "Access to basic services remains limited in several rural communes.", 6),
        VocabItem("m6_water_point", "water point", "point d'eau",
            "A borehole, well or other infrastructure providing access to water.",
            "Forage, puits ou autre infrastructure permettant l'accès à l'eau.",
            "The village's only functional water point serves over 2,000 residents.", 6),
        VocabItem("m6_health_facility", "health facility", "formation sanitaire / centre de santé",
            "A structure providing medical care, ranging from a health post to a hospital.",
            "Structure offrant des soins médicaux, allant du poste de santé à l'hôpital.",
            "The nearest health facility is located twelve kilometres from the village.", 6),
        VocabItem("m6_school_infrastructure", "school infrastructure", "infrastructures scolaires",
            "Physical facilities supporting education, including classrooms and latrines.",
            "Installations physiques soutenant l'éducation, notamment salles de classe et latrines.",
            "Poor school infrastructure contributes to high dropout rates among girls.", 6),
        VocabItem("m6_sanitation", "sanitation", "assainissement",
            "Facilities and services for the safe disposal of human waste.",
            "Installations et services pour l'élimination sûre des déchets humains.",
            "Improved sanitation reduces the incidence of waterborne diseases.", 6),
        VocabItem("m6_rural_road", "rural road", "piste rurale",
            "An unpaved or lightly improved road connecting rural communities to markets and services.",
            "Route non revêtue ou légèrement améliorée reliant les communautés rurales aux marchés et services.",
            "The rural road becomes impassable during the rainy season, isolating several villages.", 6),
        VocabItem("m6_electrification", "electrification", "électrification",
            "The process of providing access to electricity, including through solar mini-grids.",
            "Processus consistant à fournir l'accès à l'électricité, y compris via des mini-réseaux solaires.",
            "Solar electrification has extended lighting hours at the health centre.", 6)
    ),
    collocations = listOf(
        Expression("m6_e1", "to improve access to basic services", "améliorer l'accès aux services sociaux de base",
            "Very common phrasing in project objectives across sectors.",
            "The project aims to improve access to basic services for 15,000 people.", 6),
        Expression("m6_e2", "to rehabilitate infrastructure", "réhabiliter les infrastructures",
            "Used for repairing rather than building new infrastructure.",
            "The programme will rehabilitate three water points damaged during the floods.", 6),
        Expression("m6_e3", "to close the infrastructure gap", "combler le déficit d'infrastructures",
            "Formal expression describing addressing a shortfall.",
            "New classrooms help close the infrastructure gap in the commune.", 6),
        Expression("m6_e4", "to connect communities to markets", "relier les communautés aux marchés",
            "Common in rural roads and economic infrastructure components.",
            "The rehabilitated road connects three villages to the regional market.", 6),
        Expression("m6_e5", "to be underserved", "être insuffisamment desservi",
            "Describes populations lacking adequate services.",
            "Remote pastoral areas remain underserved in terms of health facilities.", 6)
    ),
    concepts = listOf(
        ConceptCard("m6_c1", "Basic social services", "Services sociaux de base",
            "Basic social services generally include health, education, water, sanitation and, increasingly, energy access — the minimum package a development strategy aims to secure.",
            "Les services sociaux de base comprennent généralement la santé, l'éducation, l'eau, l'assainissement et, de plus en plus, l'accès à l'énergie — le socle minimal qu'une stratégie de développement vise à garantir.",
            "An illustrative gap analysis in a Diffa-region commune found no functional health facility within ten kilometres of four villages.", true, 6)
    ),
    donorQuestions = listOf(
        DonorQuestion("m6_dq1",
            "Why did you prioritize water points over other infrastructure in this proposal?",
            "The needs assessment showed that lack of reliable water access was the constraint most frequently cited by households, and it directly affects health, time use, and agricultural activities, so we prioritized it as the entry point.",
            "Bonne réponse : elle justifie le choix par des données d'évaluation des besoins plutôt qu'une préférence arbitraire.",
            "prioritization", 6)
    ),
    exercises = listOf(
        Exercise("m6_ex1", ExerciseType.MULTIPLE_CHOICE,
            "Which term refers to essential public services like health, education, water and sanitation?",
            "Quel terme désigne les services publics essentiels comme la santé, l'éducation, l'eau et l'assainissement ?",
            listOf("rural road", "basic services", "electrification", "water point"),
            "basic services", "« Basic services » regroupe santé, éducation, eau et assainissement.", 6),
        Exercise("m6_ex2", ExerciseType.FILL_BLANK,
            "The programme will ______ three water points damaged during the floods.", null,
            listOf("rehabilitate", "connect", "underserve", "electrify"),
            "rehabilitate",
            "« Rehabilitate » s'utilise pour la réhabilitation d'infrastructures existantes.", 6)
    )
)
