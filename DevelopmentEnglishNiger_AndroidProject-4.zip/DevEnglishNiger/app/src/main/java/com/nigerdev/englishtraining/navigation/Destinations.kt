package com.nigerdev.englishtraining.navigation

sealed class Dest(val route: String) {
    data object Home : Dest("home")
    data object LearningPath : Dest("learning_path")
    data object ModuleDetail : Dest("module/{moduleId}") {
        fun of(moduleId: Int) = "module/$moduleId"
    }
    data object Vocabulary : Dest("vocabulary")
    data object MyVocabulary : Dest("my_vocabulary")
    data object Expressions : Dest("expressions")
    data object Practice : Dest("practice")
    data object PracticeModule : Dest("practice/{moduleId}") {
        fun of(moduleId: Int) = "practice/$moduleId"
    }
    data object DonorSimulation : Dest("donor_simulation")
    data object Progress : Dest("progress")
    data object Settings : Dest("settings")
    data object Search : Dest("search")

    companion object {
        val bottomBarItems = listOf(Home, LearningPath, Vocabulary, DonorSimulation, Progress)
    }
}
