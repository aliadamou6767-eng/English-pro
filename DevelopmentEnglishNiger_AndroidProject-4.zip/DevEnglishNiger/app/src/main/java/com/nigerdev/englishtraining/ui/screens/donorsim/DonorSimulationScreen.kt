package com.nigerdev.englishtraining.ui.screens.donorsim

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nigerdev.englishtraining.AppContainer
import com.nigerdev.englishtraining.data.repository.ContentRepository
import com.nigerdev.englishtraining.ui.components.AudioSentence
import kotlinx.coroutines.launch

/**
 * Donor simulation flow, per spec section 21:
 *  A. Read the model answer
 *  B. Listen to the model answer
 *  C. Record his own answer (basic recording hook; STT is optional/out of core scope)
 *  D. Compare his answer with the model answer
 */
@Composable
fun DonorSimulationScreen(appContainer: AppContainer) {
    val questions = remember { ContentRepository.allDonorQuestions() }
    var index by remember { mutableStateOf(0) }
    var showAnswer by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    if (questions.isEmpty()) {
        Column(Modifier.fillMaxSize().padding(24.dp)) {
            Text("Donor Simulation", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text("Donor questions are added module by module. Complete Module 3 (Climate Change, Vulnerability and Resilience) to unlock the first simulation set.")
        }
        return
    }

    val question = questions[index % questions.size]

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Donor Simulation", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Simulation d'entretien avec un bailleur", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(16.dp))

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("DONOR", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                AudioSentence(english = question.questionEn, ttsManager = appContainer.ttsManager, style = MaterialTheme.typography.titleMedium)
            }
        }

        Spacer(Modifier.height(16.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                // Placeholder hook: wire to MediaRecorder if the learner grants RECORD_AUDIO.
                // Kept optional per spec section 26 — TTS remains the core audio function.
            }) {
                Icon(Icons.Filled.Mic, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("Record my answer")
            }
            Button(onClick = { showAnswer = !showAnswer }) {
                Text(if (showAnswer) "Hide model answer" else "Show model answer")
            }
        }

        if (showAnswer) {
            Spacer(Modifier.height(12.dp))
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Model answer / Réponse modèle", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    AudioSentence(english = question.modelAnswerEn, ttsManager = appContainer.ttsManager)
                    Spacer(Modifier.height(8.dp))
                    Text("Why this works · Pourquoi cette réponse fonctionne", style = MaterialTheme.typography.labelLarge)
                    Text(question.explanationFr, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            TextButton(onClick = {
                scope.launch { appContainer.progressRepository.logDonorSimAttempt(question.id) }
                showAnswer = false
                index++
            }) { Text("I compared my answer → Next question") }
        }
    }
}
