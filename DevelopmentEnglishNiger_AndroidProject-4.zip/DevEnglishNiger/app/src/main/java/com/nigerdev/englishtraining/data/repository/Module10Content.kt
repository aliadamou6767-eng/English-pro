package com.nigerdev.englishtraining.data.repository

import com.nigerdev.englishtraining.data.model.*

/**
 * MODULE 10 — GIS, Remote Sensing and Spatial Evidence
 * SIG, télédétection et données spatiales
 * English ratio: 55%
 * (This module speaks directly to ADAMOU's core professional identity as an aménagiste.)
 */
val module10 = Module(
    id = 10,
    titleEn = "GIS, Remote Sensing and Spatial Evidence",
    titleFr = "SIG, télédétection et données spatiales",
    englishRatio = 0.55f,
    objectiveEn = "By the end of this lesson, you will be able to explain GIS and remote sensing concepts to a non-technical audience, including donors, in English.",
    objectiveFr = "À la fin de cette leçon, vous serez capable d'expliquer les concepts de SIG et de télédétection à un public non technique, y compris des bailleurs, en anglais.",
    vocabulary = listOf(
        VocabItem("m10_gis", "Geographic Information System (GIS)", "Système d'Information Géographique (SIG)",
            "A system for capturing, storing, analyzing and displaying spatially referenced data.",
            "Système permettant de saisir, stocker, analyser et afficher des données à référence spatiale.",
            "GIS analysis helped identify overlapping vulnerability and rainfall deficit zones.", 10),
        VocabItem("m10_remote_sensing", "remote sensing", "télédétection",
            "The collection of information about the Earth's surface using satellite or aerial imagery.",
            "Collecte d'informations sur la surface terrestre à l'aide d'images satellitaires ou aériennes.",
            "Remote sensing imagery showed a decline in vegetation cover over the past five years.", 10),
        VocabItem("m10_satellite_imagery", "satellite imagery", "imagerie satellitaire",
            "Images of the Earth captured by satellites, used to monitor land use and environmental change.",
            "Images de la Terre captées par satellite, utilisées pour suivre l'occupation des sols et les changements environnementaux.",
            "Satellite imagery from the last three growing seasons was compared to detect land degradation.", 10),
        VocabItem("m10_spatial_data", "spatial data", "données spatiales",
            "Data that includes geographic location as one of its attributes.",
            "Données incluant la localisation géographique comme l'un de leurs attributs.",
            "Spatial data on water points was layered with population density to identify service gaps.", 10),
        VocabItem("m10_shapefile", "shapefile", "shapefile / fichier de formes",
            "A common digital file format for storing geographic vector data such as boundaries or points.",
            "Format de fichier numérique courant pour stocker des données vectorielles géographiques telles que limites ou points.",
            "The commune boundary shapefile was overlaid with the vulnerability index.", 10),
        VocabItem("m10_ndvi", "vegetation index (NDVI)", "indice de végétation (NDVI)",
            "A satellite-derived measure of vegetation health and density, commonly used to monitor drought.",
            "Mesure de la santé et de la densité de la végétation dérivée de données satellitaires, couramment utilisée pour suivre la sécheresse.",
            "The vegetation index showed below-average pasture conditions across the pastoral zone.", 10),
        VocabItem("m10_land_use_map", "land use map", "carte d'occupation des sols",
            "A map showing how land is used, such as cropland, pasture, settlement or forest.",
            "Carte montrant l'utilisation des terres, telle que terres cultivées, pâturages, habitat ou forêt.",
            "The land use map guided the selection of sites for the irrigated perimeter.", 10)
    ),
    collocations = listOf(
        Expression("m10_e1", "to overlay spatial data layers", "superposer des couches de données spatiales",
            "The standard GIS analytical action.",
            "We overlaid spatial data layers to cross-reference flood risk with population density.", 10),
        Expression("m10_e2", "to produce a map", "produire une carte",
            "Simple but essential phrasing for describing deliverables.",
            "The team produced a map showing priority intervention zones.", 10),
        Expression("m10_e3", "to monitor land degradation", "suivre la dégradation des terres",
            "Common when discussing remote sensing applications.",
            "Satellite data helps monitor land degradation trends over multiple seasons.", 10),
        Expression("m10_e4", "to ground-truth the data", "vérifier les données sur le terrain",
            "Refers to validating remote-sensed data through field visits — an important credibility point with donors.",
            "Field teams ground-truthed the satellite-derived land cover classification.", 10),
        Expression("m10_e5", "to support evidence-based decision-making", "appuyer une prise de décision fondée sur des preuves",
            "A high-value phrase linking GIS work to project credibility.",
            "Spatial analysis supports evidence-based decision-making in area selection.", 10)
    ),
    concepts = listOf(
        ConceptCard("m10_c1", "From data to decision", "Des données à la décision",
            "GIS work is only useful to a donor audience when it is explicitly connected to a decision: which area was chosen, why, and what evidence supports that choice.",
            "Le travail SIG n'est utile pour un public de bailleurs que lorsqu'il est explicitement relié à une décision : quelle zone a été choisie, pourquoi, et quelles preuves soutiennent ce choix.",
            "An illustrative Tahoua-region map combined rainfall deficit and population data to justify selecting two priority communes over four alternatives.", true, 10),
        ConceptCard("m10_c2", "Explaining technical work to a non-technical audience", "Expliquer un travail technique à un public non technique",
            "When presenting GIS findings to donors, lead with the finding and its implication, not the technical method — save technical detail for follow-up questions.",
            "Lors de la présentation de résultats SIG à des bailleurs, commencez par le résultat et son implication, pas par la méthode technique — gardez le détail technique pour les questions de suivi.",
            "Instead of opening with 'we ran an NDVI analysis,' an aménagiste might open with 'vegetation data confirmed this zone had the most severe pasture loss.'", true, 10)
    ),
    donorQuestions = listOf(
        DonorQuestion("m10_dq1",
            "Can you explain, in simple terms, how you used GIS to select this area?",
            "We layered several maps — rainfall patterns, population density, and vegetation health — over the region, and this zone consistently showed the most severe overlap of climate stress and population vulnerability.",
            "Bonne réponse : elle vulgarise la méthode sans jargon excessif, tout en restant précise sur le résultat.",
            "GIS explanation", 10),
        DonorQuestion("m10_dq2",
            "How reliable is satellite data compared to information collected on the ground?",
            "Satellite data is very reliable for detecting broad trends over large areas, but we always ground-truth it with field visits, since local factors like a newly dug well are not always visible from a satellite image.",
            "Bonne réponse : elle reconnaît honnêtement les limites de la télédétection tout en expliquant comment l'équipe les compense.",
            "data reliability", 10)
    ),
    exercises = listOf(
        Exercise("m10_ex1", ExerciseType.MULTIPLE_CHOICE,
            "Which term refers to validating satellite-derived data through field visits?",
            "Quel terme désigne la validation de données satellitaires par des visites de terrain ?",
            listOf("ground-truthing", "shapefile", "NDVI", "overlay"),
            "ground-truthing", "« Ground-truth » = vérifier sur le terrain.", 10),
        Exercise("m10_ex2", ExerciseType.FILL_BLANK,
            "The team ______ spatial data layers to cross-reference flood risk with population density.", null,
            listOf("overlaid", "ground-truthed", "monitored", "produced"),
            "overlaid",
            "« Overlay data layers » est l'expression SIG standard.", 10)
    )
)
