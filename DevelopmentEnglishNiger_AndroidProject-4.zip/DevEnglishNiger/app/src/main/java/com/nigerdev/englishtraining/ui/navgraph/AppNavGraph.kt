package com.nigerdev.englishtraining.ui.navgraph

import androidx.navigation.NavController
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavType
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.nigerdev.englishtraining.AppContainer
import com.nigerdev.englishtraining.navigation.Dest
import com.nigerdev.englishtraining.ui.screens.donorsim.DonorSimulationScreen
import com.nigerdev.englishtraining.ui.screens.expressions.ExpressionsScreen
import com.nigerdev.englishtraining.ui.screens.home.HomeScreen
import com.nigerdev.englishtraining.ui.screens.learningpath.LearningPathScreen
import com.nigerdev.englishtraining.ui.screens.module.ModuleDetailScreen
import com.nigerdev.englishtraining.ui.screens.practice.PracticeHubScreen
import com.nigerdev.englishtraining.ui.screens.practice.PracticeModuleScreen
import com.nigerdev.englishtraining.ui.screens.progress.ProgressScreen
import com.nigerdev.englishtraining.ui.screens.search.SearchScreen
import com.nigerdev.englishtraining.ui.screens.settings.SettingsScreen
import com.nigerdev.englishtraining.ui.screens.vocabulary.MyVocabularyScreen
import com.nigerdev.englishtraining.ui.screens.vocabulary.VocabularyScreen

fun NavGraphBuilder.appNavGraph(navController: NavController, appContainer: AppContainer) {

    composable(Dest.Home.route) {
        HomeScreen(
            appContainer = appContainer,
            onOpenModule = { id -> navController.navigate(Dest.ModuleDetail.of(id)) },
            onGoToPath = { navController.navigate(Dest.LearningPath.route) },
            onGoToDonorSim = { navController.navigate(Dest.DonorSimulation.route) }
        )
    }

    composable(Dest.LearningPath.route) {
        LearningPathScreen(
            appContainer = appContainer,
            onOpenModule = { id -> navController.navigate(Dest.ModuleDetail.of(id)) }
        )
    }

    composable(
        route = Dest.ModuleDetail.route,
        arguments = listOf(navArgument("moduleId") { type = NavType.IntType })
    ) { backStackEntry ->
        val moduleId = backStackEntry.arguments?.getInt("moduleId") ?: 1
        ModuleDetailScreen(
            moduleId = moduleId,
            appContainer = appContainer,
            onStartPractice = { id -> navController.navigate(Dest.PracticeModule.of(id)) }
        )
    }

    composable(Dest.Vocabulary.route) {
        VocabularyScreen(
            appContainer = appContainer,
            onOpenMyVocabulary = { navController.navigate(Dest.MyVocabulary.route) }
        )
    }

    composable(Dest.MyVocabulary.route) {
        MyVocabularyScreen(appContainer = appContainer)
    }

    composable(Dest.Expressions.route) {
        ExpressionsScreen(appContainer = appContainer)
    }

    composable(Dest.Practice.route) {
        PracticeHubScreen(onOpenPractice = { id -> navController.navigate(Dest.PracticeModule.of(id)) })
    }

    composable(
        route = Dest.PracticeModule.route,
        arguments = listOf(navArgument("moduleId") { type = NavType.IntType })
    ) { backStackEntry ->
        val moduleId = backStackEntry.arguments?.getInt("moduleId") ?: 1
        PracticeModuleScreen(moduleId = moduleId, appContainer = appContainer)
    }

    composable(Dest.DonorSimulation.route) {
        DonorSimulationScreen(appContainer = appContainer)
    }

    composable(Dest.Progress.route) {
        ProgressScreen(appContainer = appContainer)
    }

    composable(Dest.Settings.route) {
        SettingsScreen(appContainer = appContainer)
    }

    composable(Dest.Search.route) {
        SearchScreen(appContainer = appContainer)
    }
}
