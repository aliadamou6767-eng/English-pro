package com.nigerdev.englishtraining.data.repository

import com.nigerdev.englishtraining.data.model.*

/**
 * MODULE 17 — Gender, Inclusion, Human Rights and Do-No-Harm
 * Genre, inclusion, droits humains et principe de ne pas nuire
 * English ratio: 65%
 */
val module17 = Module(
    id = 17,
    titleEn = "Gender, Inclusion, Human Rights and Do-No-Harm",
    titleFr = "Genre, inclusion, droits humains et principe de ne pas nuire",
    englishRatio = 0.65f,
    objectiveEn = "By the end of this lesson, you will be able to discuss gender, inclusion and rights-based approaches to development in English.",
    objectiveFr = "À la fin de cette leçon, vous serez capable de discuter d'approches genre, inclusion et fondées sur les droits en anglais.",
    vocabulary = listOf(
        VocabItem("m17_gender_mainstreaming", "gender mainstreaming", "intégration de la dimension genre",
            "The practice of considering gender implications in all stages of project design and implementation.",
            "Pratique consistant à prendre en compte les implications de genre à toutes les étapes de la conception et de la mise en œuvre d'un projet.",
            "Gender mainstreaming ensured women's needs were reflected in every project component.", 17),
        VocabItem("m17_gender_responsive", "gender-responsive", "sensible au genre",
            "Describes an approach that actively addresses the different needs and constraints of women and men.",
            "Décrit une approche qui répond activement aux besoins et contraintes différenciés des femmes et des hommes.",
            "Meeting times were adjusted to be gender-responsive to women's domestic responsibilities.", 17),
        VocabItem("m17_inclusion", "inclusion", "inclusion",
            "The practice of ensuring that marginalized or excluded groups can meaningfully participate in and benefit from a project.",
            "Pratique consistant à garantir que les groupes marginalisés ou exclus puissent participer et bénéficier réellement d'un projet.",
            "Inclusion of persons with disabilities required adapting training materials and locations.", 17),
        VocabItem("m17_rights_based_approach", "rights-based approach", "approche fondée sur les droits",
            "A development approach grounded in international human rights standards and principles.",
            "Approche du développement fondée sur les normes et principes internationaux des droits humains.",
            "The programme adopted a rights-based approach centered on access to water as a basic right.", 17),
        VocabItem("m17_gender_based_violence", "gender-based violence (GBV)", "violences basées sur le genre (VBG)",
            "Harm directed at a person because of their gender, including physical, sexual, or economic violence.",
            "Préjudice dirigé contre une personne en raison de son genre, incluant violence physique, sexuelle ou économique.",
            "The project included a gender-based violence referral pathway for survivors.", 17),
        VocabItem("m17_equitable_participation", "equitable participation", "participation équitable",
            "Fair and balanced involvement of different groups in project activities and decision-making.",
            "Implication juste et équilibrée des différents groupes dans les activités et la prise de décision du projet.",
            "The committee's composition ensured equitable participation of women and youth.", 17),
        VocabItem("m17_disaggregated_data", "sex- and age-disaggregated data", "données désagrégées par sexe et âge",
            "Data broken down by sex and age group to reveal differences in needs, access, or outcomes.",
            "Données ventilées par sexe et groupe d'âge pour révéler des différences en matière de besoins, d'accès ou de résultats.",
            "Sex- and age-disaggregated data showed girls faced greater barriers to school attendance.", 17)
    ),
    collocations = listOf(
        Expression("m17_e1", "to mainstream gender across activities", "intégrer le genre dans l'ensemble des activités",
            "Formal phrase describing systemic integration.",
            "The project mainstreamed gender across all training and infrastructure activities.", 17),
        Expression("m17_e2", "to ensure equitable participation", "garantir une participation équitable",
            "Common in inclusion-related sections of proposals.",
            "Quota-based committee seats helped ensure equitable participation of women.", 17),
        Expression("m17_e3", "to apply a do-no-harm lens", "appliquer une analyse de type « ne pas nuire »",
            "Refers to applying the do-no-harm principle as an analytical filter (see Module 16).",
            "The team applied a do-no-harm lens when deciding how to distribute inputs fairly.", 17),
        Expression("m17_e4", "to disaggregate data by sex and age", "désagréger les données par sexe et âge",
            "Standard monitoring practice increasingly required by donors.",
            "All indicators are disaggregated by sex and age in the monitoring system.", 17),
        Expression("m17_e5", "to remove barriers to participation", "lever les obstacles à la participation",
            "Used when describing inclusion measures for specific groups.",
            "Adapted transport removed barriers to participation for persons with disabilities.", 17)
    ),
    concepts = listOf(
        ConceptCard("m17_c1", "Gender mainstreaming vs. targeted gender activities", "Intégration du genre vs. activités genre ciblées",
            "Gender mainstreaming means every component considers gender; targeted activities go further, specifically designed to address a gap for one group (e.g., a women-only savings group).",
            "L'intégration du genre signifie que chaque composante prend en compte le genre ; les activités ciblées vont plus loin, conçues spécifiquement pour combler un écart pour un groupe (par ex. un groupe d'épargne réservé aux femmes).",
            "An illustrative project mainstreamed gender by disaggregating all indicators, and also ran a targeted activity: a women-only savings group addressing limited access to credit.", true, 17),
        ConceptCard("m17_c2", "Do-No-Harm as an ongoing analysis", "Ne pas nuire comme analyse continue",
            "Do-no-harm is not a one-time checklist but an ongoing analysis of how project resources, presence, and decisions might affect local power dynamics or tensions.",
            "Le principe de ne pas nuire n'est pas une simple liste de vérification ponctuelle, mais une analyse continue de la façon dont les ressources, la présence et les décisions du projet peuvent affecter les dynamiques de pouvoir ou les tensions locales.",
            "An illustrative case: distributing inputs only through the village chief risked reinforcing existing inequities, so the team added a transparent, published beneficiary list instead.", true, 17)
    ),
    donorQuestions = listOf(
        DonorQuestion("m17_dq1",
            "How will women specifically benefit from this project, beyond general household benefits?",
            "Women are prioritized in targeting given their role in water collection, and the project includes a dedicated women's savings and training component, with progress tracked through sex-disaggregated indicators.",
            "Bonne réponse : elle va au-delà du bénéfice général du ménage pour préciser un bénéfice ciblé et mesurable pour les femmes.",
            "gender", 17),
        DonorQuestion("m17_dq2",
            "How does the project ensure it does not unintentionally increase local tensions?",
            "We conducted a do-no-harm analysis during design and built in a transparent, published beneficiary selection process specifically to avoid perceptions of favoritism that could increase local tensions.",
            "Bonne réponse : elle nomme l'outil (analyse ne pas nuire) et donne une mesure concrète issue de cette analyse.",
            "do no harm", 17)
    ),
    exercises = listOf(
        Exercise("m17_ex1", ExerciseType.MULTIPLE_CHOICE,
            "Which term describes data broken down by sex and age group?",
            "Quel terme désigne des données ventilées par sexe et groupe d'âge ?",
            listOf("gender mainstreaming", "disaggregated data", "rights-based approach", "inclusion"),
            "disaggregated data", "« Sex- and age-disaggregated data » est le terme technique standard.", 17),
        Exercise("m17_ex2", ExerciseType.FILL_BLANK,
            "The team applied a ______ lens when deciding how to distribute inputs fairly.", null,
            listOf("do-no-harm", "gender-responsive", "rights-based", "inclusion"),
            "do-no-harm",
            "« Apply a do-no-harm lens » est l'expression consacrée pour cette analyse.", 17)
    )
)
