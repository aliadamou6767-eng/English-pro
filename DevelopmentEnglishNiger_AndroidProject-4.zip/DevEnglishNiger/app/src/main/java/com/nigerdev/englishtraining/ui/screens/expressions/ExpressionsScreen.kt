package com.nigerdev.englishtraining.ui.screens.expressions

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nigerdev.englishtraining.AppContainer
import com.nigerdev.englishtraining.data.repository.ContentRepository
import com.nigerdev.englishtraining.ui.components.AudioSentence

@Composable
fun ExpressionsScreen(appContainer: AppContainer) {
    val expressions = remember { ContentRepository.allExpressions() }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Professional Expressions", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Expressions et collocations professionnelles", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(12.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(expressions, key = { it.id }) { e ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        AudioSentence(english = e.english, ttsManager = appContainer.ttsManager, style = MaterialTheme.typography.titleMedium)
                        Text(e.french, fontWeight = FontWeight.SemiBold)
                        Text(e.explanationFr, style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.height(4.dp))
                        AudioSentence(english = e.exampleEn, ttsManager = appContainer.ttsManager, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}
