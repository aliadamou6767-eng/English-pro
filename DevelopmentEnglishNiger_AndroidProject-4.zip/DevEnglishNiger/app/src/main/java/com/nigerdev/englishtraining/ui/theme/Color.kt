package com.nigerdev.englishtraining.ui.theme

import androidx.compose.ui.graphics.Color

// Primary identity, consistent with the existing French-language training series
val DeepGreen = Color(0xFF173F2E)
val DeepGreenLight = Color(0xFF2A5C43)
val Sand = Color(0xFFC9A66B)
val SandLight = Color(0xFFE4D2AC)
val Cream = Color(0xFFF5EFE3)
val Charcoal = Color(0xFF262622)
val ErrorRed = Color(0xFFB3261E)
val SuccessGreen = Color(0xFF3F7A56)
val InfoBlue = Color(0xFF3A5A78)
