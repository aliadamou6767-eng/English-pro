package com.nigerdev.englishtraining.data.repository

import com.nigerdev.englishtraining.data.model.*

/**
 * MODULE 16 — Risk Management, Safeguards and Sustainability
 * Gestion des risques, sauvegardes et durabilité
 * English ratio: 65% (intermediate/advanced transition)
 */
val module16 = Module(
    id = 16,
    titleEn = "Risk Management, Safeguards and Sustainability",
    titleFr = "Gestion des risques, sauvegardes et durabilité",
    englishRatio = 0.65f,
    objectiveEn = "By the end of this lesson, you will be able to discuss project risks, safeguards and sustainability strategies in English.",
    objectiveFr = "À la fin de cette leçon, vous serez capable de discuter des risques, sauvegardes et stratégies de durabilité d'un projet en anglais.",
    vocabulary = listOf(
        VocabItem("m16_risk", "risk", "risque",
            "A potential event or condition that could negatively affect a project's ability to achieve its objectives.",
            "Un événement ou une condition potentielle qui pourrait affecter négativement la capacité d'un projet à atteindre ses objectifs.",
            "Conflict between farmers and herders was identified as a significant risk.", 16),
        VocabItem("m16_mitigation_measure", "mitigation measure", "mesure d'atténuation",
            "An action taken to reduce the likelihood or severity of a risk.",
            "Une action entreprise pour réduire la probabilité ou la gravité d'un risque.",
            "Early consultation with both groups was a key mitigation measure for land conflict.", 16),
        VocabItem("m16_safeguard", "safeguard", "sauvegarde",
            "A policy or procedure designed to prevent harm to people or the environment from project activities.",
            "Politique ou procédure conçue pour prévenir un préjudice aux personnes ou à l'environnement du fait des activités du projet.",
            "Environmental safeguards required an assessment before the irrigation canal was built.", 16),
        VocabItem("m16_do_no_harm", "do no harm", "principe de ne pas nuire",
            "A principle requiring that aid interventions avoid causing unintended negative consequences.",
            "Principe exigeant que les interventions d'aide évitent de provoquer des conséquences négatives non intentionnelles.",
            "The do no harm analysis considered how resource distribution might affect local tensions.", 16),
        VocabItem("m16_sustainability", "sustainability", "durabilité",
            "The likelihood that project benefits will continue after external funding ends.",
            "La probabilité que les bénéfices d'un projet perdurent après la fin du financement externe.",
            "Sustainability was strengthened by training local technicians to maintain the water points.", 16),
        VocabItem("m16_exit_strategy", "exit strategy", "stratégie de sortie",
            "A plan describing how a project will transition responsibilities to local actors before closure.",
            "Un plan décrivant comment un projet transférera les responsabilités aux acteurs locaux avant sa clôture.",
            "The exit strategy handed over water point management to a village committee.", 16),
        VocabItem("m16_risk_matrix", "risk matrix", "matrice des risques",
            "A table listing identified risks alongside their likelihood, severity, and mitigation measures.",
            "Tableau listant les risques identifiés avec leur probabilité, leur gravité et les mesures d'atténuation.",
            "The risk matrix rated flooding as high likelihood and high severity.", 16)
    ),
    collocations = listOf(
        Expression("m16_e1", "to identify and mitigate risks", "identifier et atténuer les risques",
            "Standard phrase pair, almost always used together.",
            "The design team identified and mitigated risks during the planning workshop.", 16),
        Expression("m16_e2", "to ensure sustainability", "garantir la durabilité",
            "One of the most frequent donor-facing phrases (see also donor questions).",
            "Community ownership was central to ensuring sustainability after project closure.", 16),
        Expression("m16_e3", "to comply with safeguards", "se conformer aux sauvegardes",
            "Common in compliance and environmental-review contexts.",
            "All construction activities complied with the donor's environmental safeguards.", 16),
        Expression("m16_e4", "to plan an exit strategy", "planifier une stratégie de sortie",
            "Frequently expected in the final sections of a proposal.",
            "The team planned an exit strategy from the start of the project, not at the end.", 16),
        Expression("m16_e5", "to assess the likelihood and severity of a risk", "évaluer la probabilité et la gravité d'un risque",
            "Formal risk-analysis phrasing.",
            "The team assessed the likelihood and severity of each risk in the matrix.", 16)
    ),
    concepts = listOf(
        ConceptCard("m16_c1", "Risk matrix (worked example)", "Matrice des risques (exemple travaillé)",
            "A risk matrix rates each risk on likelihood and severity, then pairs it with a specific mitigation measure — vague risk statements without mitigation weaken a proposal.",
            "Une matrice des risques évalue chaque risque selon sa probabilité et sa gravité, puis l'associe à une mesure d'atténuation précise — des énoncés de risque vagues, sans atténuation, affaiblissent une proposition.",
            "Illustrative example: Risk — conflict between farmers and herders over land use. Likelihood — medium. Severity — high. Mitigation — joint land-use planning with both groups before implementation.", true, 16),
        ConceptCard("m16_c2", "Sustainability dimensions", "Dimensions de la durabilité",
            "Sustainability is often assessed across several dimensions: financial (can costs be covered locally?), institutional (is there a capable local structure?), and technical (can local actors maintain what was built?).",
            "La durabilité est souvent évaluée selon plusieurs dimensions : financière (les coûts peuvent-ils être couverts localement ?), institutionnelle (existe-t-il une structure locale capable ?) et technique (les acteurs locaux peuvent-ils entretenir ce qui a été construit ?).",
            "An illustrative sustainability plan trained a village water committee (institutional), set a small user fee (financial), and certified two local technicians (technical).", true, 16)
    ),
    donorQuestions = listOf(
        DonorQuestion("m16_dq1",
            "What are the main risks to this project, and how will you mitigate them?",
            "The main risk is erratic rainfall affecting agricultural outputs, which we mitigate through drought-tolerant varieties and a contingency budget line; a secondary risk is land-use conflict, mitigated through the stakeholder engagement process described earlier.",
            "Bonne réponse : elle nomme deux risques distincts, chacun avec une mesure d'atténuation concrète, plutôt qu'une réponse générique.",
            "risk", 16),
        DonorQuestion("m16_dq2",
            "How will the project be sustained after your funding ends?",
            "Sustainability rests on three elements: a trained village committee to manage the infrastructure, a modest user-fee system to cover maintenance costs, and a formal handover agreement with the commune's technical service.",
            "Bonne réponse : elle couvre plusieurs dimensions de la durabilité (institutionnelle, financière, technique) plutôt qu'une seule.",
            "sustainability", 16)
    ),
    exercises = listOf(
        Exercise("m16_ex1", ExerciseType.MULTIPLE_CHOICE,
            "Which term describes a plan for transitioning responsibilities to local actors before project closure?",
            "Quel terme désigne un plan de transfert des responsabilités aux acteurs locaux avant la clôture du projet ?",
            listOf("risk matrix", "exit strategy", "safeguard", "do no harm"),
            "exit strategy", "« Exit strategy » = stratégie de sortie / transfert.", 16),
        Exercise("m16_ex2", ExerciseType.TRANSLATION_FR_EN,
            "Translate: « L'équipe a identifié et atténué les risques pendant l'atelier de planification. »", null, emptyList(),
            "The team identified and mitigated risks during the planning workshop.",
            "« Identify and mitigate risks » forme une paire d'expressions quasi inséparable.", 16)
    )
)
