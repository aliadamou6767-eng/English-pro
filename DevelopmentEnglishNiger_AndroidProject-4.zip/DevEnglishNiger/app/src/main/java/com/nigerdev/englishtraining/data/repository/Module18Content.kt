package com.nigerdev.englishtraining.data.repository

import com.nigerdev.englishtraining.data.model.*

/**
 * MODULE 18 — Project Implementation and Coordination
 * Mise en œuvre et coordination du projet
 * English ratio: 65%
 */
val module18 = Module(
    id = 18,
    titleEn = "Project Implementation and Coordination",
    titleFr = "Mise en œuvre et coordination du projet",
    englishRatio = 0.65f,
    objectiveEn = "By the end of this lesson, you will be able to describe implementation coordination and multi-actor collaboration in English.",
    objectiveFr = "À la fin de cette leçon, vous serez capable de décrire la coordination de la mise en œuvre et la collaboration multi-acteurs en anglais.",
    vocabulary = listOf(
        VocabItem("m18_workplan", "workplan", "plan de travail",
            "A detailed schedule outlining activities, timelines and responsible actors for a defined period.",
            "Calendrier détaillé décrivant les activités, les délais et les responsables pour une période donnée.",
            "The workplan was updated quarterly to reflect implementation delays.", 18),
        VocabItem("m18_coordination_meeting", "coordination meeting", "réunion de coordination",
            "A regular meeting bringing together implementing partners and stakeholders to align on progress and issues.",
            "Réunion régulière rassemblant les partenaires de mise en œuvre et parties prenantes pour s'aligner sur l'avancement et les problèmes.",
            "Monthly coordination meetings included the commune's technical services.", 18),
        VocabItem("m18_procurement", "procurement", "approvisionnement / passation de marchés",
            "The process of acquiring goods, works or services needed for project implementation.",
            "Processus d'acquisition de biens, travaux ou services nécessaires à la mise en œuvre du projet.",
            "Procurement of construction materials was delayed by two weeks due to supply issues.", 18),
        VocabItem("m18_cluster", "cluster", "cluster / groupe sectoriel",
            "A coordination group of organizations working in the same humanitarian or development sector.",
            "Groupe de coordination d'organisations travaillant dans le même secteur humanitaire ou de développement.",
            "The WASH cluster shared updated guidance on borehole siting standards.", 18),
        VocabItem("m18_nexus", "humanitarian-development-peace nexus", "nexus humanitaire-développement-paix",
            "An approach linking humanitarian response, development programming, and peacebuilding in fragile contexts.",
            "Approche reliant réponse humanitaire, programmation de développement et consolidation de la paix dans des contextes fragiles.",
            "The programme was designed within the humanitarian-development-peace nexus framework.", 18),
        VocabItem("m18_implementation_delay", "implementation delay", "retard de mise en œuvre",
            "A postponement in the planned schedule of project activities.",
            "Report de l'échéancier prévu des activités du projet.",
            "The implementation delay was attributed to late arrival of construction materials.", 18)
    ),
    collocations = listOf(
        Expression("m18_e1", "to coordinate with implementing partners", "se coordonner avec les partenaires de mise en œuvre",
            "The essential collaborative phrase of this module.",
            "The project coordinates with implementing partners through monthly meetings.", 18),
        Expression("m18_e2", "to stay on track with the workplan", "rester en phase avec le plan de travail",
            "Common in progress-reporting narrative.",
            "Despite minor delays, the team stayed on track with the overall workplan.", 18),
        Expression("m18_e3", "to flag an implementation delay", "signaler un retard de mise en œuvre",
            "Standard phrase for proactive reporting.",
            "The field coordinator flagged an implementation delay before the quarterly report was due.", 18),
        Expression("m18_e4", "to avoid duplication of efforts", "éviter la duplication des efforts",
            "Common in coordination and cluster contexts.",
            "Regular coordination meetings help avoid duplication of efforts among actors.", 18),
        Expression("m18_e5", "to adjust the workplan accordingly", "ajuster le plan de travail en conséquence",
            "Used when describing adaptive management.",
            "Following the mid-term review, the team adjusted the workplan accordingly.", 18)
    ),
    concepts = listOf(
        ConceptCard("m18_c1", "Coordination architecture in Niger", "Architecture de coordination au Niger",
            "Development actors in Niger typically coordinate through sectoral clusters or working groups, regional coordination platforms, and direct engagement with technical services and communal authorities.",
            "Les acteurs du développement au Niger se coordonnent généralement via des clusters sectoriels ou groupes de travail, des plateformes de coordination régionales, et un engagement direct avec les services techniques et les autorités communales.",
            "In an illustrative Diffa-region example, the project reported to the regional coordination platform while also attending the WASH cluster for technical alignment.", true, 18),
        ConceptCard("m18_c2", "Adaptive implementation", "Mise en œuvre adaptative",
            "Good implementation is not simply following the original workplan rigidly; it means using monitoring data to adjust the workplan when conditions change, while documenting why changes were made.",
            "Une bonne mise en œuvre ne consiste pas à suivre rigidement le plan de travail initial ; elle consiste à utiliser les données de suivi pour ajuster le plan quand les conditions changent, en documentant les raisons des changements.",
            "An illustrative example: flooding delayed road access, so the team resequenced training activities and documented the change in the quarterly report.", true, 18)
    ),
    donorQuestions = listOf(
        DonorQuestion("m18_dq1",
            "How do you coordinate with other actors working in the same area to avoid duplication?",
            "We participate in the regional coordination platform and the relevant sectoral cluster, and we cross-check our beneficiary lists with other actors before finalizing targeting to avoid overlap.",
            "Bonne réponse : elle décrit un mécanisme concret de coordination, pas seulement une intention générale.",
            "coordination", 18)
    ),
    exercises = listOf(
        Exercise("m18_ex1", ExerciseType.MULTIPLE_CHOICE,
            "Which term describes a coordination group of organizations working in the same sector?",
            "Quel terme désigne un groupe de coordination d'organisations travaillant dans le même secteur ?",
            listOf("workplan", "cluster", "procurement", "nexus"),
            "cluster", "« Cluster » désigne un groupe sectoriel de coordination.", 18),
        Exercise("m18_ex2", ExerciseType.FILL_BLANK,
            "Following the mid-term review, the team ______ the workplan accordingly.", null,
            listOf("adjusted", "flagged", "coordinated", "avoided"),
            "adjusted",
            "« Adjust the workplan accordingly » est l'expression correcte.", 18)
    )
)
