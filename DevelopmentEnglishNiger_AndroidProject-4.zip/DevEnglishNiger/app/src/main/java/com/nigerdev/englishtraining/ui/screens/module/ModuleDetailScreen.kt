package com.nigerdev.englishtraining.ui.screens.module

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nigerdev.englishtraining.AppContainer
import com.nigerdev.englishtraining.data.repository.ContentRepository
import com.nigerdev.englishtraining.ui.components.AudioSentence
import kotlinx.coroutines.launch

@Composable
fun ModuleDetailScreen(
    moduleId: Int,
    appContainer: AppContainer,
    onStartPractice: (Int) -> Unit
) {
    val scope = rememberCoroutineScope()
    val module = ContentRepository.moduleById(moduleId)
    val stub = ContentRepository.allModuleTitles.find { it.id == moduleId }

    LaunchedEffect(moduleId) {
        appContainer.progressRepository.markModuleOpened(moduleId)
    }

    if (module == null) {
        Column(Modifier.fillMaxSize().padding(24.dp)) {
            Text(stub?.titleEn ?: "Module $moduleId", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text(stub?.titleFr ?: "", style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(16.dp))
            Text("Ce module est en cours de production et sera ajouté selon le même standard de détail que les modules 1 à 3.")
        }
        return
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("Module ${module.id} · ${module.titleEn}", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text(module.titleFr, style = MaterialTheme.typography.bodyLarge)
        }

        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Objective / Objectif", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    AudioSentence(english = module.objectiveEn, ttsManager = appContainer.ttsManager)
                    Spacer(Modifier.height(6.dp))
                    Text(module.objectiveFr, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        item { Text("Vocabulary · Vocabulaire", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        items(module.vocabulary) { v ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    AudioSentence(english = v.english, ttsManager = appContainer.ttsManager, style = MaterialTheme.typography.titleMedium)
                    Text(v.french, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(4.dp))
                    Text(v.definitionEn, style = MaterialTheme.typography.bodyMedium)
                    Text(v.explanationFr, style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(4.dp))
                    AudioSentence(english = v.exampleEn, ttsManager = appContainer.ttsManager, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        item { Text("Professional expressions · Expressions", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        items(module.collocations) { e ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    AudioSentence(english = e.english, ttsManager = appContainer.ttsManager, style = MaterialTheme.typography.titleMedium)
                    Text(e.french, fontWeight = FontWeight.SemiBold)
                    Text(e.explanationFr, style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(4.dp))
                    AudioSentence(english = e.exampleEn, ttsManager = appContainer.ttsManager, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        if (module.concepts.isNotEmpty()) {
            item { Text("Key concepts · Concepts clés", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
            items(module.concepts) { c ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("${c.titleEn} / ${c.titleFr}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(4.dp))
                        AudioSentence(english = c.explanationEn, ttsManager = appContainer.ttsManager, style = MaterialTheme.typography.bodyMedium)
                        Text(c.explanationFr, style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.height(6.dp))
                        if (c.isIllustrativeExample) {
                            Text("Illustrative example / Exemple illustratif", style = MaterialTheme.typography.labelLarge)
                        }
                        AudioSentence(english = c.nigerExampleEn, ttsManager = appContainer.ttsManager, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }

        item {
            Button(
                onClick = { onStartPractice(module.id) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Practice this module") }
        }

        item {
            OutlinedButton(
                onClick = {
                    scope.launch { appContainer.progressRepository.markModuleCompleted(module.id) }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Mark module as completed") }
        }
    }
}
