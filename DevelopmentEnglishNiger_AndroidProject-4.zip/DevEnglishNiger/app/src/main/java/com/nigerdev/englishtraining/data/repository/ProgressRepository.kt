package com.nigerdev.englishtraining.data.repository

import com.nigerdev.englishtraining.data.db.*
import kotlinx.coroutines.flow.Flow

class ProgressRepository(private val dao: AppDao) {

    fun observeCompletedModuleCount(): Flow<Int> = dao.observeCompletedModuleCount()
    fun observeModuleProgress(): Flow<List<ModuleProgressEntity>> = dao.observeModuleProgress()
    fun observeSavedVocabulary(): Flow<List<SavedVocabularyEntity>> = dao.observeSavedVocabulary()
    fun observePracticeSessionCount(): Flow<Int> = dao.observePracticeSessionCount()
    fun observeDonorSimCompletedCount(): Flow<Int> = dao.observeDonorSimCompletedCount()
    fun isVocabularySaved(vocabId: String): Flow<Boolean> = dao.isVocabularySaved(vocabId)

    suspend fun markModuleOpened(moduleId: Int) {
        val existing = dao.getModuleProgress(moduleId)
        dao.upsertModuleProgress(
            (existing ?: ModuleProgressEntity(moduleId)).copy(lastOpenedTimestamp = System.currentTimeMillis())
        )
    }

    suspend fun markModuleCompleted(moduleId: Int) {
        val existing = dao.getModuleProgress(moduleId)
        dao.upsertModuleProgress(
            (existing ?: ModuleProgressEntity(moduleId)).copy(isCompleted = true)
        )
    }

    suspend fun recordQuizScore(moduleId: Int, scorePercent: Int) {
        val existing = dao.getModuleProgress(moduleId)
        val best = maxOf(existing?.quizBestScorePercent ?: 0, scorePercent)
        dao.upsertModuleProgress(
            (existing ?: ModuleProgressEntity(moduleId)).copy(quizBestScorePercent = best)
        )
    }

    suspend fun isModuleUnlocked(moduleId: Int): Boolean {
        if (moduleId <= 1) return true
        val prev = dao.getModuleProgress(moduleId - 1)
        return prev?.isCompleted == true
    }

    suspend fun toggleSavedVocabulary(id: String, english: String, french: String, example: String, currentlySaved: Boolean) {
        if (currentlySaved) dao.removeSavedVocabulary(id)
        else dao.saveVocabulary(SavedVocabularyEntity(id, english, french, example, System.currentTimeMillis()))
    }

    suspend fun logDonorSimAttempt(questionId: String) {
        dao.logDonorSimulation(DonorSimulationLogEntity(donorQuestionId = questionId, timestamp = System.currentTimeMillis(), selfRated = true))
    }

    suspend fun logPracticeSession(moduleId: Int, exerciseCount: Int, correctCount: Int) {
        dao.logPracticeSession(PracticeSessionEntity(timestamp = System.currentTimeMillis(), moduleId = moduleId, exerciseCount = exerciseCount, correctCount = correctCount))
    }

    // --- Spaced review (New -> Learning -> Familiar -> Mastered) ---
    suspend fun recordReviewResult(vocabId: String, wasCorrect: Boolean) {
        val existing = dao.getReviewState(vocabId) ?: ReviewStateEntity(vocabId = vocabId)
        val newStreak = if (wasCorrect) existing.correctStreak + 1 else 0
        val newStage = when {
            !wasCorrect -> "Learning"
            newStreak >= 6 -> "Mastered"
            newStreak >= 3 -> "Familiar"
            else -> "Learning"
        }
        val dayMs = 24L * 60 * 60 * 1000
        val intervalDays = when (newStage) {
            "Mastered" -> 14L
            "Familiar" -> 4L
            else -> 1L
        }
        val now = System.currentTimeMillis()
        dao.upsertReviewState(
            existing.copy(
                stage = newStage,
                correctStreak = newStreak,
                lastReviewedTimestamp = now,
                nextDueTimestamp = now + intervalDays * dayMs
            )
        )
    }

    suspend fun getDueReviewIds(): List<String> = dao.getDueReviews(System.currentTimeMillis()).map { it.vocabId }

    suspend fun resetAllProgress() {
        dao.clearModuleProgress()
        dao.clearSavedVocabulary()
        dao.clearReviewState()
        dao.clearDonorLog()
        dao.clearPracticeLog()
    }
}
