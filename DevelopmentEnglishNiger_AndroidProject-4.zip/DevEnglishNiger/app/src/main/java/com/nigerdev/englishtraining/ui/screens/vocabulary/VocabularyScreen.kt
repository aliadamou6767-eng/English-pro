package com.nigerdev.englishtraining.ui.screens.vocabulary

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nigerdev.englishtraining.AppContainer
import com.nigerdev.englishtraining.data.model.VocabItem
import com.nigerdev.englishtraining.data.repository.ContentRepository
import com.nigerdev.englishtraining.ui.components.AudioSentence
import kotlinx.coroutines.launch

@Composable
fun VocabularyScreen(appContainer: AppContainer, onOpenMyVocabulary: () -> Unit) {
    var query by remember { mutableStateOf("") }
    val allVocab = remember { ContentRepository.allVocabulary() }
    val savedVocab by appContainer.progressRepository.observeSavedVocabulary().collectAsState(initial = emptyList())
    val savedIds = remember(savedVocab) { savedVocab.map { it.vocabId }.toSet() }
    val scope = rememberCoroutineScope()

    val filtered = remember(query, allVocab) {
        if (query.isBlank()) allVocab
        else allVocab.filter {
            it.english.contains(query, ignoreCase = true) || it.french.contains(query, ignoreCase = true)
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Vocabulary", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            TextButton(onClick = onOpenMyVocabulary) { Text("My Vocabulary (${savedVocab.size})") }
        }

        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            placeholder = { Text("Search English or French…") },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            singleLine = true
        )

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(filtered, key = { it.id }) { v ->
                VocabRow(
                    item = v,
                    isSaved = v.id in savedIds,
                    appContainer = appContainer,
                    onToggleSave = {
                        scope.launch {
                            appContainer.progressRepository.toggleSavedVocabulary(
                                v.id, v.english, v.french, v.exampleEn, v.id in savedIds
                            )
                        }
                    }
                )
            }
        }
    }
}

@Composable
private fun VocabRow(item: VocabItem, isSaved: Boolean, appContainer: AppContainer, onToggleSave: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(Modifier.weight(1f)) {
                    AudioSentence(english = item.english, ttsManager = appContainer.ttsManager, style = MaterialTheme.typography.titleMedium)
                    Text(item.french, fontWeight = FontWeight.SemiBold)
                }
                IconButton(onClick = onToggleSave) {
                    Icon(
                        imageVector = if (isSaved) Icons.Filled.Star else Icons.Outlined.Star,
                        contentDescription = "Add to My Vocabulary"
                    )
                }
            }
            Spacer(Modifier.height(4.dp))
            Text(item.definitionEn, style = MaterialTheme.typography.bodyMedium)
            Text(item.explanationFr, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(4.dp))
            AudioSentence(english = item.exampleEn, ttsManager = appContainer.ttsManager, style = MaterialTheme.typography.bodyMedium)
        }
    }
}
