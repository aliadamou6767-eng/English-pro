package com.nigerdev.englishtraining.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = DeepGreen,
    onPrimary = Color.White,
    secondary = Sand,
    onSecondary = Charcoal,
    background = Cream,
    onBackground = Charcoal,
    surface = Color.White,
    onSurface = Charcoal,
    error = ErrorRed
)

private val DarkColors = darkColorScheme(
    primary = SandLight,
    onPrimary = Charcoal,
    secondary = DeepGreenLight,
    onSecondary = Color.White,
    background = Charcoal,
    onBackground = Cream,
    surface = Color(0xFF32322D),
    onSurface = Cream,
    error = Color(0xFFCF6679)
)

@Composable
fun DevEnglishNigerTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colors,
        typography = AppTypography,
        content = content
    )
}
