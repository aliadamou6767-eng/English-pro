package com.nigerdev.englishtraining.data.repository

import com.nigerdev.englishtraining.data.model.*

/**
 * MODULE 25 — Presenting Socio-Economic Data
 * Présentation des données socio-économiques
 * English ratio: 75% (advanced)
 *
 * Added beyond the original 24-module plan, at ADAMOU's request, to cover the
 * specific skill of presenting statistical and socio-economic data professionally
 * in English — tables, charts, and verbal description of trends for donor and
 * institutional audiences.
 */
val module25 = Module(
    id = 25,
    titleEn = "Presenting Socio-Economic Data",
    titleFr = "Présentation des données socio-économiques",
    englishRatio = 0.75f,
    objectiveEn = "By the end of this lesson, you will be able to describe, interpret and present socio-economic data clearly and accurately in English.",
    objectiveFr = "À la fin de cette leçon, vous serez capable de décrire, interpréter et présenter des données socio-économiques de manière claire et précise en anglais.",
    vocabulary = listOf(
        VocabItem("m25_socio_economic_profile", "socio-economic profile", "profil socio-économique",
            "A structured summary of a population's demographic, economic and social characteristics.",
            "Résumé structuré des caractéristiques démographiques, économiques et sociales d'une population.",
            "The socio-economic profile of the commune showed a young, largely agropastoral population.", 25),
        VocabItem("m25_demographic_data", "demographic data", "données démographiques",
            "Statistical data describing a population, such as age structure, household size, and migration.",
            "Données statistiques décrivant une population, telles que la structure par âge, la taille des ménages et la migration.",
            "Demographic data showed that over 60% of the population was under twenty-five.", 25),
        VocabItem("m25_trend", "trend", "tendance",
            "A general direction in which data is changing over time, such as increasing, decreasing, or stable.",
            "Direction générale dans laquelle des données évoluent dans le temps, comme en hausse, en baisse ou stable.",
            "Household income showed a declining trend over the past three agricultural seasons.", 25),
        VocabItem("m25_outlier", "outlier", "valeur aberrante",
            "A data point that differs significantly from the rest of the dataset.",
            "Point de donnée qui diffère significativement du reste de l'ensemble de données.",
            "One village was an outlier, reporting income levels far above the regional average.", 25),
        VocabItem("m25_correlation", "correlation", "corrélation",
            "A statistical relationship between two variables, without necessarily implying causation.",
            "Relation statistique entre deux variables, sans impliquer nécessairement une causalité.",
            "The data showed a correlation between distance to market and household income.", 25),
        VocabItem("m25_disparity", "disparity", "disparité",
            "A notable difference or inequality between groups or areas within the data.",
            "Différence ou inégalité notable entre groupes ou zones au sein des données.",
            "The report highlighted a significant disparity in literacy rates between men and women.", 25),
        VocabItem("m25_data_visualization", "data visualization", "visualisation des données",
            "The graphic representation of data, such as charts, graphs, and maps, to support interpretation.",
            "Représentation graphique de données, comme des diagrammes, graphiques et cartes, pour appuyer leur interprétation.",
            "A simple bar chart was the clearest data visualization for comparing income across villages.", 25),
        VocabItem("m25_margin_of_error", "margin of error", "marge d'erreur",
            "The range within which the true value is expected to fall, given the survey's sampling method.",
            "L'intervalle dans lequel la valeur réelle est censée se situer, compte tenu de la méthode d'échantillonnage de l'enquête.",
            "The survey's margin of error was plus or minus five percentage points.", 25)
    ),
    collocations = listOf(
        Expression("m25_e1", "to present data clearly", "présenter des données clairement",
            "The central objective of this module.",
            "The team presented data clearly using a small number of well-labeled charts.", 25),
        Expression("m25_e2", "to highlight a trend", "mettre en évidence une tendance",
            "Standard phrase for drawing attention to a pattern in data.",
            "The report highlighted a trend of declining rainfall over the past decade.", 25),
        Expression("m25_e3", "to break down data by category", "ventiler les données par catégorie",
            "Common when describing disaggregation (see also Module 17).",
            "Income data was broken down by category, including gender and livelihood type.", 25),
        Expression("m25_e4", "to interpret the figures", "interpréter les chiffres",
            "Refers to explaining what data means, not just presenting it.",
            "The analyst interpreted the figures for a non-specialist donor audience.", 25),
        Expression("m25_e5", "to avoid overstating the findings", "éviter de surinterpréter les résultats",
            "An important professional caution when presenting statistics.",
            "The presenter was careful to avoid overstating the findings given the small sample size.", 25),
        Expression("m25_e6", "to round figures appropriately", "arrondir les chiffres de façon appropriée",
            "A practical writing skill for readable, professional data presentation.",
            "Figures were rounded appropriately to avoid a false impression of precision.", 25)
    ),
    concepts = listOf(
        ConceptCard("m25_c1", "Choosing the right way to present a number", "Choisir la bonne façon de présenter un chiffre",
            "A single trend over time is usually clearest as a line chart; a comparison between a few categories works well as a bar chart; a simple proportion is often clearest stated in a sentence rather than a chart at all.",
            "Une tendance unique dans le temps est généralement plus claire sous forme de graphique linéaire ; une comparaison entre quelques catégories fonctionne bien en diagramme à barres ; une simple proportion est souvent plus claire énoncée dans une phrase plutôt qu'en graphique.",
            "An illustrative example: '42% of households reported food insecurity' is clearer as a sentence than as a two-slice pie chart.", true, 25),
        ConceptCard("m25_c2", "Data honesty: precision vs. false precision", "Honnêteté des données : précision vs. fausse précision",
            "Professional data presentation matches the level of precision reported to the data's actual reliability — citing '41.7%' from a small sample implies more confidence than the data supports; '42%' or 'around 40%' is often more honest.",
            "Une présentation professionnelle des données ajuste le niveau de précision annoncé à la fiabilité réelle des données — citer « 41,7 % » à partir d'un petit échantillon suggère plus de certitude que les données ne le permettent ; « 42 % » ou « environ 40 % » est souvent plus honnête.",
            "An illustrative case: with a household survey of 120 respondents and a margin of error of ±6 points, reporting '42% (±6%)' is more transparent than a falsely precise '41.7%.'", true, 25)
    ),
    donorQuestions = listOf(
        DonorQuestion("m25_dq1",
            "Can you walk us through the key socio-economic data behind this proposal?",
            "Certainly — the survey found that 42% of households fall below the poverty line, with a notable disparity between male- and female-headed households, and income shows a declining trend correlated with distance to the nearest market.",
            "Bonne réponse : elle cite des chiffres précis, une disparité et une corrélation, structurés clairement sans surcharger l'auditoire.",
            "data presentation", 25),
        DonorQuestion("m25_dq2",
            "How reliable is this data, given your sample size?",
            "The sample of 400 households gives a margin of error of about five percentage points, which is standard for this type of survey, and we cross-checked the key findings against secondary data to strengthen confidence in the results.",
            "Bonne réponse : elle reconnaît honnêtement la marge d'erreur tout en expliquant la démarche de validation.",
            "data reliability", 25)
    ),
    exercises = listOf(
        Exercise("m25_ex1", ExerciseType.MULTIPLE_CHOICE,
            "Which term describes a data point that differs significantly from the rest of the dataset?",
            "Quel terme désigne un point de donnée qui diffère significativement du reste de l'ensemble ?",
            listOf("trend", "outlier", "correlation", "disparity"),
            "outlier", "« Outlier » = valeur aberrante, nettement différente du reste des données.", 25),
        Exercise("m25_ex2", ExerciseType.FILL_BLANK,
            "Income data was ______ by category, including gender and livelihood type.", null,
            listOf("broken down", "highlighted", "interpreted", "rounded"),
            "broken down",
            "« Break down data by category » est l'expression standard pour la ventilation de données.", 25),
        Exercise("m25_ex3", ExerciseType.TRANSLATION_FR_EN,
            "Translate: « Le présentateur a évité de surinterpréter les résultats compte tenu de la petite taille de l'échantillon. »", null, emptyList(),
            "The presenter avoided overstating the findings given the small sample size.",
            "« Overstate the findings » exprime le risque de surinterprétation des données.", 25)
    )
)
