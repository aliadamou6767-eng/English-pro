package com.nigerdev.englishtraining.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "module_progress")
data class ModuleProgressEntity(
    @PrimaryKey val moduleId: Int,
    val isCompleted: Boolean = false,
    val lastOpenedTimestamp: Long = 0L,
    val quizBestScorePercent: Int = 0
)

@Entity(tableName = "saved_vocabulary")
data class SavedVocabularyEntity(
    @PrimaryKey val vocabId: String,   // matches VocabItem.id
    val english: String,
    val french: String,
    val exampleEn: String,
    val savedTimestamp: Long
)

// Spaced-review state: New -> Learning -> Familiar -> Mastered
@Entity(tableName = "review_state")
data class ReviewStateEntity(
    @PrimaryKey val vocabId: String,
    val stage: String = "New",        // New, Learning, Familiar, Mastered
    val correctStreak: Int = 0,
    val lastReviewedTimestamp: Long = 0L,
    val nextDueTimestamp: Long = 0L
)

@Entity(tableName = "donor_simulation_log")
data class DonorSimulationLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val donorQuestionId: String,
    val timestamp: Long,
    val selfRated: Boolean = false      // true once learner has compared their answer
)

@Entity(tableName = "practice_session_log")
data class PracticeSessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val moduleId: Int,
    val exerciseCount: Int,
    val correctCount: Int
)
