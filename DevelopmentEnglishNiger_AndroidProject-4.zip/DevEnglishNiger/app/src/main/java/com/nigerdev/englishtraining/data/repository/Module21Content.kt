package com.nigerdev.englishtraining.data.repository

import com.nigerdev.englishtraining.data.model.*

/**
 * MODULE 21 — Donor Questions, Defense and Professional Discussion
 * Questions des bailleurs, défense du projet et discussion professionnelle
 * English ratio: 75% (advanced)
 */
val module21 = Module(
    id = 21,
    titleEn = "Donor Questions, Defense and Professional Discussion",
    titleFr = "Questions des bailleurs, défense du projet et discussion professionnelle",
    englishRatio = 0.75f,
    objectiveEn = "By the end of this lesson, you will be able to handle difficult donor questions and defend a project's design confidently in English.",
    objectiveFr = "À la fin de cette leçon, vous serez capable de répondre à des questions difficiles de bailleurs et de défendre la conception d'un projet avec assurance, en anglais.",
    vocabulary = listOf(
        VocabItem("m21_pushback", "pushback", "objection / résistance",
            "Critical or skeptical resistance from a donor toward an aspect of a proposal.",
            "Résistance critique ou sceptique d'un bailleur envers un aspect d'une proposition.",
            "The donor's pushback focused on the ambitious timeline for the second component.", 21),
        VocabItem("m21_clarifying_question", "clarifying question", "question de clarification",
            "A question asked to better understand a point before forming a judgment.",
            "Question posée pour mieux comprendre un point avant de se prononcer.",
            "The programme officer asked a clarifying question about the targeting methodology.", 21),
        VocabItem("m21_to_defend", "to defend a project", "défendre un projet",
            "To provide reasoned justification for a project's design choices when challenged.",
            "Fournir une justification raisonnée des choix de conception d'un projet lorsqu'ils sont remis en question.",
            "The team defended the choice of intervention area using the vulnerability data.", 21),
        VocabItem("m21_evidence_base", "evidence base", "socle de preuves",
            "The body of data and analysis supporting a project's claims and design.",
            "L'ensemble des données et analyses soutenant les affirmations et la conception d'un projet.",
            "The proposal's evidence base included the household survey and secondary poverty data.", 21),
        VocabItem("m21_to_concede_a_point", "to concede a point", "concéder un point",
            "To acknowledge the validity of a criticism or limitation, rather than defending everything.",
            "Reconnaître la validité d'une critique ou d'une limite, plutôt que de tout défendre.",
            "The presenter conceded a point about the tight timeline and proposed a revised schedule.", 21),
        VocabItem("m21_follow_up_question", "follow-up question", "question de suivi",
            "A question that builds on a previous answer to probe further.",
            "Question qui s'appuie sur une réponse précédente pour approfondir.",
            "The donor's follow-up question pressed for more detail on the exit strategy.", 21)
    ),
    collocations = listOf(
        Expression("m21_e1", "to respond to pushback", "répondre à une objection",
            "The core skill of this module.",
            "The team responded to pushback about the budget by clarifying cost assumptions.", 21),
        Expression("m21_e2", "to stand by the project design", "maintenir la conception du projet",
            "Used when a design choice is challenged but remains justified.",
            "The presenter stood by the project design, citing the needs assessment evidence.", 21),
        Expression("m21_e3", "to acknowledge a limitation", "reconnaître une limite",
            "Professional way of conceding a valid critique without undermining the whole proposal.",
            "The team acknowledged a limitation in the sample size and explained its mitigation.", 21),
        Expression("m21_e4", "to buy time before answering", "gagner du temps avant de répondre",
            "A useful conversational strategy phrase (e.g., 'That's a fair question, let me address that.').",
            "The presenter bought time before answering a complex budget question by restating it clearly.", 21),
        Expression("m21_e5", "to bring the discussion back to evidence", "recentrer la discussion sur les preuves",
            "A defense technique for staying grounded during difficult exchanges.",
            "The team brought the discussion back to evidence whenever assumptions were challenged.", 21)
    ),
    concepts = listOf(
        ConceptCard("m21_c1", "Defending without being defensive", "Défendre sans être sur la défensive",
            "Strong donor discussions calmly separate two things: defending well-evidenced design choices, and conceding genuine limitations — trying to defend everything erodes credibility.",
            "Les échanges solides avec les bailleurs distinguent calmement deux choses : défendre des choix de conception bien étayés, et concéder de véritables limites — vouloir tout défendre nuit à la crédibilité.",
            "An illustrative exchange: the presenter defended the area selection (well evidenced) but conceded the timeline was ambitious and proposed a phased alternative.", true, 21),
        ConceptCard("m21_c2", "Bridging phrases for difficult questions", "Formules de transition pour les questions difficiles",
            "A small set of bridging phrases — 'That's a fair question,' 'Let me clarify,' 'To build on that' — buys thinking time and signals professionalism, rather than long silences or repeated filler words.",
            "Un petit ensemble de formules de transition — « That's a fair question », « Let me clarify », « To build on that » — offre un temps de réflexion et signale le professionnalisme, plutôt que de longs silences ou des mots de remplissage répétés.",
            "An illustrative use: 'That's a fair question — let me clarify how the targeting criteria were weighted.'", true, 21)
    ),
    donorQuestions = listOf(
        DonorQuestion("m21_dq1",
            "Your budget seems high compared to similar projects. Can you justify it?",
            "That's a fair question — our per-household cost is higher because the intervention area has significant accessibility constraints that increase logistics costs, and we can share a cost breakdown showing this is in line with other hard-to-reach area projects.",
            "Bonne réponse : elle utilise une formule de transition, reconnaît la question, puis apporte une justification factuelle précise.",
            "budget defense", 21),
        DonorQuestion("m21_dq2",
            "This is very similar to a project that failed elsewhere. Why will yours be different?",
            "That's an important comparison to make — the previous project lacked a community management structure for sustainability, which is why we built in a trained village committee and a clear handover plan from the start.",
            "Bonne réponse : elle reconnaît la comparaison sans être sur la défensive, puis explique précisément la différence de conception.",
            "risk defense", 21)
    ),
    exercises = listOf(
        Exercise("m21_ex1", ExerciseType.MULTIPLE_CHOICE,
            "Which phrase professionally acknowledges a valid criticism without abandoning the whole proposal?",
            "Quelle expression reconnaît professionnellement une critique valable sans abandonner toute la proposition ?",
            listOf("to concede a point", "to defend a project", "pushback", "evidence base"),
            "to concede a point", "« Concede a point » = reconnaître une limite précise, pas la proposition entière.", 21),
        Exercise("m21_ex2", ExerciseType.TRANSLATION_FR_EN,
            "Translate: « L'équipe a maintenu la conception du projet en citant les preuves de l'évaluation des besoins. »", null, emptyList(),
            "The team stood by the project design, citing the needs assessment evidence.",
            "« Stand by the design » exprime une défense assurée et fondée sur des preuves.", 21)
    )
)
