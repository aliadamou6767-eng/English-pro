package com.nigerdev.englishtraining.data.repository

import com.nigerdev.englishtraining.data.model.*

/**
 * MODULE 11 — From Needs Assessment to Project Identification
 * De l'évaluation des besoins à l'identification du projet
 * English ratio: 60% (intermediate)
 */
val module11 = Module(
    id = 11,
    titleEn = "From Needs Assessment to Project Identification",
    titleFr = "De l'évaluation des besoins à l'identification du projet",
    englishRatio = 0.60f,
    objectiveEn = "By the end of this lesson, you will be able to explain, in English, how assessment findings are translated into a project idea.",
    objectiveFr = "À la fin de cette leçon, vous serez capable d'expliquer en anglais comment les résultats d'une évaluation se traduisent en une idée de projet.",
    vocabulary = listOf(
        VocabItem("m11_project_identification", "project identification", "identification du projet",
            "The phase in which assessment findings are analyzed to define a project's focus and rationale.",
            "Phase durant laquelle les résultats d'évaluation sont analysés pour définir l'orientation et la justification d'un projet.",
            "Project identification translated the assessment's findings into a clear intervention rationale.", 11),
        VocabItem("m11_concept_note", "concept note", "note conceptuelle",
            "A short document outlining a proposed project's rationale, objectives and approach before full proposal development.",
            "Document court présentant la justification, les objectifs et l'approche d'un projet proposé avant l'élaboration de la proposition complète.",
            "The concept note was shared with the donor for initial feedback before full proposal drafting.", 11),
        VocabItem("m11_rationale", "rationale", "justification / raison d'être",
            "The reasoning that explains why a particular intervention is needed and appropriate.",
            "Le raisonnement qui explique pourquoi une intervention particulière est nécessaire et appropriée.",
            "The project's rationale rests on evidence of declining water access documented in the assessment.", 11),
        VocabItem("m11_theory_of_change", "theory of change", "théorie du changement",
            "An explanation of how and why a set of activities is expected to lead to desired long-term outcomes.",
            "Explication de la manière et des raisons pour lesquelles un ensemble d'activités devrait mener aux résultats souhaités à long terme.",
            "The theory of change links improved water access to reduced time poverty for women.", 11),
        VocabItem("m11_gap_analysis", "gap analysis", "analyse des écarts",
            "A comparison between current conditions and desired conditions to identify what is missing.",
            "Comparaison entre la situation actuelle et la situation souhaitée pour identifier ce qui manque.",
            "The gap analysis showed a shortfall of twelve functional water points against demand.", 11),
        VocabItem("m11_entry_point", "entry point", "point d'entrée",
            "The initial activity or issue through which a project engages with a community or problem.",
            "L'activité ou l'enjeu initial par lequel un projet s'engage avec une communauté ou un problème.",
            "Water access was chosen as the entry point given its priority ranking by communities.", 11)
    ),
    collocations = listOf(
        Expression("m11_e1", "to translate findings into a project idea", "traduire les résultats en une idée de projet",
            "The central action of this module.",
            "The team translated assessment findings into a project idea focused on water access.", 11),
        Expression("m11_e2", "to build a theory of change", "élaborer une théorie du changement",
            "Standard phrase for early project design work.",
            "The design workshop built a theory of change linking activities to long-term outcomes.", 11),
        Expression("m11_e3", "to draft a concept note", "rédiger une note conceptuelle",
            "Common first deliverable in proposal development.",
            "The team drafted a concept note to share with the donor before the full proposal.", 11),
        Expression("m11_e4", "to prioritize among competing needs", "hiérarchiser des besoins concurrents",
            "Used when several needs were identified but only some can be addressed.",
            "The design team had to prioritize among competing needs identified during the assessment.", 11),
        Expression("m11_e5", "to align with national strategy", "s'aligner sur la stratégie nationale",
            "Frequently expected in donor proposals in Niger (e.g., alignment with Initiative 3N, PDC).",
            "The project idea aligns with national strategy under Initiative 3N.", 11)
    ),
    concepts = listOf(
        ConceptCard("m11_c1", "From problem to project idea", "Du problème à l'idée de projet",
            "Project identification bridges the problem analysis (Module 2) and formal design (Module 13): it selects which causes the project will address and states a preliminary rationale.",
            "L'identification du projet fait le pont entre l'analyse du problème (Module 2) et la conception formelle (Module 13) : elle sélectionne les causes que le projet traitera et énonce une justification préliminaire.",
            "In an illustrative Dosso-region case, of five root causes identified, the project idea focused on the two most tractable within the available budget and timeframe.", true, 11),
        ConceptCard("m11_c2", "Theory of change (introduction)", "Théorie du changement (introduction)",
            "A theory of change makes explicit the assumed causal chain: if we do X, then Y will happen, because of Z. Stating this clearly strengthens both design and donor communication.",
            "Une théorie du changement rend explicite la chaîne causale supposée : si nous faisons X, alors Y se produira, en raison de Z. L'énoncer clairement renforce à la fois la conception et la communication avec les bailleurs.",
            "An illustrative theory of change: IF farmers receive drought-tolerant seed and training, THEN yields will stabilize, BECAUSE the main constraint is variety choice, not soil quality.", true, 11)
    ),
    donorQuestions = listOf(
        DonorQuestion("m11_dq1",
            "How did you move from your assessment findings to this specific project idea?",
            "The assessment identified several needs, but we prioritized water access because it was ranked highest by communities and because addressing it has clear downstream effects on health and time use, which we captured in our theory of change.",
            "Bonne réponse : elle montre un raisonnement de priorisation explicite, pas une simple liste de besoins.",
            "identification", 11)
    ),
    exercises = listOf(
        Exercise("m11_ex1", ExerciseType.MULTIPLE_CHOICE,
            "Which document typically precedes a full project proposal?",
            "Quel document précède généralement une proposition de projet complète ?",
            listOf("concept note", "gap analysis", "entry point", "rationale"),
            "concept note", "La note conceptuelle est un document court soumis avant la proposition complète.", 11),
        Exercise("m11_ex2", ExerciseType.TRANSLATION_FR_EN,
            "Translate: « Le projet s'aligne sur la stratégie nationale. »", null, emptyList(),
            "The project aligns with national strategy.",
            "« Align with » ne prend pas de préposition supplémentaire en anglais.", 11)
    )
)
