package com.nigerdev.englishtraining.ui.screens.home

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nigerdev.englishtraining.AppContainer
import com.nigerdev.englishtraining.data.repository.ContentRepository

@Composable
fun HomeScreen(
    appContainer: AppContainer,
    onOpenModule: (Int) -> Unit,
    onGoToPath: () -> Unit,
    onGoToDonorSim: () -> Unit
) {
    val repo = appContainer.progressRepository
    val completedCount by repo.observeCompletedModuleCount().collectAsState(initial = 0)
    val practiceCount by repo.observePracticeSessionCount().collectAsState(initial = 0)
    val savedVocab by repo.observeSavedVocabulary().collectAsState(initial = emptyList())
    val donorCount by repo.observeDonorSimCompletedCount().collectAsState(initial = 0)

    val totalModules = ContentRepository.allModuleTitles.size
    val nextModuleId = (completedCount + 1).coerceAtMost(totalModules)
    val nextModule = ContentRepository.allModuleTitles.find { it.id == nextModuleId }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("Development English", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
            Text("Professional English for Development Projects", style = MaterialTheme.typography.bodyLarge)
        }

        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Your progress", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("Modules completed: $completedCount / $totalModules")
                    Text("Professional vocabulary saved: ${savedVocab.size} words")
                    Text("Practice sessions: $practiceCount")
                    Text("Donor questions practiced: $donorCount")
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { if (totalModules == 0) 0f else completedCount / totalModules.toFloat() },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        item {
            if (nextModule != null) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { onOpenModule(nextModule.id) }
                ) {
                    Row(
                        Modifier.padding(16.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text("Continue learning", style = MaterialTheme.typography.labelLarge)
                            Text("Module ${nextModule.id} · ${nextModule.titleEn}", style = MaterialTheme.typography.titleMedium)
                            Text(nextModule.titleFr, style = MaterialTheme.typography.bodyMedium)
                        }
                        Icon(Icons.Filled.ArrowForward, contentDescription = null)
                    }
                }
            }
        }

        item {
            OutlinedCard(modifier = Modifier.fillMaxWidth(), onClick = onGoToDonorSim) {
                Column(Modifier.padding(16.dp)) {
                    Text("Donor simulation", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("Practice answering real donor questions out loud.")
                }
            }
        }

        item {
            OutlinedCard(modifier = Modifier.fillMaxWidth(), onClick = onGoToPath) {
                Column(Modifier.padding(16.dp)) {
                    Text("Full learning path", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("See all 24 modules, from foundations to executive English.")
                }
            }
        }
    }
}
