package com.nigerdev.englishtraining.data.repository

import com.nigerdev.englishtraining.data.model.*

/**
 * MODULE 24 — Advanced Professional Communication and Executive English
 * Communication professionnelle avancée et anglais exécutif
 * English ratio: 80% (advanced, capstone module)
 */
val module24 = Module(
    id = 24,
    titleEn = "Advanced Professional Communication and Executive English",
    titleFr = "Communication professionnelle avancée et anglais exécutif",
    englishRatio = 0.80f,
    objectiveEn = "By the end of this lesson, you will be able to communicate with senior stakeholders and represent an organization at a strategic level in English.",
    objectiveFr = "À la fin de cette leçon, vous serez capable de communiquer avec des interlocuteurs de haut niveau et de représenter une organisation à un niveau stratégique en anglais.",
    vocabulary = listOf(
        VocabItem("m24_stakeholder_landscape", "stakeholder landscape", "paysage des parties prenantes",
            "The full strategic map of actors, interests, and power dynamics relevant to an organization's work.",
            "La carte stratégique complète des acteurs, intérêts et dynamiques de pouvoir pertinents pour le travail d'une organisation.",
            "Understanding the stakeholder landscape helped the director anticipate donor priorities for the next funding cycle.", 24),
        VocabItem("m24_strategic_positioning", "strategic positioning", "positionnement stratégique",
            "How an organization presents its distinct role, strengths and niche relative to other actors.",
            "La manière dont une organisation présente son rôle distinct, ses forces et sa niche par rapport aux autres acteurs.",
            "The organization's strategic positioning emphasized its long-term presence in remote areas.", 24),
        VocabItem("m24_high_level_meeting", "high-level meeting", "réunion de haut niveau",
            "A meeting involving senior decision-makers, such as ministers, country directors, or ambassadors.",
            "Réunion impliquant des décideurs de haut niveau, tels que ministres, directeurs pays ou ambassadeurs.",
            "The country director represented the organization at a high-level meeting with the ministry.", 24),
        VocabItem("m24_policy_dialogue", "policy dialogue", "dialogue politique",
            "Structured discussion between development actors and government aimed at influencing policy.",
            "Discussion structurée entre acteurs du développement et gouvernement visant à influencer les politiques.",
            "The organization contributed technical evidence to the national policy dialogue on climate adaptation.", 24),
        VocabItem("m24_executive_briefing", "executive briefing", "note de synthèse pour la direction",
            "A short, high-level summary prepared for senior leadership to inform a decision quickly.",
            "Résumé court et de haut niveau préparé pour la direction afin d'éclairer rapidement une décision.",
            "The executive briefing gave the regional director three options ahead of the donor meeting.", 24),
        VocabItem("m24_thought_leadership", "thought leadership", "leadership d'opinion",
            "Establishing an organization's expertise and influence on a topic through public analysis and engagement.",
            "Établir l'expertise et l'influence d'une organisation sur un sujet par l'analyse et l'engagement publics.",
            "Publishing field-based evidence on transhumance corridors built the organization's thought leadership on land governance.", 24)
    ),
    collocations = listOf(
        Expression("m24_e1", "to represent the organization at a high level", "représenter l'organisation à un niveau élevé",
            "Signals the shift in register expected of this capstone module.",
            "She was asked to represent the organization at a high level during the donor roundtable.", 24),
        Expression("m24_e2", "to engage in policy dialogue", "participer au dialogue politique",
            "Common in advocacy and strategic communication contexts (see also the plaidoyer series).",
            "The organization engages in policy dialogue on land governance at the national level.", 24),
        Expression("m24_e3", "to influence decision-makers", "influencer les décideurs",
            "Central verb for strategic communication.",
            "Evidence-based briefings help influence decision-makers on resource allocation.", 24),
        Expression("m24_e4", "to articulate a strategic vision", "formuler une vision stratégique",
            "Executive-level phrasing for setting direction.",
            "The director articulated a strategic vision for scaling the programme regionally.", 24),
        Expression("m24_e5", "to command the room", "capter l'attention de l'auditoire",
            "An idiomatic expression describing confident, authoritative presence in a high-level setting.",
            "Clear, concise answers helped the presenter command the room during the ministerial briefing.", 24)
    ),
    concepts = listOf(
        ConceptCard("m24_c1", "Executive register", "Registre exécutif",
            "Executive-level English favors brevity, confident framing, and forward-looking recommendations over lengthy explanation — senior audiences expect the bottom line first, detail on request.",
            "L'anglais de niveau exécutif privilégie la concision, un cadrage assuré et des recommandations tournées vers l'avenir plutôt qu'une explication longue — un public de haut niveau attend l'essentiel d'abord, le détail sur demande.",
            "An illustrative executive framing: 'We recommend proceeding with Option B; it costs 15% more but reduces implementation risk significantly' — conclusion first, reasoning second.", true, 24),
        ConceptCard("m24_c2", "From field expertise to strategic voice", "De l'expertise de terrain à la voix stratégique",
            "An aménagiste's field-level technical credibility becomes a strategic asset when translated into concise, decision-relevant language for senior audiences — the underlying expertise does not change, but its presentation does.",
            "La crédibilité technique de terrain d'un aménagiste devient un atout stratégique lorsqu'elle est traduite en un langage concis et pertinent pour la décision, destiné à un public de haut niveau — l'expertise sous-jacente ne change pas, mais sa présentation oui.",
            "An illustrative transformation: detailed GIS methodology (Module 10) becomes, at executive level, 'Spatial analysis confirms this is our highest-impact investment zone.'", true, 24)
    ),
    donorQuestions = listOf(
        DonorQuestion("m24_dq1",
            "If you had thirty seconds with our regional director, what would you want them to know?",
            "This project addresses a documented, urgent water access gap for 4,000 households, our organization has the field presence to deliver it reliably, and we are asking for a decision on co-financing within the next month to stay on schedule.",
            "Bonne réponse : elle applique le registre exécutif — conclusion et demande claire en premier, sans détail technique superflu.",
            "executive communication", 24)
    ),
    exercises = listOf(
        Exercise("m24_ex1", ExerciseType.MULTIPLE_CHOICE,
            "Which phrase best reflects executive-level communication style?",
            "Quelle expression reflète le mieux le style de communication de niveau exécutif ?",
            listOf(
                "We recommend proceeding with Option B; it costs more but reduces risk.",
                "So there are many factors to consider, and honestly it's complicated, but maybe Option B could work if...",
                "Let me explain the full history of how we arrived at these options.",
                "We are not entirely sure, but we could look into it further."
            ),
            "We recommend proceeding with Option B; it costs more but reduces risk.",
            "Le registre exécutif place la recommandation et sa justification concise en tête.", 24),
        Exercise("m24_ex2", ExerciseType.TRANSLATION_FR_EN,
            "Translate: « La directrice a formulé une vision stratégique pour l'extension régionale du programme. »", null, emptyList(),
            "The director articulated a strategic vision for the regional expansion of the programme.",
            "« Articulate a strategic vision » est l'expression consacrée au niveau exécutif.", 24)
    )
)
