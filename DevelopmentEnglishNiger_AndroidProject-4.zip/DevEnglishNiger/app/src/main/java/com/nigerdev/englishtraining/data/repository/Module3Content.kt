package com.nigerdev.englishtraining.data.repository

import com.nigerdev.englishtraining.data.model.*

/**
 * MODULE 3 — Climate Change, Vulnerability and Resilience
 * Changement climatique, vulnérabilité et résilience
 * English ratio: 40% (beginner, upper end)
 */
val module3 = Module(
    id = 3,
    titleEn = "Climate Change, Vulnerability and Resilience",
    titleFr = "Changement climatique, vulnérabilité et résilience",
    englishRatio = 0.45f,
    objectiveEn = "By the end of this lesson, you will be able to explain vulnerability and resilience concepts and discuss how climate change affects communities in Niger.",
    objectiveFr = "À la fin de cette leçon, vous serez capable d'expliquer les concepts de vulnérabilité et de résilience et de discuter des effets du changement climatique sur les communautés au Niger.",
    vocabulary = listOf(
        VocabItem("m3_vulnerability", "vulnerability", "vulnérabilité",
            "The degree to which a population is likely to be affected by a hazard.",
            "Le degré auquel une population est susceptible d'être affectée par un aléa.",
            "Climate variability increases the vulnerability of rain-fed farming households.", 3),
        VocabItem("m3_resilience", "resilience", "résilience",
            "The capacity of a household or system to withstand, adapt to, and recover from shocks.",
            "Capacité d'un ménage ou d'un système à résister, s'adapter et se remettre des chocs.",
            "The programme aims to strengthen the resilience of pastoralist communities.", 3),
        VocabItem("m3_hazard", "hazard", "aléa",
            "A potentially damaging physical event, such as drought, flood, or locust invasion.",
            "Événement physique potentiellement dommageable, comme la sécheresse, l'inondation ou l'invasion acridienne.",
            "Drought is the main climate hazard affecting agropastoral zones in Niger.", 3),
        VocabItem("m3_exposure", "exposure", "exposition",
            "The extent to which people or assets are located in areas likely to be affected by a hazard.",
            "Degré auquel des personnes ou des biens se trouvent dans des zones susceptibles d'être touchées par un aléa.",
            "Villages along the Niger River have high exposure to flooding.", 3),
        VocabItem("m3_adaptive_capacity", "adaptive capacity", "capacité d'adaptation",
            "The ability of a system or community to adjust to climate change and reduce potential damage.",
            "Capacité d'un système ou d'une communauté à s'ajuster au changement climatique et à réduire les dommages potentiels.",
            "Access to weather information can strengthen farmers' adaptive capacity.", 3),
        VocabItem("m3_climate_variability", "climate variability", "variabilité climatique",
            "Short-term fluctuations in climate patterns, such as irregular rainfall from year to year.",
            "Fluctuations à court terme des régimes climatiques, telles que l'irrégularité des précipitations d'une année à l'autre.",
            "Climate variability makes it difficult for farmers to plan planting dates.", 3),
        VocabItem("m3_early_warning_system", "early warning system", "système d'alerte précoce",
            "A mechanism that monitors risk indicators and alerts communities before a hazard occurs.",
            "Mécanisme qui surveille les indicateurs de risque et alerte les communautés avant la survenue d'un aléa.",
            "The early warning system flagged below-average rainfall by mid-July.", 3),
        VocabItem("m3_coping_mechanism", "coping mechanism", "mécanisme d'adaptation/de survie",
            "A strategy a household uses to manage the immediate impact of a shock, sometimes at long-term cost.",
            "Stratégie qu'un ménage utilise pour gérer l'impact immédiat d'un choc, parfois au détriment du long terme.",
            "Selling livestock early is a common coping mechanism during drought.", 3)
    ),
    collocations = listOf(
        Expression("m3_e1", "to build resilience", "renforcer la résilience",
            "The standard collocation for strengthening a community's capacity to withstand shocks.",
            "The project seeks to build the resilience of 4,000 agropastoral households.", 3),
        Expression("m3_e2", "to adapt to climate change", "s'adapter au changement climatique",
            "Used broadly across development English for describing adaptation strategies.",
            "Farmers are adapting to climate change by diversifying their crops.", 3),
        Expression("m3_e3", "to mitigate climate risks", "atténuer les risques climatiques",
            "Refers to reducing the severity or likelihood of climate-related harm.",
            "Reforestation activities help mitigate climate risks in the watershed.", 3),
        Expression("m3_e4", "to reduce vulnerability", "réduire la vulnérabilité",
            "A frequent goal statement in project objectives.",
            "The intervention aims to reduce the vulnerability of women-headed households.", 3),
        Expression("m3_e5", "to be exposed to a hazard", "être exposé à un aléa",
            "Used to describe geographic or social exposure.",
            "Riverine communities are exposed to seasonal flooding.", 3),
        Expression("m3_e6", "to cope with a shock", "faire face à un choc",
            "Describes how households manage the impact of a hazard.",
            "Households used savings groups to cope with the 2024 dry spell.", 3)
    ),
    concepts = listOf(
        ConceptCard("m3_c1", "Vulnerability = Exposure × Sensitivity − Adaptive Capacity",
            "Vulnérabilité = Exposition × Sensibilité − Capacité d'adaptation",
            "This widely used framework shows that vulnerability rises with exposure and sensitivity to a hazard, and falls as adaptive capacity increases.",
            "Ce cadre largement utilisé montre que la vulnérabilité augmente avec l'exposition et la sensibilité à un aléa, et diminue lorsque la capacité d'adaptation augmente.",
            "In an illustrative Tillabéri analysis, households with irrigation access showed lower vulnerability despite similar exposure to drought.", true, 3),
        ConceptCard("m3_c2", "Resilience as a project objective", "La résilience comme objectif de projet",
            "Resilience-building projects do not aim to eliminate hazards but to strengthen households' ability to absorb and recover from them.",
            "Les projets de renforcement de la résilience ne visent pas à éliminer les aléas mais à renforcer la capacité des ménages à les absorber et à s'en remettre.",
            "A PNACC-aligned project in Dosso combined water harvesting and savings groups to build household resilience.", true, 3)
    ),
    donorQuestions = listOf(
        DonorQuestion("m3_dq1",
            "How does this project address climate vulnerability specifically, rather than poverty in general?",
            "The project targets the specific hazards affecting this zone — erratic rainfall and pasture degradation — and strengthens households' adaptive capacity through climate-smart agriculture and water harvesting, in addition to broader livelihood support.",
            "Bonne réponse : elle distingue clairement vulnérabilité climatique et pauvreté générale, et montre une logique causale précise.",
            "vulnerability", 3),
        DonorQuestion("m3_dq2",
            "What evidence do you have that this area is highly exposed to climate hazards?",
            "We used rainfall records from the last ten years, combined with community consultations and the national early warning system data, which together show a clear pattern of declining and more erratic rainfall.",
            "Bonne réponse : elle combine données quantitatives et qualitatives, ce qui renforce la crédibilité.",
            "evidence", 3)
    ),
    exercises = listOf(
        Exercise("m3_ex1", ExerciseType.MATCH_PAIRS,
            "Match each English term with its French translation.", null,
            listOf("vulnerability=vulnérabilité", "resilience=résilience", "hazard=aléa", "exposure=exposition"),
            "vulnerability=vulnérabilité;resilience=résilience;hazard=aléa;exposure=exposition",
            "Ces quatre termes forment le socle du vocabulaire climat-résilience.", 3),
        Exercise("m3_ex2", ExerciseType.CHOOSE_EXPRESSION,
            "Choose the correct expression: The project aims to ______ of vulnerable pastoralist households.",
            null,
            listOf("build the resilience", "mitigate the resilience", "expose the resilience", "cope the resilience"),
            "build the resilience",
            "« Build resilience » est la collocation standard ; les autres options ne sont pas idiomatiques.", 3)
    )
)
