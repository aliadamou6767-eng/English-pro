package com.nigerdev.englishtraining.ui.screens.practice

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.nigerdev.englishtraining.AppContainer
import com.nigerdev.englishtraining.data.model.Exercise
import com.nigerdev.englishtraining.data.model.ExerciseType
import com.nigerdev.englishtraining.data.repository.ContentRepository

@Composable
fun PracticeModuleScreen(moduleId: Int, appContainer: AppContainer) {
    val module = ContentRepository.moduleById(moduleId)
    val exercises = module?.exercises ?: emptyList()
    var currentIndex by remember { mutableStateOf(0) }
    var correctCount by remember { mutableStateOf(0) }
    var finished by remember { mutableStateOf(false) }

    if (module == null || exercises.isEmpty()) {
        Column(Modifier.fillMaxSize().padding(24.dp)) {
            Text("No exercises available yet for this module.")
        }
        return
    }

    if (finished) {
        val percent = (correctCount * 100) / exercises.size
        LaunchedEffect(Unit) {
            appContainer.progressRepository.recordQuizScore(moduleId, percent)
            appContainer.progressRepository.logPracticeSession(moduleId, exercises.size, correctCount)
        }
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Session complete", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("Score: $correctCount / ${exercises.size} ($percent%)", style = MaterialTheme.typography.titleLarge)
            Button(onClick = {
                currentIndex = 0; correctCount = 0; finished = false
            }) { Text("Practice again") }
        }
        return
    }

    val exercise = exercises[currentIndex]

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Exercise ${currentIndex + 1} / ${exercises.size}", style = MaterialTheme.typography.labelLarge)
        Spacer(Modifier.height(8.dp))
        ExerciseCard(
            exercise = exercise,
            onAnswered = { wasCorrect ->
                if (wasCorrect) correctCount++
                if (currentIndex + 1 < exercises.size) currentIndex++
                else finished = true
            }
        )
    }
}

@Composable
private fun ExerciseCard(exercise: Exercise, onAnswered: (Boolean) -> Unit) {
    var selected by remember(exercise.id) { mutableStateOf<String?>(null) }
    var submitted by remember(exercise.id) { mutableStateOf(false) }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(exercise.promptEn, style = MaterialTheme.typography.titleMedium)
            exercise.promptFr?.let { Text(it, style = MaterialTheme.typography.bodyMedium) }
            Spacer(Modifier.height(12.dp))

            when (exercise.type) {
                ExerciseType.MULTIPLE_CHOICE, ExerciseType.FILL_BLANK,
                ExerciseType.CHOOSE_EXPRESSION, ExerciseType.MATCH_PAIRS -> {
                    exercise.options.forEach { option ->
                        val isCorrectOption = option == exercise.correctAnswer
                        val isSelected = option == selected
                        OutlinedButton(
                            onClick = { if (!submitted) selected = option },
                            modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                            colors = if (submitted && isCorrectOption)
                                ButtonDefaults.outlinedButtonColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                            else if (submitted && isSelected)
                                ButtonDefaults.outlinedButtonColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                            else ButtonDefaults.outlinedButtonColors()
                        ) { Text(option) }
                    }
                }
                else -> {
                    Text("Type d'exercice à réponse libre — comparez avec la réponse correcte ci-dessous.")
                }
            }

            Spacer(Modifier.height(12.dp))

            if (!submitted) {
                Button(
                    onClick = { submitted = true },
                    enabled = selected != null || exercise.options.isEmpty(),
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Check answer") }
            } else {
                val wasCorrect = selected == exercise.correctAnswer || exercise.options.isEmpty()
                Text(
                    if (wasCorrect) "Correct!" else "Correct answer: ${exercise.correctAnswer}",
                    fontWeight = FontWeight.Bold
                )
                Text(exercise.explanationFr, style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(8.dp))
                Button(onClick = { onAnswered(wasCorrect) }, modifier = Modifier.fillMaxWidth()) {
                    Text("Next")
                }
            }
        }
    }
}
