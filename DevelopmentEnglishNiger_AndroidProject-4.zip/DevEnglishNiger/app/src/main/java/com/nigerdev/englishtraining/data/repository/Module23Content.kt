package com.nigerdev.englishtraining.data.repository

import com.nigerdev.englishtraining.data.model.*

/**
 * MODULE 23 — Reporting, Emails and Professional Correspondence
 * Rapports, courriels et correspondance professionnelle
 * English ratio: 75%
 */
val module23 = Module(
    id = 23,
    titleEn = "Reporting, Emails and Professional Correspondence",
    titleFr = "Rapports, courriels et correspondance professionnelle",
    englishRatio = 0.75f,
    objectiveEn = "By the end of this lesson, you will be able to write clear donor reports and professional emails in English.",
    objectiveFr = "À la fin de cette leçon, vous serez capable de rédiger des rapports destinés aux bailleurs et des courriels professionnels clairs en anglais.",
    vocabulary = listOf(
        VocabItem("m23_progress_report", "progress report", "rapport d'avancement",
            "A periodic report summarizing activities, results and challenges during a defined reporting period.",
            "Rapport périodique résumant les activités, résultats et difficultés d'une période donnée.",
            "The quarterly progress report highlighted a delay in the construction component.", 23),
        VocabItem("m23_narrative_report", "narrative report", "rapport narratif",
            "The descriptive section of a report explaining what happened and why, as opposed to financial tables.",
            "La section descriptive d'un rapport expliquant ce qui s'est passé et pourquoi, par opposition aux tableaux financiers.",
            "The narrative report explained the reasons behind the revised targeting approach.", 23),
        VocabItem("m23_cc", "to cc someone", "mettre en copie",
            "To include an additional recipient on an email for information, without expecting a direct reply.",
            "Inclure un destinataire supplémentaire dans un courriel pour information, sans attendre de réponse directe.",
            "Please cc the finance officer on all budget-related correspondence.", 23),
        VocabItem("m23_action_item", "action item", "point d'action",
            "A specific task assigned to a person following a meeting or correspondence.",
            "Tâche spécifique assignée à une personne à l'issue d'une réunion ou d'un échange.",
            "The minutes listed three action items with responsible persons and deadlines.", 23),
        VocabItem("m23_deadline_extension", "deadline extension", "prolongation de délai",
            "Additional time granted beyond an original submission or completion date.",
            "Temps supplémentaire accordé au-delà d'une date de soumission ou d'achèvement initiale.",
            "The organization requested a deadline extension for the annual report.", 23),
        VocabItem("m23_professional_tone", "professional tone", "ton professionnel",
            "Writing style that is courteous, clear, and appropriately formal for a workplace context.",
            "Style d'écriture courtois, clair et d'un niveau de formalité approprié au contexte professionnel.",
            "The email maintained a professional tone even when raising a difficult issue.", 23)
    ),
    collocations = listOf(
        Expression("m23_e1", "to submit a report", "soumettre un rapport",
            "The essential collocation for reporting obligations.",
            "The team submitted the progress report two days ahead of the deadline.", 23),
        Expression("m23_e2", "to follow up on an email", "relancer un courriel",
            "Common in day-to-day donor and partner correspondence.",
            "The coordinator followed up on the email after a week without a response.", 23),
        Expression("m23_e3", "to request a deadline extension", "demander une prolongation de délai",
            "Directly connects to Module 12's no-cost extension vocabulary.",
            "The team requested a deadline extension due to a delayed field mission.", 23),
        Expression("m23_e4", "to flag an issue promptly", "signaler un problème rapidement",
            "Emphasizes proactive, professional communication.",
            "The field officer flagged an issue promptly rather than waiting for the next report.", 23),
        Expression("m23_e5", "to close the loop", "clore le sujet / boucler",
            "Common informal-professional phrase for confirming an issue is resolved.",
            "A brief email closed the loop once the budget revision was approved.", 23)
    ),
    concepts = listOf(
        ConceptCard("m23_c1", "Structuring a professional email", "Structurer un courriel professionnel",
            "A clear professional email states its purpose in the first sentence, gives necessary context briefly, and ends with a specific action or request — donors and partners often skim, so burying the ask reduces response rates.",
            "Un courriel professionnel clair énonce son objectif dès la première phrase, donne le contexte nécessaire brièvement, et se termine par une action ou demande précise — les bailleurs et partenaires survolent souvent les messages, donc noyer la demande réduit le taux de réponse.",
            "An illustrative opening line: 'I am writing to request a two-week extension for the Q3 report, due to a delayed field mission in [commune].'", true, 23),
        ConceptCard("m23_c2", "Reporting bad news professionally", "Communiquer une mauvaise nouvelle avec professionnalisme",
            "When reporting a delay or shortfall, professional writing states the fact plainly, explains the cause briefly, and immediately follows with the corrective action — avoiding both minimization and over-apologizing.",
            "Pour signaler un retard ou un manquement, une rédaction professionnelle énonce le fait clairement, explique brièvement la cause, et enchaîne immédiatement sur la mesure corrective — en évitant à la fois la minimisation et l'excès d'excuses.",
            "An illustrative sentence: 'Due to flooding on the access road, borehole rehabilitation is three weeks behind schedule; we have revised the workplan and expect to be back on track by [date].'", true, 23)
    ),
    donorQuestions = listOf(
        DonorQuestion("m23_dq1",
            "Your last report mentioned a delay without much explanation. Can you clarify what happened?",
            "Apologies for the brevity in that report — the delay was caused by flooding that blocked the access road for three weeks; we have since revised the workplan and construction has resumed, with completion now expected by the end of next month.",
            "Bonne réponse : elle reconnaît la lacune, explique la cause précisément et donne une échéance corrective claire.",
            "reporting clarity", 23)
    ),
    exercises = listOf(
        Exercise("m23_ex1", ExerciseType.MULTIPLE_CHOICE,
            "Which term describes a task assigned to a person following a meeting?",
            "Quel terme désigne une tâche assignée à une personne à l'issue d'une réunion ?",
            listOf("action item", "narrative report", "deadline extension", "professional tone"),
            "action item", "« Action item » = point d'action assigné après une réunion.", 23),
        Exercise("m23_ex2", ExerciseType.SENTENCE_CORRECTION,
            "Improve this opening line for clarity: 'Hello, I hope this finds you well, I wanted to write about something regarding the report.'",
            "Améliorez cette phrase d'ouverture pour plus de clarté : « Bonjour, j'espère que vous allez bien, je voulais écrire à propos de quelque chose concernant le rapport. »",
            emptyList(),
            "I am writing to request a two-week extension for the Q3 report, due to a delayed field mission.",
            "Une phrase d'ouverture professionnelle énonce l'objet immédiatement, sans détour.", 23)
    )
)
