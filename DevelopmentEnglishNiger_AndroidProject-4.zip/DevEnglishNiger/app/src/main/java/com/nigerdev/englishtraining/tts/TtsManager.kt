package com.nigerdev.englishtraining.tts

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.Locale

enum class TtsAvailability { UNKNOWN, READY, ENGLISH_DATA_MISSING, UNAVAILABLE }

/**
 * Wraps android.speech.tts.TextToSpeech for English pronunciation playback.
 *
 * Requirements covered (per spec section 8):
 *  - Locale.US / Locale.UK selection
 *  - detects whether English TTS data is installed
 *  - stops previous speech before playing new speech
 *  - exposes isSpeaking as state for play/stop UI controls
 *  - setSpeechRate() support (0.70x / 1.00x / 1.20x)
 *
 * This is a process-wide singleton created once in the Application/Activity
 * and passed down via CompositionLocal (see MainActivity).
 */
class TtsManager(context: Context) {

    private val appContext = context.applicationContext
    private var tts: TextToSpeech? = null

    private val _availability = MutableStateFlow(TtsAvailability.UNKNOWN)
    val availability: StateFlow<TtsAvailability> = _availability

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking

    private var currentRate: Float = 1.0f
    private var currentLocale: Locale = Locale.US

    init {
        tts = TextToSpeech(appContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val result = tts?.setLanguage(currentLocale)
                _availability.value = when (result) {
                    TextToSpeech.LANG_MISSING_DATA, TextToSpeech.LANG_NOT_SUPPORTED ->
                        TtsAvailability.ENGLISH_DATA_MISSING
                    else -> TtsAvailability.READY
                }
                tts?.setSpeechRate(currentRate)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) { _isSpeaking.value = true }
                    override fun onDone(utteranceId: String?) { _isSpeaking.value = false }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { _isSpeaking.value = false }
                })
            } else {
                _availability.value = TtsAvailability.UNAVAILABLE
            }
        }
    }

    fun setVoiceLocale(locale: Locale) {
        currentLocale = locale
        val result = tts?.setLanguage(locale)
        _availability.value = when (result) {
            TextToSpeech.LANG_MISSING_DATA, TextToSpeech.LANG_NOT_SUPPORTED ->
                TtsAvailability.ENGLISH_DATA_MISSING
            else -> TtsAvailability.READY
        }
    }

    fun setSpeechRate(rate: Float) {
        currentRate = rate
        tts?.setSpeechRate(rate)
    }

    /** Stops any speech in progress, then speaks [text]. Always call this — never queue. */
    fun speak(text: String, utteranceId: String = text.hashCode().toString()) {
        if (_availability.value == TtsAvailability.UNAVAILABLE) return
        tts?.stop()
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    fun stop() {
        tts?.stop()
        _isSpeaking.value = false
    }

    fun shutdown() {
        tts?.shutdown()
        tts = null
    }

    /** Opens the system dialog to install missing TTS language data, if needed. */
    fun requestInstallEnglishData(): android.content.Intent {
        return android.content.Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA)
    }
}
