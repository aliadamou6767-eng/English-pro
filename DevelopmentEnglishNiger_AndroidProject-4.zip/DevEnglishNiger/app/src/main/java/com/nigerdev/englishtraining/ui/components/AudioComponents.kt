package com.nigerdev.englishtraining.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.nigerdev.englishtraining.tts.TtsManager

/**
 * The 🔊 Listen button required throughout the app (spec sections 7, 10, 15, 16, 20).
 * Tapping it stops any current speech and speaks [textToSpeak].
 * While speaking, it becomes a stop control.
 */
@Composable
fun ListenButton(
    textToSpeak: String,
    ttsManager: TtsManager,
    modifier: Modifier = Modifier
) {
    val isSpeaking by ttsManager.isSpeaking.collectAsState()
    var thisButtonActive by remember { mutableStateOf(false) }

    LaunchedEffect(isSpeaking) {
        if (!isSpeaking) thisButtonActive = false
    }

    FilledTonalIconButton(
        modifier = modifier.semantics { contentDescription = "Listen to English pronunciation" },
        onClick = {
            if (isSpeaking && thisButtonActive) {
                ttsManager.stop()
            } else {
                thisButtonActive = true
                ttsManager.speak(textToSpeak)
            }
        }
    ) {
        Icon(
            imageVector = if (isSpeaking && thisButtonActive) Icons.Filled.Stop else Icons.Filled.VolumeUp,
            contentDescription = null
        )
    }
}

/**
 * An English sentence with a selectable text component (never rendered as an image,
 * per spec section 9) plus its Listen button, laid out on one row.
 */
@Composable
fun AudioSentence(
    english: String,
    ttsManager: TtsManager,
    modifier: Modifier = Modifier,
    style: androidx.compose.ui.text.TextStyle = MaterialTheme.typography.bodyLarge
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        SelectionContainer(modifier = Modifier.weight(1f)) {
            Text(text = english, style = style)
        }
        ListenButton(textToSpeak = english, ttsManager = ttsManager)
    }
}
