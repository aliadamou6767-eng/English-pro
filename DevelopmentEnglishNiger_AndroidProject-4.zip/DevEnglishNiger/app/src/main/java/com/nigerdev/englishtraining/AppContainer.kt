package com.nigerdev.englishtraining

import android.content.Context
import com.nigerdev.englishtraining.data.db.AppDatabase
import com.nigerdev.englishtraining.data.repository.ProgressRepository
import com.nigerdev.englishtraining.data.repository.SettingsRepository
import com.nigerdev.englishtraining.tts.TtsManager

class AppContainer(context: Context) {
    val database: AppDatabase by lazy { AppDatabase.getInstance(context) }
    val progressRepository: ProgressRepository by lazy { ProgressRepository(database.dao()) }
    val settingsRepository: SettingsRepository by lazy { SettingsRepository(context) }
    val ttsManager: TtsManager by lazy { TtsManager(context) }
}
