package com.nigerdev.englishtraining.data.repository

import com.nigerdev.englishtraining.data.model.*

/**
 * MODULE 20 — Presenting a Development Project to Donors
 * Présentation d'un projet de développement aux bailleurs
 * English ratio: 70%
 */
val module20 = Module(
    id = 20,
    titleEn = "Presenting a Development Project to Donors",
    titleFr = "Présentation d'un projet de développement aux bailleurs",
    englishRatio = 0.70f,
    objectiveEn = "By the end of this lesson, you will be able to structure and deliver a clear, confident project presentation to a donor in English.",
    objectiveFr = "À la fin de cette leçon, vous serez capable de structurer et de présenter un projet de manière claire et assurée à un bailleur, en anglais.",
    vocabulary = listOf(
        VocabItem("m20_pitch", "pitch", "présentation synthétique / argumentaire",
            "A concise, persuasive summary of a project delivered verbally, often under time pressure.",
            "Résumé concis et persuasif d'un projet, présenté oralement, souvent sous contrainte de temps.",
            "The three-minute pitch focused on the problem, the approach, and the expected results.", 20),
        VocabItem("m20_talking_points", "talking points", "points clés à aborder",
            "A short list of key messages prepared in advance to guide a presentation or discussion.",
            "Courte liste de messages clés préparés à l'avance pour guider une présentation ou une discussion.",
            "The team agreed on talking points before the meeting with the donor's country office.", 20),
        VocabItem("m20_slide_deck", "slide deck", "diaporama",
            "A set of visual slides used to support an oral presentation.",
            "Ensemble de diapositives visuelles utilisées pour appuyer une présentation orale.",
            "The slide deck included one map showing the intervention area and key indicators.", 20),
        VocabItem("m20_time_management", "time management", "gestion du temps",
            "The skill of delivering a presentation within an allotted time limit.",
            "La compétence consistant à livrer une présentation dans le temps imparti.",
            "Time management was essential to cover all fourteen sections within twenty minutes.", 20),
        VocabItem("m20_audience_engagement", "audience engagement", "engagement de l'auditoire",
            "Techniques used to keep listeners attentive and involved during a presentation.",
            "Techniques utilisées pour garder l'auditoire attentif et impliqué durant une présentation.",
            "A brief pause for questions midway improved audience engagement.", 20),
        VocabItem("m20_closing_statement", "closing statement", "conclusion",
            "The final remarks of a presentation, often summarizing the key ask or call to action.",
            "Les propos finaux d'une présentation, résumant souvent la demande clé ou l'appel à l'action.",
            "The closing statement reiterated the funding request and next steps.", 20)
    ),
    collocations = listOf(
        Expression("m20_e1", "to deliver a presentation", "faire une présentation",
            "Standard collocation; note 'deliver,' not 'make' or 'do,' in professional register.",
            "The programme manager delivered the presentation to the donor delegation.", 20),
        Expression("m20_e2", "to keep to time", "respecter le temps imparti",
            "Frequently emphasized in presentation coaching.",
            "Rehearsing twice helped the presenter keep to time during the actual meeting.", 20),
        Expression("m20_e3", "to anticipate questions", "anticiper les questions",
            "Directly connects to donor simulation practice.",
            "The team anticipated questions about sustainability and prepared clear answers in advance.", 20),
        Expression("m20_e4", "to highlight key results", "mettre en avant les résultats clés",
            "Common when summarizing achievements or expected outcomes.",
            "The presentation highlighted key results expected within the first year.", 20),
        Expression("m20_e5", "to close with a clear ask", "conclure par une demande claire",
            "Refers to ending a presentation with an explicit, specific request.",
            "The presenter closed with a clear ask: co-financing for the second phase.", 20)
    ),
    concepts = listOf(
        ConceptCard("m20_c1", "Structuring a timed presentation", "Structurer une présentation chronométrée",
            "Per the fourteen-point structure (context, problem, evidence, target population, area, methodology, objectives, activities, results, indicators, risks, sustainability, budget, conclusion), shorter formats compress rather than drop sections — a 3-minute pitch touches all fourteen briefly rather than skipping half.",
            "Selon la structure en quatorze points (contexte, problème, preuves, population cible, zone, méthodologie, objectifs, activités, résultats, indicateurs, risques, durabilité, budget, conclusion), les formats plus courts compressent plutôt que suppriment des sections — un pitch de 3 minutes aborde brièvement les quatorze points plutôt que d'en ignorer la moitié.",
            "An illustrative 3-minute pitch gave each of the fourteen points roughly 10-12 seconds, while a 20-minute presentation allowed 60-90 seconds per point with supporting data.", true, 20),
        ConceptCard("m20_c2", "Confidence signals in professional English", "Signaux de confiance en anglais professionnel",
            "Confident delivery in English relies less on complex vocabulary and more on short, direct sentences, clear signposting ('First,' 'This brings me to,' 'In conclusion'), and comfortable pauses rather than filler words.",
            "Une prestation assurée en anglais repose moins sur un vocabulaire complexe que sur des phrases courtes et directes, des marqueurs de transition clairs (« First », « This brings me to », « In conclusion »), et des pauses maîtrisées plutôt que des mots de remplissage.",
            "An illustrative transition: 'This brings me to our second objective' is clearer and more confident than a long, hedging sentence trying to connect two ideas.", true, 20)
    ),
    donorQuestions = listOf(
        DonorQuestion("m20_dq1",
            "Can you summarize your project in under two minutes?",
            "Certainly — [project name] addresses declining water access for 4,000 households in [commune] through borehole rehabilitation and community management, with an expected 70% access rate by project end, requiring [amount] over eighteen months.",
            "Bonne réponse : elle couvre problème, cible, approche, résultat attendu et budget en une seule phrase dense mais claire.",
            "presentation", 20)
    ),
    exercises = listOf(
        Exercise("m20_ex1", ExerciseType.MULTIPLE_CHOICE,
            "Which word is the professional collocation for giving a presentation?",
            "Quel verbe est la collocation professionnelle pour faire une présentation ?",
            listOf("make a presentation", "do a presentation", "deliver a presentation", "say a presentation"),
            "deliver a presentation", "« Deliver a presentation » est le registre professionnel standard.", 20),
        Exercise("m20_ex2", ExerciseType.CHOOSE_EXPRESSION,
            "Choose the best transition to open a new section: '_____ our second objective is to strengthen local governance.'",
            null,
            listOf("This brings me to", "By the way", "Anyway", "Also"),
            "This brings me to",
            "Les transitions formelles structurent une présentation professionnelle plus efficacement que les connecteurs informels.", 20)
    )
)
