package com.nigerdev.englishtraining.data.repository

import com.nigerdev.englishtraining.data.model.*

/**
 * MODULE 4 — Poverty, Livelihoods and Vulnerable Groups
 * Pauvreté, moyens d'existence et groupes vulnérables
 * English ratio: 45% (beginner, upper end)
 */
val module4 = Module(
    id = 4,
    titleEn = "Poverty, Livelihoods and Vulnerable Groups",
    titleFr = "Pauvreté, moyens d'existence et groupes vulnérables",
    englishRatio = 0.45f,
    objectiveEn = "By the end of this lesson, you will be able to describe household livelihoods and identify vulnerable groups in professional English.",
    objectiveFr = "À la fin de cette leçon, vous serez capable de décrire les moyens d'existence des ménages et d'identifier les groupes vulnérables en anglais professionnel.",
    vocabulary = listOf(
        VocabItem("m4_livelihood", "livelihood", "moyens d'existence",
            "The means by which a household secures the necessities of life, such as food, water and income.",
            "Les moyens par lesquels un ménage se procure les nécessités de la vie : nourriture, eau, revenu.",
            "Livestock rearing is the main livelihood for pastoralist households in this area.", 4),
        VocabItem("m4_income_generating_activity", "income-generating activity", "activité génératrice de revenus",
            "An activity undertaken specifically to produce household income.",
            "Activité entreprise spécifiquement pour produire un revenu pour le ménage.",
            "The project supports small-scale trade as an income-generating activity for women.", 4),
        VocabItem("m4_household_head", "household head", "chef de ménage",
            "The person recognized as primarily responsible for a household's decisions and resources.",
            "Personne reconnue comme principalement responsable des décisions et des ressources du ménage.",
            "Nearly a third of surveyed households are headed by women.", 4),
        VocabItem("m4_extreme_poverty", "extreme poverty", "extrême pauvreté",
            "A condition characterized by severe deprivation of basic human needs.",
            "État caractérisé par une privation sévère des besoins humains fondamentaux.",
            "The programme prioritizes communes with the highest rates of extreme poverty.", 4),
        VocabItem("m4_social_safety_net", "social safety net", "filet social de sécurité",
            "A set of programmes that protect vulnerable households from severe hardship, such as cash transfers.",
            "Ensemble de programmes qui protègent les ménages vulnérables contre les difficultés graves, comme les transferts monétaires.",
            "Cash transfers are part of the national social safety net during the lean season.", 4),
        VocabItem("m4_diversification", "livelihood diversification", "diversification des moyens d'existence",
            "The process of adding new income sources to reduce a household's dependence on a single activity.",
            "Processus consistant à ajouter de nouvelles sources de revenu pour réduire la dépendance d'un ménage à une seule activité.",
            "Beekeeping was introduced as part of a livelihood diversification strategy.", 4),
        VocabItem("m4_person_with_disability", "person with disability", "personne en situation de handicap",
            "Preferred professional terminology; avoid outdated or stigmatizing terms.",
            "Terminologie professionnelle privilégiée ; éviter les termes dépassés ou stigmatisants.",
            "The assessment ensured that persons with disabilities were consulted directly.", 4),
        VocabItem("m4_marginalized_group", "marginalized group", "groupe marginalisé",
            "A group that is systematically excluded from resources, decision-making, or opportunities.",
            "Groupe systématiquement exclu des ressources, de la prise de décision ou des opportunités.",
            "The consultation process specifically reached out to marginalized groups in the commune.", 4)
    ),
    collocations = listOf(
        Expression("m4_e1", "to identify vulnerable households", "identifier les ménages vulnérables",
            "The standard phrase for the targeting step of needs assessment.",
            "The survey team used agreed criteria to identify vulnerable households.", 4),
        Expression("m4_e2", "to fall below the poverty line", "se situer sous le seuil de pauvreté",
            "Formal expression used in poverty analysis.",
            "An estimated 42% of surveyed households fall below the poverty line.", 4),
        Expression("m4_e3", "to depend on a single income source", "dépendre d'une seule source de revenu",
            "Used to describe livelihood fragility.",
            "Many households depend on a single income source, which increases their vulnerability.", 4),
        Expression("m4_e4", "to target the most vulnerable", "cibler les plus vulnérables",
            "Common in project objectives and donor proposals.",
            "The project specifically targets the most vulnerable households in each village.", 4),
        Expression("m4_e5", "to cope with income shocks", "faire face aux chocs de revenu",
            "Used when discussing household resilience to economic shocks.",
            "Savings groups help households cope with income shocks during the dry season.", 4),
        Expression("m4_e6", "to have limited access to", "avoir un accès limité à",
            "General-purpose expression for describing constraints.",
            "Female-headed households often have limited access to agricultural land.", 4)
    ),
    concepts = listOf(
        ConceptCard("m4_c1", "Livelihood framework (introduction)", "Cadre des moyens d'existence (introduction)",
            "A livelihood framework analyzes the assets a household draws on — natural, physical, human, financial, and social — to sustain itself.",
            "Un cadre des moyens d'existence analyse les actifs sur lesquels un ménage s'appuie — naturels, physiques, humains, financiers et sociaux — pour subsister.",
            "In an illustrative Zinder-region analysis, agropastoral households relied mainly on natural assets (land, pasture) and social assets (mutual aid networks).", true, 4),
        ConceptCard("m4_c2", "Vulnerability targeting criteria", "Critères de ciblage de la vulnérabilité",
            "Projects typically combine several criteria — female headship, disability, dependency ratio, asset ownership — rather than relying on a single indicator.",
            "Les projets combinent généralement plusieurs critères — chef de ménage femme, handicap, taux de dépendance, possession d'actifs — plutôt que de s'appuyer sur un seul indicateur.",
            "An illustrative targeting matrix in Maradi region weighted female headship and livestock loss above household size alone.", true, 4)
    ),
    donorQuestions = listOf(
        DonorQuestion("m4_dq1",
            "How did you identify the most vulnerable households, rather than the whole community?",
            "We used a combination of participatory wealth ranking with community members and objective criteria — female headship, dependency ratio, and asset ownership — validated jointly with local authorities.",
            "Bonne réponse : elle montre une méthode combinée (participative + objective) et une validation locale, ce qui renforce la crédibilité du ciblage.",
            "targeting", 4),
        DonorQuestion("m4_dq2",
            "How will women-headed households specifically benefit from this project?",
            "Women-headed households were identified as a priority group during targeting; the project allocates a dedicated share of income-generating activities and literacy training directly to them.",
            "Bonne réponse : elle est concrète et chiffrable plutôt que vague, ce que les bailleurs recherchent.",
            "gender", 4)
    ),
    exercises = listOf(
        Exercise("m4_ex1", ExerciseType.MULTIPLE_CHOICE,
            "Which term refers to the means by which a household secures food, water and income?",
            "Quel terme désigne les moyens par lesquels un ménage se procure nourriture, eau et revenu ?",
            listOf("livelihood", "social safety net", "extreme poverty", "marginalized group"),
            "livelihood", "« Livelihood » est le terme central pour les moyens d'existence.", 4),
        Exercise("m4_ex2", ExerciseType.TRANSLATION_FR_EN,
            "Translate: « Le projet cible spécifiquement les ménages les plus vulnérables. »", null, emptyList(),
            "The project specifically targets the most vulnerable households.",
            "« Target » + les plus vulnérables ; notez l'ordre des mots en anglais.", 4),
        Exercise("m4_ex3", ExerciseType.FILL_BLANK,
            "Many households ______ a single income source, which increases their vulnerability.", null,
            listOf("depend on", "target", "fall below", "cope with"),
            "depend on",
            "« Depend on » exprime la dépendance à une seule source de revenu.", 4)
    )
)
