package com.nigerdev.englishtraining.data.repository

import com.nigerdev.englishtraining.data.model.*

/**
 * MODULE 22 — Negotiation with Donors and Professional Diplomacy
 * Négociation avec les bailleurs et diplomatie professionnelle
 * English ratio: 75%
 */
val module22 = Module(
    id = 22,
    titleEn = "Negotiation with Donors and Professional Diplomacy",
    titleFr = "Négociation avec les bailleurs et diplomatie professionnelle",
    englishRatio = 0.75f,
    objectiveEn = "By the end of this lesson, you will be able to negotiate budget, scope and timeline adjustments with donors diplomatically in English.",
    objectiveFr = "À la fin de cette leçon, vous serez capable de négocier des ajustements de budget, de portée et de délai avec les bailleurs de manière diplomatique, en anglais.",
    vocabulary = listOf(
        VocabItem("m22_negotiation", "negotiation", "négociation",
            "A structured discussion aimed at reaching a mutually acceptable agreement on terms.",
            "Discussion structurée visant à parvenir à un accord mutuellement acceptable sur des termes.",
            "Budget negotiation with the donor lasted through two rounds of revisions.", 22),
        VocabItem("m22_trade_off", "trade-off", "compromis / arbitrage",
            "A balance struck between two competing priorities, where gaining one means giving up part of another.",
            "Équilibre trouvé entre deux priorités concurrentes, où gagner l'une implique de renoncer en partie à l'autre.",
            "Reducing the geographic scope was a trade-off accepted to keep the original timeline.", 22),
        VocabItem("m22_ceiling", "budget ceiling", "plafond budgétaire",
            "The maximum amount of funding a donor is able or willing to provide.",
            "Le montant maximal de financement qu'un bailleur est en mesure ou disposé à fournir.",
            "The revised proposal was adjusted to fit within the donor's budget ceiling.", 22),
        VocabItem("m22_counter_proposal", "counter-proposal", "contre-proposition",
            "An alternative offer made in response to an initial proposal during negotiation.",
            "Offre alternative faite en réponse à une proposition initiale durant une négociation.",
            "The organization submitted a counter-proposal with a phased implementation timeline.", 22),
        VocabItem("m22_common_ground", "common ground", "terrain d'entente",
            "Shared interests or points of agreement that can form the basis of a negotiated solution.",
            "Intérêts partagés ou points d'accord pouvant servir de base à une solution négociée.",
            "Both parties found common ground on prioritizing water access over secondary activities.", 22),
        VocabItem("m22_diplomatic_language", "diplomatic language", "langage diplomatique",
            "Phrasing chosen to express disagreement or difficult positions respectfully and constructively.",
            "Formulation choisie pour exprimer un désaccord ou des positions difficiles de façon respectueuse et constructive.",
            "The email used diplomatic language to request additional time without appearing uncooperative.", 22)
    ),
    collocations = listOf(
        Expression("m22_e1", "to negotiate in good faith", "négocier de bonne foi",
            "Signals a constructive, honest negotiating posture.",
            "Both teams negotiated in good faith to reach a workable budget compromise.", 22),
        Expression("m22_e2", "to find a middle ground", "trouver un compromis / un terrain d'entente",
            "Common phrase for describing negotiated outcomes.",
            "The teams found a middle ground between the requested budget and the donor's ceiling.", 22),
        Expression("m22_e3", "to make a counter-proposal", "faire une contre-proposition",
            "Standard negotiation action verb.",
            "The organization made a counter-proposal reducing scope rather than quality.", 22),
        Expression("m22_e4", "to push back diplomatically", "s'opposer avec diplomatie",
            "Describes disagreeing professionally without damaging the relationship.",
            "The programme manager pushed back diplomatically on the unrealistic timeline.", 22),
        Expression("m22_e5", "to reach a mutually acceptable agreement", "parvenir à un accord mutuellement acceptable",
            "Formal closing phrase for successful negotiation.",
            "After two rounds of discussion, both parties reached a mutually acceptable agreement.", 22)
    ),
    concepts = listOf(
        ConceptCard("m22_c1", "Interests vs. positions", "Intérêts vs. positions",
            "Effective negotiation looks past stated positions (e.g., 'we need this exact budget') to underlying interests (e.g., 'we need to reach a minimum number of households') — this often reveals more flexible trade-offs.",
            "Une négociation efficace regarde au-delà des positions affichées (par ex. « il nous faut ce budget précis ») pour identifier les intérêts sous-jacents (par ex. « nous devons atteindre un nombre minimum de ménages ») — cela révèle souvent des compromis plus flexibles.",
            "An illustrative case: rather than insisting on the original budget, the team proposed reducing geographic scope to preserve per-household investment quality, which satisfied the donor's real concern about cost-effectiveness.", true, 22),
        ConceptCard("m22_c2", "Diplomatic phrasing patterns", "Modèles de formulation diplomatique",
            "Diplomatic English often uses hedging and softening structures — 'we would suggest,' 'one option might be,' 'we understand the constraint, and propose' — rather than blunt refusals or demands.",
            "L'anglais diplomatique utilise souvent des structures atténuantes — « we would suggest », « one option might be », « we understand the constraint, and propose » — plutôt que des refus ou exigences directs.",
            "An illustrative phrasing shift: instead of 'That budget is not enough,' a diplomatic version is 'We understand the funding constraint, and would like to propose a phased approach that fits within it.'", true, 22)
    ),
    donorQuestions = listOf(
        DonorQuestion("m22_dq1",
            "We can only offer 70% of your requested budget. How would you adjust the project?",
            "We understand the constraint, and we would propose reducing the geographic scope from six to four villages rather than lowering the quality of activities, so we can maintain strong per-household impact within the available budget.",
            "Bonne réponse : elle reconnaît la contrainte avec diplomatie et propose un compromis structuré plutôt qu'un simple accord ou refus.",
            "budget negotiation", 22)
    ),
    exercises = listOf(
        Exercise("m22_ex1", ExerciseType.MULTIPLE_CHOICE,
            "Which term describes the maximum funding amount a donor is willing to provide?",
            "Quel terme désigne le montant maximal de financement qu'un bailleur est disposé à fournir ?",
            listOf("counter-proposal", "budget ceiling", "common ground", "trade-off"),
            "budget ceiling", "« Budget ceiling » = plafond budgétaire maximal.", 22),
        Exercise("m22_ex2", ExerciseType.SENTENCE_CORRECTION,
            "Make this more diplomatic: 'That budget is not enough for the project.'",
            "Rendez cette phrase plus diplomatique : « Ce budget n'est pas suffisant pour le projet. »",
            emptyList(),
            "We understand the funding constraint, and would like to propose a phased approach that fits within it.",
            "Le langage diplomatique reformule un refus direct en proposition constructive.", 22)
    )
)
